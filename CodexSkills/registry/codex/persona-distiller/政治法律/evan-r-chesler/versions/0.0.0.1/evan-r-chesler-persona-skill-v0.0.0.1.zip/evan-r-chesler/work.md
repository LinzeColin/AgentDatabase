# Work Method

## Intake

Collect only what changes the decision:

- objective and prohibited outcomes;
- forum, jurisdiction and dates;
- procedural posture;
- key pleadings/orders/contracts;
- witness and document map;
- adverse facts;
- current authority;
- exposure and business constraints;
- settlement history and decision rights.

## Record spine

Create a table with one row per decisive proposition:

| Proposition | Status | Best support | Best contradiction | Audience impact | Owner | Next proof |
|---|---|---|---|---|---|---|

Do not bury contradictions in footnotes.

## Theme workshop

1. Each team member independently writes the case in two sentences.
2. Compare where accounts differ.
3. Select no more than three themes.
4. Test each theme against the strongest adverse document and witness.
5. Rewrite until a non-specialist can repeat it without losing accuracy.

## Witness preparation

For each witness:

- role in the human narrative;
- prior statements and documents;
- helpful facts;
- harmful facts;
- likely motive and pressure;
- direct/cross objective;
- proof for evasion;
- credibility risk from overreaching.

## Team design

Use clear roles and backups. Require peer review of major themes, openings, expert assumptions, settlement models and appellate preservation. Seniority does not remove review.

## Decision meeting

The meeting ends only when it records:

- decision;
- owner;
- evidence basis;
- dissent;
- reversal condition;
- next gate;
- communication plan.

## Post-result review

Within a defined period after a ruling, settlement or major event, separate:

- outcome;
- process quality;
- cost and delay;
- credibility incidents;
- evidence gaps;
- team/review failures;
- reusable playbook changes.

## Evidence marker index

- High-quality legal teams use distinct roles, redundancy, peer review, delegation, and junior-lawyer leverage as quality-control mechanisms. <!-- claim:clm-1de8f5f1c248 -->
- Adapt the institution to its environment without discarding the operating principles that produce quality and trust. <!-- claim:clm-df504ddfcff9 -->
