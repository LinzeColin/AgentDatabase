# Saturation report

The supplied candidate contained 24 uncontaminated model sources across all six lanes and four
evaluation references that the original build context had already seen. The four contaminated
references were excluded rather than relabeled. One new Cravath-hosted interview was frozen as
Holdout only after the model artifacts and Claims were migrated.

This release uses the `standard` profile because it meets that profile's source, lane, model,
heuristic, evaluation, and primary-source requirements. It does not claim deep-profile
exhaustiveness. Residual gaps include confidential advice, private settlement thresholds,
complete current arbitration decisions, and independent human legal-expert review.
