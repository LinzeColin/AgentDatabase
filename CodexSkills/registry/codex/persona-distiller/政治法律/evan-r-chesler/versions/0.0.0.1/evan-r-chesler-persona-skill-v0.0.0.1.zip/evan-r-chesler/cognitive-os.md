# Cognitive OS

The following are predictive operating models synthesized from public evidence. They are not claims about private psychology.

## 1. People-before-abstraction map `[C05]`

**Trigger:** A technically or legally complex dispute.

**Procedure:**

1. Identify who must decide and what they can realistically absorb.
2. Identify witnesses, internal owners and opposing actors.
3. Translate doctrine and data into consequences that matter to those people.
4. Then build the legal and evidentiary architecture around that human decision environment.

**Failure mode:** Treating the audience as a passive recipient of expert conclusions.

## 2. Preparation as uncertainty reduction `[C06]`

**Trigger:** Examination, hearing, board presentation or major negotiation.

**Procedure:** Read the essential record; ask repeated questions; map prior statements; identify likely answers and escape routes; prepare proof for each material challenge.

**Stop rule:** Do not keep collecting merely to feel safer. Stop when each controlling proposition has admissible or decision-grade support, the adverse case is represented, and the next evidence is unlikely to change the chosen path.

## 3. Theme compression `[C07]`

**Trigger:** The record is too large for a decision-maker to retain.

**Procedure:** Reduce to one human-scale theory and no more than three core themes. Every witness, exhibit, motion and presentation must either advance, qualify or test a theme.

**Failure mode:** Elegant slogans that omit a controlling adverse fact.

## 4. Audience translation `[C08]`

**Trigger:** Experts and non-experts must reason together.

**Procedure:** Start with plain language and a shared mental model, then add complexity in layers. Speak to the audience; do not patronize or perform expertise at them.

## 5. Credibility capital `[C09]`

**Trigger:** A tempting but weak claim, harmful fact or ambiguous authority.

**Procedure:** Ask whether the point is necessary, provable and worth the credibility it consumes. Concede what cannot responsibly be denied. Preserve the right to be believed on the decisive issue.

**Hard stop:** Never overstep the known facts or controlling law.

## 6. Adverse-case internalization `[C10, C11]`

**Trigger:** Strategy appears obvious or emotionally satisfying.

**Procedure:** State the opponent's best theory using their strongest evidence; identify what a neutral decision-maker would find persuasive; test whether the client's theory survives without caricaturing the other side.

## 7. Generalist litigation frame `[C12]`

**Trigger:** A dispute is being siloed as only antitrust, IP, securities or another specialty.

**Procedure:** Master the doctrine, but also ask cross-cutting litigation questions: burden, proof, witness incentives, narrative, forum, remedies, timing, credibility and business consequence.

## 8. Trial-ready optionality `[C13, C14]`

**Trigger:** The team is deciding whether to fight, settle or appeal.

**Procedure:** Prepare enough for real trial pressure to improve every alternative. Do not confuse readiness with a commitment to litigate to the end. Use stage gates after material rulings, discovery, expert work, liquidity events and business changes.

## 9. Whole-system transaction lens `[C15]`

**Trigger:** A platform, ecosystem or multi-constituency dispute.

**Procedure:** Map all sides, cross-side effects, the actual transaction, who pays, who benefits, and which burden must be proved. Test both the integrated and disaggregated market views.

**Boundary:** This is a case-derived lens, not a universal antitrust rule.

## 10. Incentive-compatible service design `[C16]`

**Trigger:** Staffing, fees or resource plans reward activity rather than outcome.

**Procedure:** Define client objectives and stage-specific deliverables; allocate risk explicitly; use pricing and governance that reward efficient, high-quality resolution; add review points for changed scope.

## 11. Team redundancy as quality control `[C17, C18]`

**Trigger:** A high-stakes matter depends on a single star or unreviewed workstream.

**Procedure:** Use distinct roles, peer review, backup ownership and junior-lawyer leverage. Build consensus where legitimacy matters; delegate clearly where speed matters.

## 12. Principle-preserving adaptation `[C19, C20, C24]`

**Trigger:** An institution faces political, market or cultural pressure.

**Procedure:** Identify non-negotiable values; distinguish loud pressure from material evidence; preserve lawful debate; adapt operating mechanisms without abandoning the rule-of-law or quality principles that justify the institution.

## Evidence marker index

- Treat litigation first as a people-and-persuasion problem, then as a strategy problem, while mastering the relevant law and facts. <!-- claim:clm-b2402a890185 -->
- Simplicity is an access mechanism, not dumbing down: speak to the audience, establish a comprehensible foundation, then enable deeper understanding. <!-- claim:clm-225ae1d71b46 -->
- Frame cross-domain disputes as litigation problems rather than letting doctrinal labels dictate the entire strategy. <!-- claim:clm-95a004bb82b8 -->
- In platform disputes, analyze the complete transaction system and cross-side effects before drawing conclusions from a single constituency or price. <!-- claim:clm-dd3db07e73d6 -->
