# Decision Policy

## The Chesler dispute decision loop

### Gate 0 - Authority and jurisdiction

Before substantive analysis, confirm the jurisdiction, governing law, forum, procedural posture, deadlines and current primary authority. Historical Chesler cases are learning material, not current law.

### Gate 1 - Enterprise objective

Write one sentence completing:

> The enterprise wins if, by [date/trigger], it preserves or obtains [cash/control/continuity/reputation/precedent/IP/customer/governance outcome] within [risk/cost constraints].

Reject a legal tactic that has no plausible path to this objective.

### Gate 2 - Record quality

Classify every material proposition:

- verified and usable;
- verified but harmful;
- disputed;
- inference;
- expert-dependent;
- missing;
- currently unknowable.

No theme is final until it accounts for the harmful verified facts.

### Gate 3 - Audience and people map

For each relevant person or institution, record:

- decision power;
- incentives;
- information level;
- credibility with the forum;
- likely objection;
- what would change their position.

### Gate 4 - Case-theory compression

A trialable theory must pass all five tests:

1. accurate enough to survive the record;
2. simple enough for a non-specialist to repeat;
3. connected to a human or institutional consequence;
4. consistent across witnesses and documents;
5. distinguishable from the opponent's best theory.

### Gate 5 - Credibility budget

For each proposed assertion, ask:

- Is it necessary?
- Is it provable?
- Is it consistent with prior statements and documents?
- What happens if the decision-maker rejects it?
- Does it weaken the decisive point?

Concede low-value, high-risk points.

### Gate 6 - Option comparison

Compare at least these paths where available:

| Path | Legal upside | Business upside | Credibility risk | Cost/time | Reversibility | Trigger to choose |
|---|---:|---:|---:|---:|---:|---|
| Trial | | | | | | |
| Settlement | | | | | | |
| Business agreement | | | | | | |
| Motion/narrowing | | | | | | |
| Appeal | | | | | | |
| Arbitration/mediation | | | | | | |
| Stop/withdraw | | | | | | |

### Gate 7 - Resource and incentive alignment

Define:

- lead decision owner;
- trial/theory owner;
- record owner;
- witness owner;
- expert owner;
- business owner;
- settlement authority;
- independent reviewer;
- fee/staffing logic;
- maximum exposure and stop-loss conditions.

### Gate 8 - Decision and reversal conditions

Every recommendation must name:

- the chosen path;
- the principal reason;
- the strongest objection;
- the evidence that would reverse the decision;
- the next review trigger;
- who owns the decision.

### Gate 9 - After-action review

Separate process from outcome. A win may conceal waste or credibility damage; a loss may follow a sound process. Record what should be repeated, stopped and tested next. `[C25]`

## Evidence marker index

- Preparation is the principal uncertainty-reduction mechanism: read the essential record, ask many questions, know prior witness statements, and anticipate answers before examination. <!-- claim:clm-c68b87b19ed5 -->
- Compress a large factual and doctrinal record into a small number of themes that every examination, opening, and closing advances consistently. <!-- claim:clm-04b6ab54c9ef -->
- A persuasive opening should make defensible promises and directly account for the strongest evidence against the client rather than relying on over-advocacy. <!-- claim:clm-7a58042b58f2 -->
- Prepare as though trial is real, but treat settlement, business agreement, appeal, and other resolution paths as legitimate means of serving the client. <!-- claim:clm-88293eca8df6 -->
- Legal-service incentives should be aligned with client outcomes, predictability, and efficient resolution rather than mechanically rewarding hours consumed. <!-- claim:clm-3afddcc76ee8 -->
