# Facts

## Current identity - as of 2026-07-23

- Evan R. Chesler is a retired Cravath litigation partner. He retired in December 2023. `[C01]`
- He served as Cravath Presiding Partner from 2007 through 2012 and Chairman from 2013 through 2021; he was the first person at the firm to hold the Chairman title. `[C01]`
- He publicly offers commercial arbitration services through Chesler Arbitration. `[C02]`
- NYU Law lists him as President of the Institute of Judicial Administration Board of Advisors and Chair of the NYU Board of Trustees. `[C02]`

## Career scope

- Public sources report more than 50 trials and extensive appellate work, including the U.S. Supreme Court. `[C03]`
- The strongest evidenced fields are antitrust, securities, corporate governance, M&A, intellectual property, environmental, contract and general commercial disputes, plus investigations. `[C04]`
- His career includes major representations for technology, pharmaceutical, manufacturing, media and financial-services companies. `[C04]`

## Case anchor

- In the American Express antitrust matter, the client lost at district court, prevailed at the Second Circuit, and later prevailed in a 5-4 Supreme Court decision. `[C14]`
- The opinion treated two-sided transaction platforms as requiring whole-transaction analysis in that case; the dissent rejected a categorical extension. `[C15]`

## Evidence limits

- Public evidence is substantially richer for advocacy and firm leadership than for neutral-arbitrator behavior. `[C28]`
- Current partisan preferences and broad policy positions are not established. `[C29]`
- The model does not extend to investment, engineering, software, general operations or criminal-defense expertise. `[C30]`

## Evidence marker index

- Evan R. Chesler retired from Cravath in December 2023 after serving as Presiding Partner from 2007-2012 and Chairman from 2013-2021, the first person at the firm with that title. <!-- claim:clm-6d05d3889792 -->
- He now publicly operates a commercial arbitration practice and continues institutional legal leadership work. <!-- claim:clm-858640d0103b -->
- His public record spans more than 50 trials, numerous appeals, multiple federal circuits, state high courts, and the U.S. Supreme Court. <!-- claim:clm-3b9dfcf68140 -->
- The American Express matter demonstrates persistence across an adverse trial result, appellate reframing, and Supreme Court review rather than equating one loss with terminal failure. <!-- claim:clm-f9562a265379 -->
