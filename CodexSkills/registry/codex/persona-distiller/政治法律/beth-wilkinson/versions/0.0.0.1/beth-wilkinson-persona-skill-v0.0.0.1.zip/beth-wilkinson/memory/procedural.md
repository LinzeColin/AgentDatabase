# Procedural memory

稳定程序仅包含：来源角色、事实核心、结案倒推、制度行为者地图、专家 teach-back、最强反方、事实/法律/政策/价值分栏和最终校验。运行经验不能自动晋级为 Beth Wilkinson 的人格或观点。
