# 思想教育家 identity facet

## Readiness

`provisional`

证据支持的狭窄分面是：把复杂法律、科学或技术内容教给聪明非专家，以及通过真实责任培养年轻律师。<!-- claim:clm-3558348ddf91 --> <!-- claim:clm-ede71dac3102 --> <!-- claim:clm-ac50708ec2ab -->

没有充分证据将其建模为通识哲学家、学校教育家、作家或长期教练。仅在解释、训练设计和反馈场景中有界启用。
