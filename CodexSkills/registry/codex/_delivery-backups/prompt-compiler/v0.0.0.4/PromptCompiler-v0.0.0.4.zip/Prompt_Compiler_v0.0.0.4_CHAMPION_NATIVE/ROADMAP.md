# Roadmap｜Prompt Compiler

## 当前发布：v0.0.0.4

状态：`SEALED_TASKPACK`。当前版本完成四条独立原生优化路径、两阶段 Omni、严格逐维冠军门、事务式安装和冻结 QA。Build Agent 只承担真实环境最后一公里。

| Stage | Phase | 状态 | 当前交付 |
|---|---|---|---|
| 0 | Baseline / Discovery | 完成 | v0.0.0.3 逆向与失效路径定位 |
| 1 | Native Path Contract | 完成 | GEPA、Promptfoo、AutoResearch、MetaHarness 无本地回退 |
| 2 | Workspace Isolation | 完成 | origin、入口、allowlist、前后树哈希、越界阻断 |
| 3 | Omni Orchestration | 完成 | 四路径 Stage 1 + 逐维差距 Stage 2 |
| 4 | Evidence / Champion Gate | 完成 | 逐竞品逐维第一、最终集密封、证据哈希 |
| 5 | Verification / Packaging | 完成 | 58 项测试、三轮 QA、事务式安装、确定性 ZIP |
| 6 | Real Environment Last Mile | 环境绑定 | 真实工作区、模型、凭据、数据、正式同场证据、落库 |

## 后续独立版本，不污染 v0.0.0.4

- v0.0.0.5：统一原生工作区自动发现与固定 commit/许可证收据；加入真实 Token、货币成本和硬件延迟计量。
- v0.0.0.6：序贯统计停止、分层预算和跨数据集冠军稳定性门，减少无收益调用。
- v0.0.0.7：将 DSPy MIPROv2、TextGrad、OPRO、PromptWizard、PromptAgent、SAMMO、Opik、MLflow 纳入冻结原生矩阵。
