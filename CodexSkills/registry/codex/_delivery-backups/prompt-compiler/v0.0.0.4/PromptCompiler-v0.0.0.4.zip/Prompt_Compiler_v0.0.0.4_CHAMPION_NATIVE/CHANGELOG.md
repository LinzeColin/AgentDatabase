# Changelog

## v0.0.0.4 - 2026-08-03

- 将 GEPA、Promptfoo Optimize、AutoResearch Loop、MetaHarness Search 固定为四条独立原生路径。
- 将 Prompt Compiler Omni 固定为“Stage 1 四原生路径 + Stage 2 逐维差距合成”的两阶段总编排。
- 删除 AutoResearch、MetaHarness、Omni 的本地同名模拟函数及 GEPA/Promptfoo 兼容回退。
- Promptfoo 只从官方输出的精确 `Best prompt` 区段提取获胜提示词；支持官方选择未修改基线。
- 明确 Promptfoo 目标模型与候选建议模型的逻辑角色隔离，并记录身份来源。
- 新增官方 Git origin/入口校验、隔离 clone、候选路径 allowlist、执行前后 SHA-256 树快照和越界修改阻断。
- 新增原生输入胶囊，禁止向四条路径暴露最终测试集。
- 单元与集成测试由 49 项扩展至 58 项。

## v0.0.0.3 - 2026-08-02

- 将 GEPA、AutoResearch、MetaHarness、Promptfoo 固定为同层竞品 + 可路由执行器双角色。
- 新增严格逐维冠军核心、15 个内置维度、动态业务维度和满分并列例外。
- 将预算改为总量守恒的最低探测 + 弱项差距 + 能力先验自适应分配。
- 新增独立冠军证据文件、哈希复核、CI 逐维重读和事务式安装器。
