# Decisions

- Four independent native competitors remain visible even when their mechanisms are routed inside Omni.
- Omni is a two-stage orchestrator, not a fifth local optimizer.
- Missing native execution is `BLOCKED`, never silently replaced by a seed copy, local loop or compatible fallback.
- Official Promptfoo output is authoritative only for the exact final `Best prompt` section; Prompt Compiler independently evaluates that candidate.
- Target-model and suggestion-model roles are separate and auditable.
- Release requires first place against every required peer on every frozen dimension and overall; averages cannot compensate for a weak dimension.
- Evidence is scoped to the sealed data, versions, identities, budget, evaluator and repeats of that run; no permanent universal-superiority claim is pre-generated.
- Current offline QA proves package integrity and fail-closed behavior, not real-world champion status.
