# 需求 - 任务 - 测试 - 证据 - 制品

| 需求 | 任务 | 测试 / Oracle | 证据 | 制品 |
|---|---|---|---|---|
| 四竞品保持独立且同时可路由 | 双角色注册表 + Stage 1 四路径 | 缺任一路径或报告非 PASS 时 Omni 阻塞 | Omni 缺 Promptfoo 负向测试 | `COMPETITOR_REGISTRY.json`、`run_champion_synthesis` |
| AutoResearch 不使用本地同名模拟 | 官方/受控工作区、真实命令、隔离副本 | 候选必须实际变化；合同外文件不得变化 | allowlist 正反测试、静态函数不存在测试 | `native_engine_adapter.py`、`run_autoresearch_native_engine` |
| MetaHarness 不使用本地同名模拟 | 官方入口发现、真实命令、隔离副本 | 必须发现官方嵌套入口并生成候选 | 入口发现测试、越界修改测试 | `discover_meta_harness_entrypoint`、`run_meta_harness_native_engine` |
| Promptfoo 必须真实运行官方命令 | 固定官方 CLI 参数和输出合同 | 只接受精确 `Best prompt`；拒绝代码围栏和别名 | 精确提取、别名拒绝、基线获胜测试 | `run_promptfoo_optimizer_engine` |
| Promptfoo 建议模型与目标模型分角色 | 记录 target 与 `suggestionsProvider` 身份来源 | 角色合同完整；可选强制 Provider 身份不同 | 运行报告 `role_contract` | `infer_promptfoo_suggestions_identity` |
| GEPA 不允许兼容回退 | 只调用官方 `optimize_anything` | API 缺失、执行失败或无候选即阻塞 | 运行时静态扫描无回退调用 | `run_gepa_engine` |
| Omni 是两阶段总编排 | Stage 1 四原生候选；Stage 2 逐维单变更 | 四路径齐全后才合成；KEEP/REVERT 可归因 | 离线全链路测试与缺路径负向测试 | `run_champion_synthesis` |
| 任一冻结维度和总体都必须第一 | 严格逐维 Bootstrap 冠军门 | 每个 peer/dimension 仅允许严格第一或数学上限共同第一 | 缺维度、并列、竞品领先测试 | `champion_core.py` |
| 支持任意业务维度 | 自动发现、冻结、缺值阻断 | 新维度进入冻结清单；缺证据失败 | 项目附加维度正反测试 | `frozen_champion_dimensions` |
| 最终测试不可泄漏 | 原生输入胶囊不含最终集；候选名单冻结后开启 | 合同中无 `final_test`；封印变化阻断 | 输入合同和数据封印测试 | `native_input_contract`、`candidate_freeze.json` |
| 报告不可伪造 | 独立证据文件与 SHA 重读 | 篡改 `release_allowed` 不能放行 | CI 篡改测试 | `ci-gate` |
| 可安装即用 | 事务式安装、复验、备份和回滚 | 清洁安装、升级、幂等、卸载 | 三轮 QA，每轮 58 项测试 | `install.py`、一键脚本 |
