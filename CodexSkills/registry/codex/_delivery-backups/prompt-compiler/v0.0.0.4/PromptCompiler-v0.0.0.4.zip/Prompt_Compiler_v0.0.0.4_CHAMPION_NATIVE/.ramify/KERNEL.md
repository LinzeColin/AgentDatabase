# Context Kernel

## Canonical identity

- Project: `prompt-compiler`
- Product / Taskpack version: `v0.0.0.4`
- State: `SEALED_TASKPACK`
- Canonical state: `CANONICAL_STATE.json`
- Acceptance contract: `prompt-compiler/references/CHAMPION_CONTRACT.md`
- Baseline: user-supplied prior package; superseded by v0.0.0.4.

## Pursuing Goal

GEPA、Promptfoo optimize、AutoResearch loop、MetaHarness harness search 保持四条独立原生优化路径，同时也是可路由下层执行器；`prompt_compiler omni` 是先完整运行四条路径、再按逐维差距合成的两阶段总编排。只有 Prompt Compiler 在全部冻结维度和总体上均排名第一，并通过独立终审、回归、红队、证据完整性与发布门，才允许发布。

## Frozen decisions

- AutoResearch、MetaHarness、Omni 禁止本地同名模拟。
- GEPA、Promptfoo 禁止兼容回退。
- Promptfoo 只接受官方 CLI 最后一个精确 `Best prompt` 区段。
- Promptfoo 目标模型与候选建议模型是两个逻辑角色；身份分别记录。
- 原生工作区必须隔离运行，校验来源/入口，只允许声明路径变化，并保存执行前后树哈希。
- 原生输入不得包含 `final_test`；最终集仅在候选名单和竞品范围冻结后开启。
- 平均分不能抵消弱项；低于数学上限的并列不算第一。

## Evidence and verification

- Skill implementation: `prompt-compiler/`
- Unit/integration tests: `prompt-compiler/tests/`
- Three-pass QA: `QA/TEST_REPORT.json`
- Frozen verifier: `QA/VERIFIER_REPORT.md`
- Skill manifest: `prompt-compiler/MANIFEST.sha256`
- Package manifest: `PACKAGE_MANIFEST.sha256`
- Optimization summary: `OPTIMIZATION_SUMMARY.md` and `.pdf`

## Environment-bound unknowns

- Latest target repository state and applicable `AGENTS.md` at installation time.
- Authorized task/reflection/evaluator/final-judge identities and credentials.
- Verified AutoResearch and MetaHarness workspaces, commands and candidate artifacts.
- Real sealed datasets, business Oracle, budgets, latency and monetary-cost measurements.

## Next action

Build Agent performs only Stage 0 semantic reconcile, transactional installation, frozen verification, real environment binding, formal arena execution, evidence persistence, commit/push and backup. Any `BLOCKED`, `NOT_PROVEN`, hash mismatch or non-first dimension stops release; the Agent reports evidence without redesigning the Skill.
