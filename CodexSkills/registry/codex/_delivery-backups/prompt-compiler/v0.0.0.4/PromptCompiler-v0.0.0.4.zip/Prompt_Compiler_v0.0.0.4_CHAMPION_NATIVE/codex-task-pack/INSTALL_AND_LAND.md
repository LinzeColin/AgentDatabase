# Codex Last-Mile Task Pack

## Pursuing Goal

将本包 `prompt-compiler/` 原样语义安装到目标 Skill Registry，运行冻结验证；仅使用真实环境完成原生依赖、真实模型/凭据、同场冠军证据、commit、push 和备份，不重新研究、重新设计或扩展验收。

## Stage 0｜移动仓语义对账

1. `git fetch origin`，读取最新 main、AGENTS、CONTRIBUTING 和目标目录。
2. 将每项分类为 `satisfied | apply | adapt | equivalent | conflict | blocked | obsolete`。
3. 保留更新、更好的上游等价实现；不得用旧整树覆盖未来更高版本。
4. 只有身份、版本倒退、安全边界或 Acceptance 冲突才阻塞。

## Stage 1｜安装

```bash
python3 START_HERE.py install --scope agentdatabase --repo /absolute/path/to/AgentDatabase
```

Expected：JSON/Human 状态为 `INSTALLED`，自检 `PASS`，旧版本存在完整备份。

## Stage 2｜冻结验证

```bash
python3 QA/run_all.py --verify-only
python3 install.py verify --scope agentdatabase --repo /absolute/path/to/AgentDatabase --json
```

Stop Condition：任何哈希、版本、58 项测试、双角色注册、安装或冠军负向测试失败。不得绕过。

## Stage 3｜真实环境

```bash
python3 install.py install --scope agentdatabase --repo /absolute/path/to/AgentDatabase --with-runtime --json
python3 /absolute/path/to/installed/prompt-compiler/scripts/prompt_compiler.py doctor --probe
```

真实凭据、独立模型身份、真实数据和外部原生竞品只在授权环境配置。任何缺失记录为 BLOCKED，不得伪造 PASS。

## Stage 4｜落库

仅在 Stage 1-3 满足冻结条件后执行 `git add`、`git diff --check`、commit、push main 和备份。不得创建开放 PR/branch，不得修改版本号或冠军合同。

## Rollback

安装收据包含备份位置；失败由安装器自动恢复。落库失败时保留工作树和日志，不强推。
