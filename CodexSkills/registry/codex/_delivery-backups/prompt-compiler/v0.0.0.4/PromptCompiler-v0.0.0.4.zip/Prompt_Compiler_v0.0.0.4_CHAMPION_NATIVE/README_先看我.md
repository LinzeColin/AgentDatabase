# Prompt Compiler v0.0.0.4｜全维冠军原生版

## 一键安装

- macOS：双击 `INSTALL_TO_CODEX.command`
- Windows：右键运行 `INSTALL_TO_CODEX.ps1`
- Linux：执行 `bash INSTALL.sh`
- 通用方式：`python3 START_HERE.py install`

安装器会先核对 SHA-256 清单、运行离线自检，再进行事务式安装。已有版本会完整备份；安装失败会自动回滚。

安装后在 Codex、Claude Code 或兼容 Agent 中输入：

```text
$prompt-compiler
优化下面的原始工件。GEPA、Promptfoo optimize、AutoResearch loop、MetaHarness harness search 是四条独立原生优化路径；prompt_compiler omni 是两阶段总编排。原文不可覆盖。只有 Prompt Compiler 在每个冻结维度和总体上均排名第一，且独立终审、回归、红队和发布门全部通过，才允许发布。

【原始工件】
在这里粘贴
```

## v0.0.0.4 的关键变化

1. **四条独立路径均为原生路径**：GEPA 调用官方 Python API；Promptfoo 调用官方 `promptfoo optimize`；AutoResearch 和 MetaHarness 在隔离工作区中运行真实外部命令。任何一条缺失或失败，Omni 立即阻塞。
2. **不再存在本地同名模拟或兼容回退**：运行时已删除 `run_local_engine` 和旧 Omni 本地交叉函数。
3. **Promptfoo 获胜提示词只从官方 `Best prompt` 区段提取**：不接受通用代码围栏、`Optimized prompt` 别名或本地候选替代；官方判定基线最佳时允许原样保留基线。
4. **Promptfoo 角色隔离**：被优化的目标模型与 Promptfoo 的候选建议模型是不同逻辑角色，报告分别记录身份来源；可按项目要求强制 Provider 身份不同。
5. **AutoResearch 与 MetaHarness 真实工作区隔离**：校验官方 Git origin/入口，复制到隔离工作区，执行前后做 SHA-256 树快照，只允许修改声明的候选路径；越界修改立即失败关闭。
6. **Omni 两阶段总编排**：第一阶段收集四条原生路径的独立候选和证据；第二阶段按逐维差距进行单变更合成、独立验证并 KEEP/REVERT。
7. **冠军发布门没有降级**：缺竞品、缺维度、低于数学上限的并列、置信区间未分离、数据泄漏、证据哈希不一致，均不能发布。

## 正式运行需要什么

基础安装和离线自检不需要模型费用。正式同场竞技需要：真实任务数据、任务模型、不同身份的独立终审模型、官方 GEPA/Promptfoo 运行环境，以及 AutoResearch/MetaHarness 的官方或可验证派生工作区与真实执行命令。Skill 会明确报告缺项，不会用模拟结果冒充原生结果。

## 证据边界

本包能够保证的是：**没有“Prompt Compiler 对全部必选竞品、每个冻结维度和总体均第一”的真实封印证据，就绝不输出冠军通过。** 任何冠军结论只覆盖该次数据封印、模型身份、工具版本、总预算、评分器、重复次数和竞品注册表；不能预先伪造脱离条件的永久第一。
