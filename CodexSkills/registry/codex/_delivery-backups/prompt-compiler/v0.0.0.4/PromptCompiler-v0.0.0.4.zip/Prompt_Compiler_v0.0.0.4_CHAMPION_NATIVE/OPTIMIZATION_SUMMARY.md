# Prompt Compiler v0.0.0.4 优化总结

## 结论

v0.0.0.4 将五条路径冻结为明确、不可混淆的结构：

- `GEPA`：独立原生路径；只调用官方 `gepa.optimize_anything`。
- `Promptfoo optimize`：独立原生路径；只调用官方 CLI，并从最终 `Best prompt` 区段提取获胜提示词。
- `AutoResearch loop`：独立原生路径；在可验证的官方/受控 Git 工作区隔离副本中运行真实命令。
- `MetaHarness harness search`：独立原生路径；发现并运行官方参考入口或可验证派生入口。
- `prompt_compiler omni`：两阶段总编排；先收集四条独立原生路径，再按逐维差距做受控合成。

四条独立路径仍然是必须同场击败的竞品，同时也是 Omni 可路由的下层执行器。任何路径缺跑、阻塞或没有候选，Omni 都不能使用本地模拟补位，也不能形成冠军候选。

## 从 v0.0.0.3 到 v0.0.0.4

| 维度 | 旧风险 | v0.0.0.4 机制 | 可核验结果 |
|---|---|---|---|
| AutoResearch | 本地方法兼容循环可能被误认为官方路径 | 真实外部命令 + 官方 origin/合同文件校验 + 隔离工作区 | 无工作区或命令时 `BLOCKED` |
| MetaHarness | 本地结构模拟可能掩盖真实 Harness 行为 | 官方嵌套入口发现 + 隔离运行 + 候选制品路径合同 | 未发现入口或候选未变化时 `BLOCKED` |
| Promptfoo optimize | 泛化解析可能误取代码围栏或非最终候选 | 只接受精确 `Best prompt` 区段；官方 CLI 失败不回退 | 解析边界有正反测试 |
| Promptfoo 角色 | 建议模型与目标模型容易混为同一角色 | 目标角色与 `suggestionsProvider` 角色分别记录 | 可选强制 Provider 身份不同 |
| GEPA | 官方执行失败后可能进入兼容回退 | 只运行官方 API；无候选即阻塞 | 不再存在 GEPA 本地回退 |
| Omni | 单次本地交叉可能被称为总编排 | Stage 1 四原生路径 + Stage 2 逐维差距合成 | 缺任一路径则 Stage 2 不运行 |
| 工作区安全 | 外部 Agent 可能改写合同外文件 | 执行前后文件树 SHA-256；候选路径 allowlist | 越界修改触发 `NATIVE_FORBIDDEN_MUTATION` |
| 最终集隔离 | 外部路径可能接触盲测数据 | 原生输入胶囊只含种子、训练、验证、目标和要求 | 测试验证无 `final_test` 字段 |
| 本地模拟残留 | 旧函数可被未来代码误调用 | 删除 `run_local_engine` 与 `run_omni_crossover` | 静态测试断言函数不存在 |

## 新增机制

### 1. 原生工作区执行证据

每个 AutoResearch/MetaHarness 运行记录：来源工作区、Git origin、必需文件、允许修改路径、执行命令、返回码、标准输出/错误输出、执行前后树哈希和实际变更路径。密钥模式自动脱敏。

### 2. Promptfoo 精确获胜候选合同

Promptfoo Optimize 必须真实执行官方命令；解析器从最后一个精确 `Best prompt` 标题后开始读取，并在官方等号分隔线前停止。`Optimized prompt`、Markdown 围栏和任意 JSON 别名都不能替代官方最终区段。

### 3. 两阶段 Omni

第一阶段要求 GEPA、AutoResearch、MetaHarness、Promptfoo 四条路径的报告均为 `PASS` 且各有候选。第二阶段从所有原生候选中建立 Portfolio Baseline，计算逐维差距，每轮只修一个最弱维度，独立验证后采用稳健排序键决定 KEEP/REVERT。

### 4. 全维冠军门

内置 15 个维度：`overall`、`worst_case`、`weakest_slice`、`stability`、`correctness`、`coverage`、`executability`、`security`、`efficiency`、`oracle`、`hard_safety`、`regression`、`redteam`、`cost_efficiency`、`latency_efficiency`。项目评分器发现的合法附加维度也会在最终集打开前冻结。任一维度缺证据或不第一，均不能发布。

## 关闭的 P0 / P1

| 等级 | Finding | 状态与证据 |
|---|---|---|
| P0 | AutoResearch/MetaHarness 本地同名模拟 | 已删除；58 项测试包含静态不存在断言 |
| P0 | Omni 在四路径不完整时继续 | 已关闭；缺任一路径返回 `BLOCKED`，Stage 2 为 `NOT_RUN` |
| P0 | Promptfoo 非官方文本被误当获胜提示词 | 已关闭；精确解析与拒绝别名测试 |
| P0 | 外部路径越权改写合同文件 | 已关闭；树快照、allowlist、越界负向测试 |
| P0 | 失败后用兼容候选伪装原生成功 | 已关闭；四路径均无本地回退 |
| P1 | Promptfoo 建议/目标模型角色混淆 | 已关闭；双角色证据与可选身份强制门 |
| P1 | 最终测试通过原生输入胶囊泄漏 | 已关闭；输入合同测试不含最终集 |
| P1 | 官方判定基线最佳时被强行制造改写 | 已关闭；允许基线作为真实 Promptfoo finalist |

## 验收结果

- 离线单元与集成测试：**58 项全部通过**。
- 新增负向测试覆盖：Promptfoo 错误区段拒绝、工作区越界写入、Omni 缺路径、最终集不进入原生输入、旧本地模拟函数不存在。
- 安装链：清洁安装、完整性复验、幂等安装、旧版升级备份、卸载回滚均由三轮 QA 执行。
- 原生外部实测边界：本包验证了适配器、隔离合同和失败关闭；真实模型、真实凭据、真实业务数据及外部官方工作区仍需在授权环境运行，不能由离线夹具替代。

## Developer Burden Delta

Build Agent 不再需要研究五条路径的边界、重写适配器、判断是否允许回退、设计 Promptfoo 解析、设计工作区隔离、补负向测试或定义 Omni 阶段。只剩环境绑定动作：在最新目标仓做语义对账、安装本包、配置真实凭据/工作区/命令、运行冻结竞技、保存证据并 commit/push/备份。
