$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:PYTHONDONTWRITEBYTECODE = "1"
python -B START_HERE.py install
Write-Host "安装完成。若 Codex 中未出现新 Skill，请重启 Codex。"
