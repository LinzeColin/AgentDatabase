# 公开仓库访问记录

核验日期：2026-08-02。GitHub 公开资料显示 LinzeColin 当前有 7 个 Public 仓库：AgentDatabase、MetaDatabase、KMOS、LinzeHomeHub、CodexProject、Archive、NotionStudyProject。本任务只对与 Prompt Compiler 直接相关的 AgentDatabase Skill Registry、Teleiosis、Persona Distiller Group、Verifier、Context Kernel 做深入读取；其他仓库仅核验公开索引和定位，不把无关项目内容污染当前范围。

GitHub Private 仓库和未授权内容不可访问，本包没有声称已核验。容器网络无法直接 clone，因此以 Web 读取的公开 GitHub 页面和用户上传的 v0.0.0.2 为依据。
