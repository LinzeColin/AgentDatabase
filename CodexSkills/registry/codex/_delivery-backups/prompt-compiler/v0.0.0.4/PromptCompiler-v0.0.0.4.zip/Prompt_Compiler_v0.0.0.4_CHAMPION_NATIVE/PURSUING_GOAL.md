# Pursuing Goal

在不改变原始目标、硬约束、权限、数据边界和输出合同的前提下，让 GEPA、AutoResearch、MetaHarness、Promptfoo 以及显式启用的扩展竞品同时保留“同层对手”和“可路由下层执行器”身份；通过总预算守恒、自适应路由、逐维差距修复、单变更 KEEP/REVERT、独立盲测、回归、红队和证据哈希门禁，使 Prompt Compiler 只有在每个冻结维度与总体均排名第一时才允许发布。
