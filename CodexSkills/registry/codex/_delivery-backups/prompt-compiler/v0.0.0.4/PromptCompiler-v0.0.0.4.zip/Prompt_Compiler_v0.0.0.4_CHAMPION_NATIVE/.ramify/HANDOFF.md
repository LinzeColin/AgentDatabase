# Handoff

v0.0.0.4 is the frozen installable Candidate. Do not research, rename, broaden scope, relax the champion rule, substitute local simulations, or overwrite a newer equivalent upstream implementation.

Execution order:

1. Fetch latest target `main`; read applicable governance; classify each packaged change as `satisfied | apply | adapt | equivalent | conflict | blocked | obsolete`.
2. Install transactionally with `START_HERE.py`; preserve the generated backup.
3. Run `QA/run_all.py --verify-only` and installer verification. Stop on any failure.
4. Bind real model identities, GEPA/Promptfoo environment, AutoResearch/MetaHarness workspaces and commands, and sealed business data.
5. Run the formal five-path arena. Release only after strict per-peer/per-dimension and overall champion evidence passes.
6. Persist evidence, then commit, push and back up. Deployment anomalies are recorded and returned to Preparation Agent; Build Agent does not redesign.
