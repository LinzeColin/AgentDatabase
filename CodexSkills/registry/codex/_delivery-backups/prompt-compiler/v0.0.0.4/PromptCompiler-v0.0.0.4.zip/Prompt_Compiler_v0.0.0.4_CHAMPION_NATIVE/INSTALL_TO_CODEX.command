#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
python3 -B START_HERE.py install
printf '\n安装窗口可关闭。若 Codex 中未出现新 Skill，请重启 Codex。\n'
