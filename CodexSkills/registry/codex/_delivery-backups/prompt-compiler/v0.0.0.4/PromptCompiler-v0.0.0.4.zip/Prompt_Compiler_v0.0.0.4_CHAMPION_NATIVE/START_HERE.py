#!/usr/bin/env python3
"""One-click entry point: defaults to safe offline installation."""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
args = sys.argv[1:] or ["install"]
raise SystemExit(subprocess.call([sys.executable, "-B", str(ROOT / "install.py"), *args]))
