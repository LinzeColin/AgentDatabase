#!/usr/bin/env python3
"""Prompt Compiler v0.0.0.4 transactional installer."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parent
SOURCE_SKILL = PACKAGE_ROOT / "prompt-compiler"
SKILL_NAME = "prompt-compiler"
VERSION = "v0.0.0.4"
RUNNER = Path("scripts/prompt_compiler.py")
SUPPORTED_PYTHON = ((3, 10), (3, 15))


class InstallError(RuntimeError):
    pass


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clean_cache(root: Path) -> None:
    if not root.exists():
        return
    for path in sorted(root.rglob("__pycache__"), reverse=True):
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
    for pattern in ("*.pyc", "*.pyo"):
        for path in root.rglob(pattern):
            if path.is_file() or path.is_symlink():
                path.unlink(missing_ok=True)


def load_manifest(root: Path) -> list[tuple[str, str]]:
    manifest = root / "MANIFEST.sha256"
    if not manifest.is_file() or manifest.is_symlink():
        raise InstallError(f"缺少有效完整性清单：{manifest}")
    entries: list[tuple[str, str]] = []
    for line_no, raw in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            raise InstallError(f"完整性清单第 {line_no} 行无效")
        expected, relative = parts[0].lower(), parts[1].lstrip("*").strip()
        if len(expected) != 64 or any(ch not in "0123456789abcdef" for ch in expected):
            raise InstallError(f"完整性清单第 {line_no} 行哈希无效")
        if not relative or relative.startswith("/") or ".." in Path(relative).parts:
            raise InstallError(f"完整性清单第 {line_no} 行路径无效")
        entries.append((expected, relative))
    if not entries:
        raise InstallError("完整性清单为空")
    return entries


def verify_tree(root: Path) -> dict[str, Any]:
    clean_cache(root)
    if root.is_symlink() or not root.is_dir():
        raise InstallError(f"Skill 根目录无效：{root}")
    symlinks = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_symlink())
    if symlinks:
        raise InstallError(f"Skill 内不允许符号链接：{symlinks}")
    if not (root / "SKILL.md").is_file() or not (root / RUNNER).is_file():
        raise InstallError("Skill 缺少 SKILL.md 或主运行脚本")
    header = (root / "SKILL.md").read_text(encoding="utf-8")[:5000]
    if f"name: {SKILL_NAME}" not in header or VERSION not in header:
        raise InstallError("SKILL.md 的名称或版本不匹配")
    if (root / "VERSION").read_text(encoding="utf-8").strip() != VERSION:
        raise InstallError("VERSION 不匹配")
    entries = load_manifest(root)
    listed = {relative for _, relative in entries}
    actual = {
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_file() and not p.is_symlink()
    }
    permitted_unlisted = {"MANIFEST.sha256", "INSTALL_RECEIPT.json"}
    unexpected = sorted(actual - listed - permitted_unlisted)
    missing = sorted(listed - actual)
    if unexpected or missing:
        raise InstallError(f"Skill 文件树与清单不一致：unexpected={unexpected}, missing={missing}")
    resolved_root = root.resolve()
    for expected, relative in entries:
        path = root / relative
        try:
            path.resolve().relative_to(resolved_root)
        except ValueError as exc:
            raise InstallError(f"检测到路径穿越：{relative}") from exc
        if not path.is_file() or path.is_symlink():
            raise InstallError(f"清单文件无效：{relative}")
        if digest(path) != expected:
            raise InstallError(f"哈希不一致：{relative}")
    return {
        "status": "PASS",
        "skill": SKILL_NAME,
        "version": VERSION,
        "checked_files": len(entries),
        "manifest_sha256": digest(root / "MANIFEST.sha256"),
    }


def run_self_test(root: Path) -> dict[str, Any]:
    clean_cache(root)
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"}
    completed = subprocess.run(
        [sys.executable, "-B", str(root / RUNNER), "self-test"],
        text=True,
        capture_output=True,
        timeout=240,
        env=env,
    )
    clean_cache(root)
    if completed.returncode != 0:
        raise InstallError("离线自检失败：" + (completed.stderr or completed.stdout)[-5000:])
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise InstallError("离线自检未返回有效 JSON") from exc
    if payload.get("status") != "PASS":
        raise InstallError(f"离线自检未通过：{payload}")
    return payload


def resolve_target(args: argparse.Namespace) -> Path:
    if args.target:
        return Path(args.target).expanduser().resolve()
    home = Path.home()
    if args.scope == "user":
        return (home / ".agents" / "skills" / SKILL_NAME).resolve()
    if args.scope == "claude":
        return (home / ".claude" / "skills" / SKILL_NAME).resolve()
    if args.scope == "legacy-codex":
        return (home / ".codex" / "skills" / SKILL_NAME).resolve()
    if args.scope in {"repo", "agentdatabase"}:
        if not args.repo:
            raise InstallError(f"--scope {args.scope} 必须提供 --repo")
        repo = Path(args.repo).expanduser().resolve()
        if not repo.is_dir():
            raise InstallError(f"仓库目录不存在：{repo}")
        return (
            repo / ".agents" / "skills" / SKILL_NAME
            if args.scope == "repo"
            else repo / "CodexSkills" / "registry" / "codex" / SKILL_NAME
        )
    raise InstallError(f"未知安装范围：{args.scope}")


def safe_remove(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink(missing_ok=True)
    elif path.exists():
        shutil.rmtree(path)


def same_installed_version(target: Path) -> bool:
    try:
        source = verify_tree(SOURCE_SKILL.resolve())
        installed = verify_tree(target)
        return source["manifest_sha256"] == installed["manifest_sha256"]
    except (InstallError, OSError):
        return False


def run_optional(command: list[str], *, timeout: int) -> dict[str, Any]:
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"}
    completed = subprocess.run(command, text=True, capture_output=True, timeout=timeout, env=env)
    raw = completed.stdout.strip()
    details: Any = raw
    if raw:
        try:
            details = json.loads(raw)
        except json.JSONDecodeError:
            details = raw[-5000:]
    return {
        "status": "PASS" if completed.returncode == 0 else "BLOCKED",
        "returncode": completed.returncode,
        "details": details,
        "stderr": completed.stderr[-5000:],
    }


def install(args: argparse.Namespace) -> dict[str, Any]:
    current = sys.version_info[:2]
    if not (SUPPORTED_PYTHON[0] <= current < SUPPORTED_PYTHON[1]):
        raise InstallError("需要 Python 3.10-3.14")
    source = SOURCE_SKILL.resolve()
    source_verification = verify_tree(source)
    source_self_test = run_self_test(source)
    target = resolve_target(args)
    try:
        target.relative_to(source)
    except ValueError:
        pass
    else:
        raise InstallError("安装目标不能位于源 Skill 内部")

    result: dict[str, Any] = {
        "status": "DRY_RUN" if args.dry_run else "INSTALLED",
        "skill": SKILL_NAME,
        "version": VERSION,
        "source": str(source),
        "target": str(target),
        "source_verification": source_verification,
        "source_self_test": source_self_test,
        "backup": None,
        "installed_at": now(),
        "runtime": {"requested": bool(args.with_runtime), "status": "NOT_REQUESTED"},
        "external_acceptance": {"requested": bool(args.with_external_acceptance), "status": "NOT_REQUESTED"},
    }
    if args.dry_run:
        return result
    if target.exists() and same_installed_version(target):
        result["status"] = "ALREADY_INSTALLED"
        result["installed_verification"] = verify_tree(target)
        result["installed_self_test"] = run_self_test(target)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        backup_root = target.parent / ".backups"
        backup_root.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = backup_root / f"{SKILL_NAME}-{stamp}-{uuid.uuid4().hex[:8]}"
        stage = target.parent / f".{SKILL_NAME}.staging-{uuid.uuid4().hex}"
        prior_moved = False
        try:
            if target.exists() or target.is_symlink():
                os.replace(target, backup)
                prior_moved = True
                result["backup"] = str(backup)
            shutil.copytree(source, stage, symlinks=False)
            clean_cache(stage)
            for script in (stage / "scripts").glob("*.py"):
                script.chmod(script.stat().st_mode | 0o111)
            verify_tree(stage)
            run_self_test(stage)
            os.replace(stage, target)
            receipt = {
                "schema_version": "1.0",
                "skill": SKILL_NAME,
                "version": VERSION,
                "installed_at": now(),
                "target": str(target),
                "source_package": str(PACKAGE_ROOT),
                "source_manifest_sha256": digest(source / "MANIFEST.sha256"),
                "backup": str(backup) if prior_moved else None,
                "rollback": "replace target with backup after removing failed target",
            }
            (target / "INSTALL_RECEIPT.json").write_text(
                json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            result["installed_verification"] = verify_tree(target)
            result["installed_self_test"] = run_self_test(target)
        except Exception:
            safe_remove(stage)
            safe_remove(target)
            if prior_moved and backup.exists():
                os.replace(backup, target)
            raise

    runner = target / RUNNER
    if args.with_runtime:
        command = [sys.executable, "-B", str(runner), "bootstrap"]
        if args.with_litellm:
            command.append("--with-litellm")
        result["runtime"] = {"requested": True, **run_optional(command, timeout=args.runtime_timeout)}
        if result["runtime"]["status"] != "PASS":
            result["status"] = "INSTALLED_RUNTIME_BLOCKED"
            return result
    if args.with_external_acceptance:
        result["external_acceptance"] = {
            "requested": True,
            **run_optional(
                [sys.executable, "-B", str(runner), "external-acceptance"],
                timeout=args.runtime_timeout,
            ),
        }
        if result["external_acceptance"]["status"] != "PASS":
            result["status"] = "INSTALLED_EXTERNAL_BLOCKED"
    clean_cache(target)
    return result


def verify_installed(args: argparse.Namespace) -> dict[str, Any]:
    target = resolve_target(args)
    return {
        "status": "PASS",
        "target": str(target),
        "verification": verify_tree(target),
        "self_test": run_self_test(target),
    }


def uninstall(args: argparse.Namespace) -> dict[str, Any]:
    target = resolve_target(args)
    if not target.exists() and not target.is_symlink():
        return {"status": "NOT_INSTALLED", "target": str(target)}
    if not args.yes:
        raise InstallError("卸载必须显式使用 --yes")
    backup_root = target.parent / ".backups"
    backup_root.mkdir(parents=True, exist_ok=True)
    backup = backup_root / f"{SKILL_NAME}-uninstall-{dt.datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
    os.replace(target, backup)
    return {"status": "UNINSTALLED", "target": str(target), "backup": str(backup)}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="安装 Prompt Compiler v0.0.0.4 全维冠军版")
    parser.add_argument("command", nargs="?", choices=["install", "verify", "uninstall"], default="install")
    parser.add_argument("--scope", choices=["user", "repo", "agentdatabase", "claude", "legacy-codex"], default="user")
    parser.add_argument("--repo", help="repo/agentdatabase 范围的仓库根目录")
    parser.add_argument("--target", help="精确安装目录，覆盖 scope")
    parser.add_argument("--with-runtime", action="store_true", help="联网安装固定版本 GEPA 与 Promptfoo 隔离运行环境")
    parser.add_argument("--with-litellm", action="store_true", help="随运行环境安装可选 LiteLLM")
    parser.add_argument("--with-external-acceptance", action="store_true", help="安装后运行真实外部探针；需要授权环境")
    parser.add_argument("--runtime-timeout", type=int, default=3600)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--yes", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser


STATUS_ZH = {
    "INSTALLED": "安装完成",
    "ALREADY_INSTALLED": "已是相同版本，复验通过",
    "PASS": "通过",
    "DRY_RUN": "仅演练，未写入",
    "UNINSTALLED": "已卸载并备份",
    "NOT_INSTALLED": "尚未安装",
    "INSTALLED_RUNTIME_BLOCKED": "Skill 已安装；联网运行环境被阻塞",
    "INSTALLED_EXTERNAL_BLOCKED": "Skill 已安装；真实外部验收被阻塞",
}


def print_human(result: dict[str, Any]) -> None:
    status = str(result.get("status", ""))
    print(f"\nPrompt Compiler：{STATUS_ZH.get(status, status)}")
    if result.get("target"):
        print(f"安装位置：{result['target']}")
    if result.get("backup"):
        print(f"旧版本完整备份：{result['backup']}")
    if status in {"INSTALLED", "ALREADY_INSTALLED"}:
        print("使用：在 Codex 输入 $prompt-compiler，然后粘贴待优化内容。")
        print("新 Skill 未出现时重启 Codex。")
    elif status.startswith("INSTALLED_"):
        print("基础 Skill 已可使用；上方阻塞只涉及真实外部运行环境，不会回滚已通过的离线安装。")


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "install":
            result = install(args)
        elif args.command == "verify":
            result = verify_installed(args)
        else:
            result = uninstall(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) if args.json else "", end="") if args.json else print_human(result)
        if str(result.get("status", "")).startswith("INSTALLED_"):
            raise SystemExit(2)
    except (InstallError, subprocess.TimeoutExpired, OSError, json.JSONDecodeError) as exc:
        payload = {"status": "BLOCKED", "message": str(exc), "type": type(exc).__name__}
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(f"\n安装被阻止：{exc}", file=sys.stderr)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
