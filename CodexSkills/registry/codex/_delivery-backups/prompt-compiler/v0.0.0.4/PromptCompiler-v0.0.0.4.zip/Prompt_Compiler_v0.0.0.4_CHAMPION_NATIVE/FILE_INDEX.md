# 文件目录与使用优先级

| 优先级 | 文件/目录 | 作用 |
|---:|---|---|
| 1 | `README_先看我.md` | 零技术门槛安装与使用入口 |
| 1 | `INSTALL_TO_CODEX.command` / `.ps1` / `INSTALL.sh` | macOS、Windows、Linux 一键安装 |
| 1 | `prompt-compiler/` | 可直接安装的完整 v0.0.0.4 Skill |
| 2 | `OPTIMIZATION_SUMMARY.md` / `.pdf` | 原生五路径优化总结、证据和风险边界 |
| 2 | `QA/` | 三轮 QA、Verifier、十视角、专家复审和测试计划 |
| 2 | `CANONICAL_STATE.json` | 当前版本、范围、事实、未知和发布规则的唯一状态 |
| 2 | `TASK_DAG.json` / `TRACEABILITY_MATRIX.md` | 需求到任务、测试、证据和制品的追踪 |
| 3 | `ARCHITECTURE.mmd` / `DATA_FLOW.mmd` | 五路径、隔离工作区、数据和发布门架构 |
| 3 | `ROADMAP.md` / `PURSUING_GOAL.md` | 当前路线与不偏移目标 |
| 3 | `codex-task-pack/` | Build Agent 最后一公里说明 |
| 3 | `.ramify/` | 跨轮治理、决策与交接 |
| 4 | `PACKAGE_MANIFEST.sha256` / `PACKAGE_RECEIPT.json` | 最终包完整性与验收收据 |
