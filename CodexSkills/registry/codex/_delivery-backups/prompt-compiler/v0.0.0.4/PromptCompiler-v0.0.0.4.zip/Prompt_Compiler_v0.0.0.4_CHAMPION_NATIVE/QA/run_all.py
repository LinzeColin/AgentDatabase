#!/usr/bin/env python3
"""Three-pass deterministic QA and read-only final verifier."""
from __future__ import annotations

import argparse
import ast
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "prompt-compiler"
RUNNER = SKILL / "scripts" / "prompt_compiler.py"
INSTALLER = ROOT / "install.py"
REPORT_JSON = ROOT / "QA" / "TEST_REPORT.json"
REPORT_MD = ROOT / "QA" / "TEST_REPORT.md"
VERIFIER_MD = ROOT / "QA" / "VERIFIER_REPORT.md"
PY = sys.executable
VERSION = "v0.0.0.4"
DYNAMIC_REPORTS = {"QA/TEST_REPORT.json", "QA/TEST_REPORT.md", "QA/VERIFIER_REPORT.md"}


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clean_cache(root: Path) -> None:
    for path in sorted(root.rglob("__pycache__"), reverse=True):
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
    for pattern in ("*.pyc", "*.pyo"):
        for path in root.rglob(pattern):
            if path.is_file() or path.is_symlink():
                path.unlink(missing_ok=True)


def cache_paths(root: Path) -> list[str]:
    return sorted(
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.name == "__pycache__" or p.suffix in {".pyc", ".pyo"}
    )


def run(command: list[str], *, cwd: Path = ROOT, timeout: int = 360) -> dict[str, Any]:
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"}
    completed = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=timeout, env=env)
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout[-16000:],
        "stderr": completed.stderr[-16000:],
    }


def parse_manifest(root: Path, name: str) -> dict[str, str]:
    path = root / name
    if not path.is_file() or path.is_symlink():
        raise AssertionError(f"缺少清单：{path}")
    entries: dict[str, str] = {}
    for no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            raise AssertionError(f"{name} 第 {no} 行格式错误")
        expected, relative = parts[0].lower(), parts[1].lstrip("*").strip()
        if len(expected) != 64 or any(ch not in "0123456789abcdef" for ch in expected):
            raise AssertionError(f"{name} 第 {no} 行哈希错误")
        if not relative or relative.startswith("/") or ".." in Path(relative).parts:
            raise AssertionError(f"{name} 第 {no} 行路径错误")
        entries[relative] = expected
    if not entries:
        raise AssertionError(f"{name} 为空")
    return entries


def check_manifest(root: Path, name: str, *, package: bool = False) -> dict[str, Any]:
    entries = parse_manifest(root, name)
    for relative, expected in entries.items():
        path = root / relative
        if not path.is_file() or path.is_symlink():
            raise AssertionError(f"清单文件缺失或为符号链接：{relative}")
        if sha256(path) != expected:
            raise AssertionError(f"清单哈希不一致：{relative}")
    actual = {
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_file() and not p.is_symlink()
    }
    if package:
        actual -= {name, "PACKAGE_RECEIPT.json"}
    else:
        actual -= {name, "INSTALL_RECEIPT.json"}
    unexpected = sorted(actual - set(entries))
    missing = sorted(set(entries) - actual)
    if unexpected or missing:
        raise AssertionError(f"清单与文件树不一致：unexpected={unexpected}, missing={missing}")
    return {"entries": len(entries), "manifest_sha256": sha256(root / name)}


def check_dag() -> dict[str, Any]:
    payload = json.loads((ROOT / "TASK_DAG.json").read_text(encoding="utf-8"))
    tasks = payload.get("tasks", [])
    by_id = {str(item["id"]): item for item in tasks}
    if len(by_id) != len(tasks):
        raise AssertionError("Task DAG id 重复")
    for item in tasks:
        for dep in item.get("depends_on", []):
            if dep not in by_id:
                raise AssertionError(f"Task DAG 缺依赖：{item['id']} -> {dep}")
    visiting: set[str] = set(); visited: set[str] = set()
    def visit(node: str) -> None:
        if node in visiting:
            raise AssertionError(f"Task DAG 有环：{node}")
        if node in visited:
            return
        visiting.add(node)
        for dep in by_id[node].get("depends_on", []): visit(dep)
        visiting.remove(node); visited.add(node)
    for node in by_id: visit(node)
    isolated = [node for node, item in by_id.items() if not item.get("depends_on") and node != "T0"]
    if isolated:
        raise AssertionError(f"存在孤立起点：{isolated}")
    return {"tasks": len(tasks), "acyclic": True, "missing_dependencies": 0}


def static_checks(*, require_package_manifest: bool) -> dict[str, Any]:
    clean_cache(ROOT)
    symlinks = [p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_symlink()]
    if symlinks:
        raise AssertionError(f"任务包不允许符号链接：{symlinks}")
    if cache_paths(ROOT):
        raise AssertionError("任务包含 Python 缓存")

    required = [
        "README_先看我.md", "OPTIMIZATION_SUMMARY.md", "OPTIMIZATION_SUMMARY.pdf",
        "PURSUING_GOAL.md", "ROADMAP.md", "CANONICAL_STATE.json", "TASK_DAG.json",
        "ARCHITECTURE.mmd", "DATA_FLOW.mmd", "install.py", "START_HERE.py",
        "prompt-compiler/SKILL.md", "prompt-compiler/scripts/champion_core.py",
        "prompt-compiler/references/COMPETITOR_REGISTRY.json",
    ]
    missing = [item for item in required if not (ROOT / item).is_file()]
    if missing:
        raise AssertionError(f"缺少必要交付物：{missing}")

    py_files = sorted(ROOT.rglob("*.py"))
    for path in py_files:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    json_files = sorted(ROOT.rglob("*.json"))
    for path in json_files:
        json.loads(path.read_text(encoding="utf-8"))

    yaml_files = sorted([*ROOT.rglob("*.yaml"), *ROOT.rglob("*.yml")])
    try:
        import yaml  # type: ignore
    except Exception:
        yaml = None
    if yaml:
        for path in yaml_files:
            yaml.safe_load(path.read_text(encoding="utf-8"))
    else:
        for path in yaml_files:
            if ":" not in path.read_text(encoding="utf-8"):
                raise AssertionError(f"YAML 基础结构无效：{path}")

    for shell in sorted([*ROOT.rglob("*.sh"), *ROOT.rglob("*.command")]):
        checked = run(["bash", "-n", str(shell)], timeout=30)
        if checked["returncode"] != 0:
            raise AssertionError(f"Shell 语法错误：{shell}: {checked}")

    unresolved_words = ["TO" + "DO", "T" + "BD", "FIX" + "ME"]
    marker_re = re.compile(r"(?i)(?<![A-Za-z])(?:" + "|".join(unresolved_words) + r")(?![A-Za-z])")
    marker_hits: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".pdf", ".zip", ".png", ".jpg", ".jpeg"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if marker_re.search(text):
            marker_hits.append(path.relative_to(ROOT).as_posix())
    if marker_hits:
        raise AssertionError(f"存在未解决占位标记：{marker_hits}")

    versions = {
        (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        (SKILL / "VERSION").read_text(encoding="utf-8").strip(),
    }
    skill_header = (SKILL / "SKILL.md").read_text(encoding="utf-8")[:4000]
    if versions != {VERSION} or VERSION not in skill_header:
        raise AssertionError(f"版本不一致：{versions}")

    registry = json.loads((SKILL / "references" / "COMPETITOR_REGISTRY.json").read_text(encoding="utf-8"))
    core = registry.get("policy", {}).get("core_required_scope", [])
    expected = ["gepa", "autoresearch", "meta_harness", "promptfoo"]
    if core != expected:
        raise AssertionError(f"核心竞品范围不一致：{core}")
    by_name = {item["name"]: item for item in registry["competitors"]}
    for name in expected:
        roles = set(by_name[name].get("roles", []))
        if not {"same_layer_competitor", "routable_executor"}.issubset(roles):
            raise AssertionError(f"{name} 未保留双角色")

    pdf = ROOT / "OPTIMIZATION_SUMMARY.pdf"
    if not pdf.read_bytes().startswith(b"%PDF-") or pdf.stat().st_size < 10_000:
        raise AssertionError("优化总结 PDF 无效")
    pdfinfo = run(["pdfinfo", str(pdf)], timeout=30)
    if pdfinfo["returncode"] != 0 or "Pages:" not in pdfinfo["stdout"]:
        raise AssertionError(f"PDF 预检失败：{pdfinfo}")

    skill_manifest = check_manifest(SKILL, "MANIFEST.sha256")
    package_manifest = None
    if require_package_manifest:
        package_manifest = check_manifest(ROOT, "PACKAGE_MANIFEST.sha256", package=True)
    return {
        "python_files": len(py_files), "json_files": len(json_files), "yaml_files": len(yaml_files),
        "required_files": len(required), "skill_manifest": skill_manifest,
        "package_manifest": package_manifest, "dag": check_dag(), "pdf": {"size": pdf.stat().st_size},
        "dual_role_competitors": expected,
    }


def installer_checks(round_no: int) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix=f"pc-qa-{round_no}-") as temp:
        base = Path(temp)
        target = base / "skills" / "prompt-compiler"
        first = run([PY, "-B", str(INSTALLER), "install", "--target", str(target), "--json"], timeout=300)
        if first["returncode"] != 0:
            raise AssertionError(f"清洁安装失败：{first}")
        first_payload = json.loads(first["stdout"])
        if first_payload.get("status") != "INSTALLED":
            raise AssertionError(f"清洁安装状态错误：{first_payload}")
        verify = run([PY, "-B", str(INSTALLER), "verify", "--target", str(target), "--json"], timeout=300)
        if verify["returncode"] != 0 or json.loads(verify["stdout"]).get("status") != "PASS":
            raise AssertionError(f"安装复验失败：{verify}")
        second = run([PY, "-B", str(INSTALLER), "install", "--target", str(target), "--json"], timeout=300)
        if second["returncode"] != 0 or json.loads(second["stdout"]).get("status") != "ALREADY_INSTALLED":
            raise AssertionError(f"幂等安装失败：{second}")
        uninstall = run([PY, "-B", str(INSTALLER), "uninstall", "--target", str(target), "--yes", "--json"], timeout=120)
        if uninstall["returncode"] != 0 or json.loads(uninstall["stdout"]).get("status") != "UNINSTALLED":
            raise AssertionError(f"卸载失败：{uninstall}")

        upgrade_target = base / "upgrade" / "prompt-compiler"
        upgrade_target.mkdir(parents=True)
        (upgrade_target / "VERSION").write_text("v0.0.0.2\n", encoding="utf-8")
        (upgrade_target / "unknown-upstream-note.txt").write_text("must survive in backup\n", encoding="utf-8")
        upgrade = run([PY, "-B", str(INSTALLER), "install", "--target", str(upgrade_target), "--json"], timeout=300)
        if upgrade["returncode"] != 0:
            raise AssertionError(f"v0.0.0.2 升级失败：{upgrade}")
        upgrade_payload = json.loads(upgrade["stdout"])
        backup = Path(str(upgrade_payload.get("backup", "")))
        if not backup.is_dir() or not (backup / "unknown-upstream-note.txt").is_file():
            raise AssertionError("升级未完整保留旧树备份")
        if (upgrade_target / "VERSION").read_text(encoding="utf-8").strip() != VERSION:
            raise AssertionError("升级后版本不正确")
        return {
            "clean_install": first_payload["status"], "verify": "PASS",
            "idempotent": "ALREADY_INSTALLED", "uninstall": "UNINSTALLED",
            "upgrade_from_v0.0.0.2": upgrade_payload["status"], "backup_preserved_unknown": True,
        }


def one_round(round_no: int, *, require_package_manifest: bool) -> dict[str, Any]:
    clean_cache(ROOT)
    static = static_checks(require_package_manifest=require_package_manifest)
    self_test = run([PY, "-B", str(RUNNER), "self-test"], timeout=240)
    if self_test["returncode"] != 0 or json.loads(self_test["stdout"]).get("status") != "PASS":
        raise AssertionError(f"运行时 self-test 失败：{self_test}")
    unit = run([PY, "-B", "-W", "error::ResourceWarning", "-m", "unittest", "discover", "-s", str(SKILL / "tests"), "-p", "test_*.py", "-v"], timeout=420)
    if unit["returncode"] != 0:
        raise AssertionError(f"58 项测试失败：{unit}")
    joined = unit["stdout"] + "\n" + unit["stderr"]
    match = re.search(r"Ran\s+(\d+)\s+tests", joined)
    observed = int(match.group(1)) if match else 0
    if observed != 58:
        raise AssertionError(f"测试数量不等于 58：{observed}")
    installer_probe = run([PY, "-B", str(Path(__file__).resolve()), "--installer-only", str(round_no)], timeout=420)
    if installer_probe["returncode"] != 0:
        raise AssertionError(f"安装链隔离探针失败：{installer_probe}")
    try:
        installer = json.loads(installer_probe["stdout"])
    except json.JSONDecodeError as exc:
        raise AssertionError(f"安装链隔离探针未返回 JSON：{installer_probe}") from exc
    if installer.get("status") != "PASS":
        raise AssertionError(f"安装链隔离探针未通过：{installer}")
    installer = installer["checks"]
    clean_cache(ROOT)
    if cache_paths(ROOT):
        raise AssertionError("本轮结束后存在缓存")
    return {
        "round": round_no, "status": "PASS", "finished_at": now(),
        "checks": {
            "static": static,
            "runtime_self_test": json.loads(self_test["stdout"]),
            "unit_tests": {"observed": observed, "status": "PASS"},
            "installer": installer,
            "cache_leftovers": [],
        },
    }


def write_reports(payload: dict[str, Any]) -> None:
    REPORT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    rows = "\n".join(
        f"| 第 {item['round']} 轮 | {item['status']} | {item['checks']['unit_tests']['observed']} | 清洁安装、升级、幂等、卸载通过 |"
        for item in payload.get("rounds", [])
    )
    REPORT_MD.write_text(
        "# Prompt Compiler v0.0.0.4 三轮 QA\n\n"
        f"- 状态：**{payload.get('status')}**\n"
        f"- 运行时间：{payload.get('finished_at')}\n"
        f"- 累计测试执行：{sum(x['checks']['unit_tests']['observed'] for x in payload.get('rounds', []))} 项次\n\n"
        "| 轮次 | 状态 | 测试 | 安装链 |\n|---|---|---:|---|\n" + rows + "\n\n"
        "负向冠军门覆盖：缺竞品、缺维度、低于满分并列、竞品领先、无效维度、证据篡改、最终名单变化、数据封印变化与终审身份不独立。\n",
        encoding="utf-8",
    )
    VERIFIER_MD.write_text(
        "# Frozen Candidate Verifier\n\n"
        f"- Candidate：Prompt Compiler {VERSION}\n"
        f"- Verdict：**{'PASS' if payload.get('status') == 'PASS' else 'FAIL'}**\n"
        "- 模式：只读验证；Verifier 未修改产品代码。\n"
        "- 覆盖：文件树、清单、语法、JSON/YAML、Task DAG、PDF、58 项测试、双角色注册、负向冠军门、清洁安装、v0.0.0.2 升级备份、幂等、卸载和无缓存。\n"
        "- 证据边界：PASS 证明任务包和离线合同成立；真实项目的 CHAMPION_PASS 仍必须由真实封印竞技场生成。\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true", help="只读验证最终包，不写报告")
    parser.add_argument("--installer-only", type=int, metavar="ROUND", help=argparse.SUPPRESS)
    parser.add_argument("--round-only", type=int, metavar="ROUND", help=argparse.SUPPRESS)
    parser.add_argument("--require-package-manifest", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.installer_only is not None:
        isolated = {"status": "PASS", "round": args.installer_only, "checks": installer_checks(args.installer_only)}
        print(json.dumps(isolated, ensure_ascii=False, indent=2, sort_keys=True))
        return
    if args.round_only is not None:
        isolated_round = one_round(
            args.round_only,
            require_package_manifest=bool(args.require_package_manifest),
        )
        print(json.dumps(isolated_round, ensure_ascii=False, indent=2, sort_keys=True))
        return
    require_manifest = args.verify_only
    payload: dict[str, Any] = {
        "schema_version": "1.0", "skill": "prompt-compiler", "version": VERSION,
        "mode": "verify-only" if args.verify_only else "three-round-qa",
        "started_at": now(), "status": "RUNNING", "rounds": [],
    }
    exit_code = 0
    try:
        # Each round runs in a fresh Python process. This prevents test-created
        # subprocess state or file descriptors from contaminating later rounds.
        rounds = 1 if args.verify_only else 3
        for index in range(1, rounds + 1):
            command = [PY, "-B", str(Path(__file__).resolve()), "--round-only", str(index)]
            if require_manifest:
                command.append("--require-package-manifest")
            # Do not nest captured PIPEs across three rounds: some tested commands
            # create child processes, and inherited descriptors can delay EOF. Use
            # real files so each isolated round has a hard, deterministic boundary.
            with tempfile.TemporaryDirectory(prefix=f"pc-qa-round-{index}-") as temp:
                stdout_path = Path(temp) / "stdout.json"
                stderr_path = Path(temp) / "stderr.log"
                env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"}
                with stdout_path.open("w", encoding="utf-8") as stdout_handle, stderr_path.open("w", encoding="utf-8") as stderr_handle:
                    completed = subprocess.run(
                        command,
                        cwd=ROOT,
                        text=True,
                        stdout=stdout_handle,
                        stderr=stderr_handle,
                        timeout=900,
                        env=env,
                    )
                probe = {
                    "command": command,
                    "returncode": completed.returncode,
                    "stdout": stdout_path.read_text(encoding="utf-8")[-16000:],
                    "stderr": stderr_path.read_text(encoding="utf-8")[-16000:],
                }
            if probe["returncode"] != 0:
                raise AssertionError(f"第 {index} 轮隔离 QA 失败：{probe}")
            try:
                round_payload = json.loads(probe["stdout"])
            except json.JSONDecodeError as exc:
                raise AssertionError(f"第 {index} 轮未返回 JSON：{probe}") from exc
            if round_payload.get("status") != "PASS":
                raise AssertionError(f"第 {index} 轮状态不是 PASS：{round_payload}")
            payload["rounds"].append(round_payload)
        payload["status"] = "PASS"
    except Exception as exc:
        payload["status"] = "FAIL"
        payload["error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()[-12000:]}
        exit_code = 1
    finally:
        clean_cache(ROOT)
        payload["cache_leftovers"] = cache_paths(ROOT)
        if payload["cache_leftovers"]:
            payload["status"] = "FAIL"; exit_code = 1
        payload["finished_at"] = now()
        if not args.verify_only:
            write_reports(payload)
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
