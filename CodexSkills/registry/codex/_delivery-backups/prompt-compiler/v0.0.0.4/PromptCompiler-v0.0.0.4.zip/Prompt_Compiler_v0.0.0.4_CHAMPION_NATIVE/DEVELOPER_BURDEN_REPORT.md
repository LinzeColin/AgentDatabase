# Developer Burden Delta

## Preparation Agent 已完成

- 冻结五路径合同：四条独立原生路径 + 两阶段 Omni。
- 删除本地同名模拟和兼容回退；实现失败关闭。
- 实现 Promptfoo 官方命令、精确 `Best prompt` 解析及目标/建议模型角色证据。
- 实现 AutoResearch/MetaHarness 原生工作区校验、隔离、变更 allowlist 和树哈希证据。
- 实现逐维冠军门、预算守恒、最终集密封、回归/红队和 CI 防伪。
- 完成 58 项测试、三轮 QA、安装/升级/回滚/卸载和最终封包脚本。

## Build Agent 只剩最后一公里

1. 获取目标仓最新 `main`，按语义分类 satisfied/apply/adapt/equivalent/conflict/blocked/obsolete。
2. 原样安装并运行冻结验证，不重新研究或重构。
3. 配置授权的真实模型身份、Promptfoo/GEPA 环境，以及 AutoResearch/MetaHarness 官方工作区和真实命令。
4. 使用真实封印数据运行正式竞技；未达到逐维第一时只记录事实，不强行发布。
5. 将证据、版本和结果落库，完成 commit、push 和备份。
