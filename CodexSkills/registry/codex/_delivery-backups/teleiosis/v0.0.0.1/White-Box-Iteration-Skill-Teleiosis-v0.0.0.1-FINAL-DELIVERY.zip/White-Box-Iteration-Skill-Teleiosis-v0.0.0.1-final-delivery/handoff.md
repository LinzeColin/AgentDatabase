# Handoff - 白箱迭代Skill / Teleiosis v0.0.0.1

**有效日期：** 2026-07-26  
**工程状态：** `ENGINEERING_FINAL_INSTALLABLE`  
**当前证据状态：** `SATURATED_FOR_CURRENT_EVIDENCE`  
**正式自治晋级：** `INDEPENDENT_REVIEW_UNAVAILABLE / BLOCKED`

## 1. 基线与产品身份

- 中文名：白箱迭代Skill
- 英文品牌：Teleiosis
- 功能英文名：White-Box Iteration Skill
- 正式版本：v0.0.0.1
- 内部工程修订：`genesis-locked-self-evolved-r31-engineering-final-20260726`
- Baseline ID：`WBI-GB-CANDIDATE-001`
- 用户上传 Baseline SHA-256：`bcf4c4b4d2238bda91caf45aea6bd0001b857024ba0be0e4e241c6b37aabc12a`
- LOCKED_GENESIS SHA-256：`14ab08b9053db4ca87140e59a49f1de8105a718a87ec2d55590c6487c1a77086`
- Genesis coverage：`WBI-GB-001..027 = 27/27 PASS`

Genesis 只冻结目标、真实性、安全、权限、双白箱、独立治理和有限运行。模型、Agent runtime、候选搜索、评测器、来源 adapter、sandbox、review adapter、发布 profile 与架构仍可替换，不构成未来技术上限。

## 2. 完成范围

- Darwin：冻结 Baseline、独立 Candidate、原始对照、`KEEP / REVERT / NO_CHANGE`、失败保留和回滚棘轮。
- Luban 五门：存在性挑战、至少五个真实同行、生态位、真实产物、安装发布/reheat，全部进入 fail-closed Gate。
- 双白箱：目标 Skill 与 Teleiosis 自身使用相同或更严格的证据合同；Candidate 不能控制 Genesis、考试或终审。
- 真实 Competitor Dataset：支持发现/seed、GitHub quarantine pull、exact commit、license/inventory、static no-exec eval、manifest 和真实失败状态。
- 开放架构：支持 incremental、bundle、architecture-leap、clean-slate、Pareto population 及未来 portable strategy IDs。
- 短内核：主 `SKILL.md` 118 行、4,840 字符，低于冻结 Baseline 4,914 字符；详细机制按需加载。
- 有限循环：十个系统审查视角、预算、重复 patch 检测、状态熔断和 reheat；不允许递归死循环。

## 3. 自我迭代结果

- Source commit：`de215fdc41f989f41093f116e1b6479c4a5832f6`
- Git tree：`a945b7372cbec70ada5115eb6b23b390a352ee1f`
- Final payload tree：`147dc032a1868f93a16d002e524e043d81785b8a7f97276177fa790feb0c3d0f`
- Self-host run：`wbi-20260726T040831Z-e6d221717b`
- r30 Baseline：141 tests
- r31 Candidate：142 tests
- Frozen evaluation：PASS
- Pareto frontier：`01-incremental`
- Decision：KEEP
- Luban five gates：PASS
- Ten rounds：10/10
- Stop：`SATURATED_FOR_CURRENT_EVIDENCE`

最后三个白箱修复：

1. r29 允许 Candidate 修复旧 Baseline 已存在的缺陷，但不允许 Candidate 新增任何硬退化；
2. r30 在写入 immutable review packets 前一次性预检全部 evidence bindings，杜绝陈旧路径与半写入；
3. r31 将唯一 canonical ZIP 名称提升为 metadata 合同，并用跨文档回归测试防止 README/INSTALL/Task Pack 漂移。

## 4. 最终验收

- 142/142 regression tests：PASS
- Strict verify / release smoke / Python 3.9 AST / static audit：PASS
- 两次确定性 Skill ZIP 构建：逐字节一致
- ZIP：104 entries、唯一顶层 `teleiosis/`、无 traversal/symlink/collision/junk
- 解压后完整回归：PASS
- fresh install：PASS
- 安装后完整回归：PASS
- r30 -> r31 覆盖升级：PASS
- r31 -> r30 精确回滚与 recovery：PASS
- post-package self-audit：PASS
- PDF：11 页 A4，渲染与视觉复审 PASS

## 5. 真实性与剩余边界

当前 runtime 没有真正独立、可验证的 SubAgent spawn/attestation 能力：

- 已生成两轮 x 六个冻结 review packets，它们只是审查输入，不是伪造的批准；
- 没有用同一模型换角色、同一上下文重复输出或 fallback 冒充独立审查；
- 正式 promotion Gate 仅因 `WBI-GB-019` 保持 BLOCKED；
- 未来必须绑定 12 个唯一 actor/context/provider receipt，并由不同的第 13 个只读 verifier 裁决。

当前容器 GitHub clone 因 DNS 返回 `PULL_BLOCKED`，系统未生成假 commit、假 pull 或假 PASS，且第三方代码默认未执行。公开研究与同行信息已经记录；远程 commit-pinned pull 在网络恢复后通过 reheat 重跑。

## 6. Canonical 安装包

- `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-final.zip`
- SHA-256：`1ebabb9f6be66032955d9f5b7f118fbc2b534241f69a398922aa112146e23257`
- 顶层目录：`teleiosis/`

```bash
sha256sum White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-final.zip
unzip -q White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-final.zip -d /tmp/wbi-check
cd /tmp/wbi-check/teleiosis
python3 scripts/wbi.py verify-self --strict \
  --expected-genesis-hash 14ab08b9053db4ca87140e59a49f1de8105a718a87ec2d55590c6487c1a77086
python3 scripts/wbi.py self-test
```

正式安装、升级和回滚按 ZIP 内 `delivery/INSTALL.md` 与 `delivery/CODEX_TASK_PACK_v0.0.0.1.md` 执行；Codex 不需要重做研究或设计。

## 7. 外部交付物

| 文件 | SHA-256 | Bytes |
|---|---|---:|
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-final.zip` | `1ebabb9f6be66032955d9f5b7f118fbc2b534241f69a398922aa112146e23257` | 198,688 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-Delivery-Report.pdf` | `1f3079fcb65f633146710b72910d5bfcf9cbc179657322fd40cd0431d3cc7b3d` | 292,677 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-release-receipt.json` | `1ebdd94a18d8b840e415729dd687276302e01bddc07d075d5dbe65b8064943e1` | 6,406 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-final-validation.json` | `59a4c0212d01f40d46249be302500727dcda88e65c9c0d685eaedd76855b3426` | 1,609 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-post-package-self-audit.json` | `41f84b7eaa49508f0b841aed6f672a2276a57b2efff59d0512bbd412e0653d90` | 3,913 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-evidence.zip` | `d676e2bb98434be69980618bfa25d703f432cdc6c602401c8b43faf327308655` | 2,221,039 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-directory-tree.txt` | `31178b35f8cfe1065d41da00e4099a5915d3ea1853dd5b83f87d8449d13095d5` | 4,200 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-Codex-Task-Pack.md` | `1c19a29b07aa8fc8f6a9920ba4da5b18bd9d09aa2795a15edd2d4c2d94190394` | 2,658 |
| `White-Box-Iteration-Skill-Teleiosis-v0.0.0.1-pdf-visual-audit.json` | `85d4220ae826606f0fa53bf6be03a662ec73efe94bd5e1a981b28b751a50722b` | 927 |

## 8. Reheat 触发器

freshness 到期、新模型/runtime、标准或依赖弃用、更强同行、真实任务退化、安全公告、Genesis 显式修订、独立 review adapter 可用或 GitHub 网络恢复时，状态转为 `REHEAT_REQUIRED` 并开启新 run；不得在旧 run 中无限追加 Prompt。
