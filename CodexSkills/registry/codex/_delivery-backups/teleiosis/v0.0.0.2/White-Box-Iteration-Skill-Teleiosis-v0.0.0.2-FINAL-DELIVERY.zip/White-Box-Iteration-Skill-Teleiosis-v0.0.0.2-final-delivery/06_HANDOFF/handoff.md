# Handoff — 白箱迭代Skill / Teleiosis v0.0.0.2

**日期：** 2026-07-26（Australia/Sydney）  
**工程状态：** `ENGINEERING_FINAL_INSTALLABLE`  
**当前证据饱和：** `SATURATED_FOR_CURRENT_LOCAL_ENGINEERING_EVIDENCE`  
**当前环境最强状态：** `NOT_PROVEN`  
**正式自治晋级：** `BLOCKED`

## 1. 最终身份与锚点

```text
中文名：白箱迭代Skill
英文品牌：Teleiosis
版本：v0.0.0.2
安装包：White-Box-Iteration-Skill-Teleiosis-v0.0.0.2-final.zip
安装包 SHA-256：5a9d684bd083aaf9a244d1393e5a87d41864830a03658a6089755f874b583088
Base Genesis：14ab08b9053db4ca87140e59a49f1de8105a718a87ec2d55590c6487c1a77086
Effective Genesis：fe80c467f8ecbe8343ef0c09ef5e6f9fd9683803c8260c9188998c7e3dfca0a2
有效要求：WBI-GB-001—028
```

原 `WBI-GB-001—027` 字节未变。用户本轮明确授权的“无静态时效局限、每次输出证明当前环境强度”以 append-only `WBI-GB-028` 加入；不重写旧要求，不自动重签旧 Genesis。

## 2. 为什么过去总能发现新漏洞

1. 过去主要关闭已知 issue list，没有把前沿发现本身作为持续输入。
2. 控制面、真实 outcome、成本和外部责任链曾被混成一个“PASS”。
3. 单任务测试没有证明关键安全/权限行为被覆盖。
4. 单独 Skill 测试忽略大型 Skill 库中的检索、误选与遮蔽。
5. 随机模型的小样本结果可能被 best-of-N 或区间重叠误判为提升。
6. 报告有日期，但输出没有可执行 evidence lease 与自动失效。
7. 两个 v0.0.0.3 分支各自增加能力、同时删除对方能力，版本号没有代表超集。

## 3. 本轮机制增量

- 合并 v0.0.2 的 benchmark/status/cost/review 核心；
- 合并 adaptive diagnosis、strategy memory、truthful showcase；
- 合并 market profile、evidence gateway、no-negative guard、operations/verifier/persona bridges；
- 合并 peer taxonomy、utility guard、environment doctor、dashboard；
- 新增 behavior coverage、Skill-library shadowing、stochastic confidence、current-environment strength；
- 新增外部 effective-Genesis trust anchor；
- 将 current-environment strength 升为第八个强制状态域；
- 修复 `SATURATED → loop-status CONTINUE` 的递归风险。

## 4. 验证结果

```text
Source regression：284/284 PASS
Deterministic package：PASS（两次字节一致）
ZIP safety：234 entries；0 duplicate；0 traversal；0 symlink；0 special
Post-extract strict verify：PASS
Post-extract release smoke：PASS
Fresh v0.0.0.1 install：PASS
v0.0.0.1 → v0.0.0.2 upgrade：PASS
Installed v0.0.0.2 regression：284/284 PASS
v0.0.0.2 → v0.0.0.1 rollback：PASS
Restored predecessor tree：exact hash match
Ten system perspectives：10/10
Self-host terminal state：STOP / TERMINAL_STATE:SATURATED
```

## 5. 八域状态

| 域 | 状态 | 含义 |
|---|---|---|
| Control plane | PASS | 双白箱、Seal、Gate、状态、安装与回滚在本地工程证据下通过 |
| Benchmark integrity | VALID | 108-cell deterministic fixture 证明 runner 完整性 |
| Outcome | NOT_PROVEN | 没有真实多模型同预算任务 benchmark |
| Cost evidence | PARTIAL | provider usage/真实货币成本与完整人工成本不全 |
| Independent review | UNAVAILABLE | 当前环境没有真实外部 2×6+1 attestation |
| Engineering release | INSTALLABLE | 可安装、升级、测试和回滚 |
| Formal promotion | BLOCKED | outcome 与独立责任链未完成 |
| Current-environment strength | NOT_PROVEN | Candidate 在本地工程维度位于 Pareto frontier，但不足以宣称市场第一 |

## 6. 时效合同

```text
valid_as_of：2026-07-26
evidence lease expires：2026-08-25
expiry/update result：REHEAT_REQUIRED
```

触发条件：重大模型/Agent runtime 发布、新同行胜出、行为覆盖下降、Skill 库遮蔽回归、真实任务/安全回归、标准/依赖/安全状态变化、Genesis amendment。

## 7. 仍需外部证据

- 至少 6 个真实 target、sealed holdout、3 次以上随机试验的 equal-budget Track A/B/C；
- 真实 runtime/模型矩阵；
- commit-pinned production peer inspection（本容器 Git DNS 阻断）；
- live Skill-library retrieval/shadowing；
- provider-measured token/cost；
- 外部 12 reviewer + 独立只读 verifier。

这些不阻止工程安装，但阻止 market-first 和 formal autonomous promotion。

## 8. 安装原则

Codex 只负责验证、安装与落库，不重新设计产品。先校验 Base Genesis、Effective Genesis 和 archive 三个外部 SHA-256，再按 `delivery/CODEX_TASK_PACK_v0.0.0.2.md` 操作。
