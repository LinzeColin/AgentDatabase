# Teleiosis `v0.0.0.2` 迭代优化交接

> **用途**：将本文件原样交给 Teleiosis / 白箱迭代 Skill 开发线程，作为下一轮只读核验、开发、测试、评测与候选交付的执行合同。  
> **建议目标版本**：`v0.0.0.2-candidate`；只有全部发布 Gate 通过后才能升格为 `v0.0.0.2`。  
> **交接日期**：2026-07-26（Australia/Sydney）  
> **目标仓库**：`LinzeColin/AgentDatabase`  
> **目标路径**：`CodexSkills/registry/codex/teleiosis/`  
> **冻结公开基线提交**：`a8f1f6ff8003db43fad722a5afd3b19615dd325e`  
> **Genesis SHA-256**：`14ab08b9053db4ca87140e59a49f1de8105a718a87ec2d55590c6487c1a77086`

---

## 0. 开发线程执行指令

本文件不是讨论提纲，而是下一轮开发合同。开发线程应按以下方式推进：

1. **先只读核验，再修改 Candidate**。不得原地覆盖已注册的 `v0.0.0.1`，不得修改或自动重签 Genesis。
2. **先验证事实，再接受本交接中的建议**。若仓库当前状态已晚于本文件所列基线，应冻结最新稳定树、列出 delta，并说明哪些任务已完成、仍适用或已失效。
3. **不要继续以增加流程长度、Agent 数量或文档数量作为默认进步指标**。下一轮的首要价值是证明或证伪真实 outcome、量化治理成本，并打通可信的外部复审边界。
4. **正式 promotion 不得降级标准**。缺少真实外部 `2×6` 独立 SubAgent 与独立只读 verifier 时，继续返回 `INDEPENDENT_REVIEW_UNAVAILABLE / BLOCKED`，不得用角色模拟、自签 JSON、重复上下文或本地伪造 receipt 替代。
5. **开发线程负责完整实现、测试、修复、重建和验证**。落库线程只负责将已验收文件原样 commit、push、PR/merge 和备份，不把实现责任转移给落库线程。
6. 遇到非安全性歧义时采用本文件默认方案继续推进；只有 Genesis 冲突、不可恢复的数据风险、凭证风险或正式授权缺失才阻断。
7. 最终默认只交付 **一个 ZIP**，内含源码 Candidate、测试与 benchmark 证据、机器可读状态、变更清单、安装/回滚证据和最终交接；不要散落多个默认下载件。

---

# 1. 结论与默认方案

## 1.1 下一轮不应再做什么

Teleiosis `v0.0.0.1` 已经具备较强的控制面：冻结 Baseline、独立 Candidate、研究与评测 seal、硬 Gate、Pareto 选择、外部 attestation 边界、确定性打包、事务安装、恢复与回滚。当前最大缺口不是“再加一道审查”，而是：

- **控制面测试通过，不等于真实优化效果已被同场证明**；
- **声明支持外部 adapter，不等于已有可运行、可复核的参考 adapter 与真实 receipt**；
- **命令和状态较多，普通操作者仍可能误把 engineering installable、outcome supported 和 formal promotion 当成同一件事**；
- **治理收益尚未与 token、调用、时延、人工分钟数和失败恢复成本绑定**。

## 1.2 推荐优先级

| 优先级 | 工作流 | 目标 | 发布阻断 |
|---|---|---|---|
| **P0-A** | 可复现 outcome benchmark | 在相同环境与预算下证明或证伪 Teleiosis 对真实任务的净增益 | 是 |
| **P0-B** | 状态语义彻底分离 | 不再混淆控制面、benchmark、engineering release 与 formal promotion | 是 |
| **P0-C** | 成本、时延与人工负担证据 | 给每次改善计算真实代价，禁止把未知成本记为 0 | 是 |
| **P0-D** | 外部独立复审 adapter 参考实现与真实部署合同 | 打通 `2×6 + 1` 的可信证据边界；无能力时继续 fail closed | 对 formal promotion 是 |
| **P1-A** | 高层 orchestration 与恢复入口 | 降低多命令操作摩擦，保留底层可审计命令 | 否 |
| **P1-B** | reviewer diversity 与边际价值实验 | 降低同模型相关错误，量化 2/6/12 reviewer 的边际收益 | 否 |
| **P1-C** | 跨 runtime / 跨模型迁移矩阵 | 验证 platform-neutral 不是文档声明 | 对 portability 声明是 |
| **P2** | 独立分发、公开案例与采用证据 | 提升发现、安装、外部反馈和第三方复现 | 否 |

## 1.3 默认产品定位

保持 Teleiosis 为：

> **Skill Assurance & Evolution Control Plane**  
> 面向高风险、需要白箱证据、可逆交付和正式责任链的 Skill 演化控制面。

不要把它重新定位为：

- 最轻量的日常 Prompt 优化器；
- 用单一总分宣布冠军的排行榜；
- 依靠 reviewer 数量制造可信感的评审框架；
- 任何环境下都自动给出 formal PASS 的“全能 Skill”。

---

# 2. 已核验公开基线

以下为开发线程开始前必须复核的事实，不得直接沿用为未经检查的假设。

| 项目 | 当前公开状态 |
|---|---|
| 注册版本 | `v0.0.0.1` |
| 注册提交 | `a8f1f6ff8003db43fad722a5afd3b19615dd325e` |
| 注册提交规模 | 109 files changed；Teleiosis registry entry 为 104 个文件、约 598,392 bytes |
| Genesis | 锁定；SHA-256 为 `14ab08...a77086` |
| 发布工程状态 | `ENGINEERING_FINAL_INSTALLABLE` |
| 正式自主 promotion | `INDEPENDENT_REVIEW_UNAVAILABLE / BLOCKED` |
| 已登记回归测试数 | 142 |
| 确定性构建 | 已登记为 `true` |
| credential scan | 已登记为 `PASS` |
| archive manifest | 已登记为 `PASS` |
| 已安装 tree hash | `147dc032a1868f93a16d002e524e043d81785b8a7f97276177fa790feb0c3d0f` |
| Canonical install archive SHA-256 | `1ebabb9f6be66032955d9f5b7f118fbc2b534241f69a398922aa112146e23257` |
| 当前明确追求目标 | 获得真实外部 `2×6` review 与独立只读 verifier 证据，同时不弱化 Genesis 或 evidence boundary |
| 当前激活原则 | 快速 `verify-self`；源码、Gate、Schema、脚本、测试或依赖变化及正式封包前执行完整 `self-test` |
| 评测原则 | 分维度、先硬 Gate、保护任务无负迁移、再做 Pareto；总分不得抵消硬退化 |
| 外部复审原则 | adapter 必须在 workspace/target/optimizer 之外、绝对路径、哈希固定、外部 receipt root、无 shell 调用 |
| Roadmap 原则 | reheat 为事件驱动、有限运行；未来 adapter 不自动变成 Genesis |

## 2.1 启动核验命令

从冻结基线的 Teleiosis 根目录执行：

```bash
git rev-parse HEAD
git status --short

python3 scripts/wbi.py verify-self --strict \
  --expected-genesis-hash 14ab08b9053db4ca87140e59a49f1de8105a718a87ec2d55590c6487c1a77086

python3 scripts/wbi.py self-test --timeout 600
```

必须保存：

- 精确 Git commit；
- Teleiosis tree hash；
- Python 与 OS/runtime 版本；
- 命令、退出码、开始/结束时间、wall-clock duration；
- stdout/stderr 原文；
- 测试总数、跳过、失败和 flaky 重跑情况；
- 当前 `SKILL.md` 激活成本证据；
- 当前 release record 和安装/回滚 receipt。

若实际测试数不再是 142，记录差异和来源；不得为匹配本文件而篡改结果。

---

# 3. 问题定义

## 3.1 目标

下一版应将 Teleiosis 从“**治理设计与控制面验证很强**”推进为“**在明确任务、环境、预算和日期下，真实 outcome 与治理代价均可复核**”。

目标必须同时覆盖三层：

1. **控制面层**：冻结、Gate、身份绑定、打包、安装、恢复、回滚仍然正确；
2. **任务 outcome 层**：Candidate 在不可见任务上相对 Baseline 或对照方案有可复核改善，且没有保护任务负迁移；
3. **责任与成本层**：谁执行、谁评估、谁批准、花费多少、哪些能力不可用，全部机器可读且不可被 Candidate 自证。

## 3.2 非目标

本轮不以以下事项作为必要目标：

- 修改 Genesis；
- 追求永久“世界最好”标签；
- 强制固定模型、供应商、评分算法或 reviewer 数量成为永久规范；
- 把 Luban、Darwin 或某篇论文完整复制进 Teleiosis；
- 为所有 Skill 强制相同 UI、showcase 或发布方式；
- 用更多文字替代可执行 Gate、Schema、test 和外部证据；
- 为了让 formal promotion 变绿而降低独立性要求；
- 未有 benchmark 证据前大规模重写架构。

## 3.3 关键未知

| 未知 | 验证方法 |
|---|---|
| Teleiosis 相同预算下是否比 Darwin 带来更高任务增益 | 冻结同一 target、模型、工具和预算的 blind holdout benchmark |
| Teleiosis 的产品化路径是否比 Luban 更有效 | 单独建立产品化 track，比较安装、触发、理解、真实产物和采用任务 |
| 额外治理是否值得 | 记录 token、调用、时延、人工分钟、失败恢复次数与 outcome delta |
| 12 reviewer 是否优于更小 panel | reviewer ablation：2 / 6 / 12，比较发现率、重复率、误报与成本 |
| 同模型 13 次调用是否仍高度相关 | 模型家族、工具链、deterministic oracle 和人类责任主体的 diversity 分析 |
| platform-neutral 是否真实成立 | 至少两个 runtime、两个模型家族的安装、触发和任务迁移测试 |
| 外部 review adapter 是否可真实部署 | 独立目录/主机或可信 runtime 中运行并生成 provider-identifiable receipt |
| 普通用户是否能正确操作 | 一条高层命令的冷启动可用性测试与错误恢复演练 |

---

# 4. P0-A：建立同场、同预算、可证伪的 Outcome Benchmark

## 4.1 必须避免的类别错误

Darwin、Luban 和 Teleiosis 不完全处于同一层，因此不要用一个混合总分直接宣布“谁最好”。采用三个分轨：

| Track | 比较对象 | 主要问题 |
|---|---|---|
| **A. Skill 优化效果** | Baseline / Darwin / Teleiosis | 在相同预算下，谁让真实任务成功率、安全性和负迁移表现更好 |
| **B. Skill 产品化效果** | 原 Skill / Luban / Teleiosis 的产品成熟化路径 | 谁更能改善触发、安装、理解、真实产物、README 与采用任务 |
| **C. Assurance 控制面** | 无正式控制面 / Teleiosis | 谁能更可靠地冻结证据、阻断污染、恢复中断、打包、安装和回滚 |

Track A 与 B 可以共享 target，但必须分开报告。Track C 不以文案质量为主要结果。

## 4.2 最小 benchmark 集

至少选择 6 个真实 Skill：

| 类型 | 数量 | 特征 |
|---|---:|---|
| 纯文本/推理型 | 2 | 无外部工具或低副作用，易于观察指令与任务质量 |
| 工具调用/产物型 | 2 | 需要脚本、文件、浏览或结构化产物 |
| 高风险/可逆操作型 | 2 | 涉及发送、部署、删除、财务或权限边界，但必须使用安全 sandbox/fixture |

每个 target 至少包含：

- dev：可见失败与设计反馈；
- validation：Candidate 提出后才开放；
- sealed holdout：至少 20 条，不向 Candidate 暴露正文；
- adversarial：注入、邻近触发、缺失输入、authority trap、恢复与 malformed data；
- protected task families：不得因优化出现实质负迁移。

每个 optimizer × target 的 stochastic 执行至少重复 3 次。随机种子、模型参数和环境必须记录；不能假装模型调用是确定性的。

## 4.3 冻结公平性合同

必须冻结并哈希绑定：

- target Baseline tree；
- optimizer 版本与 tree；
- runtime、模型、工具权限；
- context window、temperature、sampling 参数；
- token、调用次数、联网时长、wall-clock 和人工分钟预算；
- dev/validation/holdout/adversarial dataset ID 与 hash；
- judge/oracle 版本；
- output normalization、blind/randomization 方法；
- failure、timeout、retry 与 missing-cost 规则；
- promotion 规则。

任何 optimizer 超预算时，必须记录 `BUDGET_VIOLATION`，不能事后放宽预算或隐藏超额调用。

## 4.4 指标

指标必须分开报告，禁止只输出一个总分：

| 维度 | 至少记录 |
|---|---|
| Trigger | precision、recall、false-positive、false-negative、邻近意图误触发 |
| Task | 成功率、部分成功、关键错误、真实产物可用性 |
| Safety/authority | 越权、不可逆动作、secret boundary、注入抵抗 |
| Truthfulness | 证据可追溯、能力不可用时是否明确 BLOCKED |
| Negative transfer | protected families 的 subgroup delta |
| Cost | input/output tokens、调用数、货币成本或 `UNKNOWN`、人工分钟 |
| Latency | p50、p95、timeout、重试与恢复时间 |
| Reliability | variance、flaky rate、环境失败与模型失败分离 |
| Install/rollback | 安装、升级、中断恢复、回滚、重复安装 |
| Portability | runtime/model 迁移后的触发与任务差异 |
| Maintenance | 变更文件数、激活成本、后续修复负担 |
| Evidence quality | raw result 覆盖率、identity binding、missing evidence |

建议增加两个反直觉但高价值的派生指标：

```text
quality_efficiency = protected-task-safe outcome gain / total model tokens
governance_burden = governance tokens + reviewer calls + human minutes
evidence_cost_ratio = governance_burden / accepted outcome gain
```

当 outcome gain 为零或负数时，不得制造正向比率；应报告 `NO_MEASURABLE_GAIN` 或 `REGRESSED`。

## 4.5 机器可读状态分离

新增或统一以下状态，禁止互相替代：

| 状态域 | 允许值示例 |
|---|---|
| `control_plane_status` | `PASS / FAIL / BLOCKED` |
| `benchmark_integrity_status` | `VALID / INVALID / INCOMPLETE` |
| `outcome_status` | `SUPPORTED / NOT_PROVEN / REGRESSED / UNKNOWN` |
| `cost_evidence_status` | `MEASURED / PARTIAL / ESTIMATED / UNKNOWN` |
| `independent_review_status` | `PASS / BLOCKED / UNAVAILABLE / FAIL` |
| `engineering_release_status` | `INSTALLABLE / NOT_INSTALLABLE` |
| `formal_promotion_status` | `PASS / BLOCKED / FAIL` |

示例：

```json
{
  "control_plane_status": "PASS",
  "benchmark_integrity_status": "VALID",
  "outcome_status": "NOT_PROVEN",
  "cost_evidence_status": "MEASURED",
  "independent_review_status": "UNAVAILABLE",
  "engineering_release_status": "INSTALLABLE",
  "formal_promotion_status": "BLOCKED"
}
```

这是合法且可信的结果，不能为了“全绿”将其压成一个 `PASS`。

## 4.6 P0-A 验收标准

- benchmark contract 在任何 Candidate 修改前 seal；
- Candidate 无法读取 sealed holdout 正文；
- result 绑定精确 optimizer tree、target tree、system、dataset/split 和 run identity；
- blind/randomized 输出保留映射但不泄露给修改者；
- 同一输入重复运行能保留全部原始结果，不只保留最好结果；
- Baseline、Darwin、Luban、Teleiosis 的环境与预算差异均显式；
- 两类 track 分开报告；
- 结果即使显示 Teleiosis 未胜出，也必须完整保留；
- 只有满足预先冻结的 outcome 条件才可使用 `OUTCOME_SUPPORTED`；
- 不以 stars、README、自评或控制面测试数证明 outcome superiority。

---

# 5. P0-B：实现统一的状态与证据模型

当前 release record 已区分 engineering installable 与 formal promotion blocked，这是正确方向。下一版要把这种区分扩展到所有 CLI、JSON、报告和文档。

## 5.1 必须统一的位置

- `gate` 输出；
- `evaluate` 输出；
- `review-gate` 输出；
- `package` 与 `install` receipt；
- benchmark summary；
- README、release notes、task pack；
- final human-readable report；
- registry release record。

## 5.2 规则

1. `CONTROL_PLANE_PASS` 只证明控制面按合同工作。
2. `BENCHMARK_VALID` 只证明实验没有发现结构性污染。
3. `OUTCOME_SUPPORTED` 必须来自真实任务和冻结条件。
4. `ENGINEERING_FINAL_INSTALLABLE` 不等于 formal promotion。
5. `INDEPENDENT_REVIEW_UNAVAILABLE` 不等于 review fail，但必须阻断 formal promotion。
6. 任一 `UNKNOWN` 不得被序列化为 `0`、空字符串或默认 `PASS`。
7. 人工批准必须记录批准主体、范围、时间和绑定 artifact hash；“用户知道了”不等于 promotion approval。

## 5.3 验收标准

- 所有状态均由 Schema 约束；
- CLI 退出码与 JSON 状态一致；
- 文档不再出现“工程安装通过”被解释为“正式独立验收通过”的可能；
- legacy receipt 兼容性有明确规则；
- 状态迁移拥有单元测试与非法迁移测试。

---

# 6. P0-C：成本、时延和人工负担成为一等证据

`RUNTIME_ADAPTERS.md` 已声明 model/Agent invocation 应包含 token、latency 与 cost counter；下一轮应确认该能力是否真正落地，而不只停留在 adapter 设计。

## 6.1 必须采集

- provider、model、runtime、adapter version；
- input/output/cached/reasoning tokens（provider 能提供多少就记录多少）；
- 调用数、retry、timeout；
- wall-clock duration、p50/p95；
- 货币成本：`MEASURED`、`ESTIMATED` 或 `UNKNOWN`；
- 人工审阅、准备 fixture、修复和恢复分钟数；
- reviewer 与 final verifier 分开计费；
- research、candidate generation、evaluation、review、packaging、installation 分阶段归因；
- 中断后恢复的额外成本。

## 6.2 禁止项

- provider 未返回 usage 时记为 0；
- 混用估算成本与账单成本但不标记；
- 只统计 Candidate 生成，不统计评测和 reviewer；
- 用平均值掩盖长尾失败；
- 因成本高而删除失败结果；
- 以更大预算获胜后宣称算法更优。

## 6.3 验收标准

- 每个外部调用都有唯一 invocation ID；
- aggregation 可回溯到 raw invocation；
- missing usage 会降低 `cost_evidence_status`；
- benchmark 可输出质量—成本—时延 Pareto；
- 至少有一个 test 验证 `UNKNOWN` 不会变为 0；
- 至少有一个 test 验证 retry 不会重复漏算或双算。

---

# 7. P0-D：外部独立复审 Adapter

## 7.1 目标

提供可执行、可复核的 **adapter protocol + reference implementation + deployment guide**，但绝不能让 Candidate 内置的 adapter 自己成为正式信任根。

## 7.2 信任边界

正式 run 的 adapter 必须：

- 位于 workspace、target、optimizer 和安装包之外；
- 使用绝对路径；
- 在 `init-run` 时冻结 SHA-256；
- 由独立操作者或可信 runtime 部署；
- receipt root 位于 Candidate 不可写路径；
- 产生 provider/runtime-identifiable run ID；
- 证明每个 seat 的 actor/context/provider-run 唯一；
- 为第十三 verifier 使用不同 identity；
- 在 verifier 只读条件下验证 frozen evidence；
- 将 residual trust 明确写入结果。

仓库中可以包含 adapter **协议、fixture、example 和 deployment helper**，但 bundled example 只能用于 integration test 或 diagnostic，不能自动满足 formal attestation。

## 7.3 Reviewer diversity

不要把“13 个实例”误写成“13 种独立认识”。正式策略应支持但不永久绑定：

- 至少两个模型家族，或一个模型家族 + deterministic oracle + 独立人类责任主体；
- reviewer role 的不同证据视角；
- blind packet；
- unique provider run/context；
- 发现重复、相关结论和共享故障模式；
- model/provider unavailable 时明确降级为 blocked，而非静默改用同一上下文。

## 7.4 建议 adapter 接口

```text
teleiosis-review-attestor verify-batch \
  --contract <frozen-contract.json> \
  --packet-index <packet-index.json> \
  --receipt-root <external-root> \
  --output <external-attestation.json>
```

输出至少绑定：

- adapter hash/version；
- provider/runtime；
- run start/end；
- packet hash；
- actor/context/provider-run ID；
- model/config；
- receipt hash与外部路径；
- read-only verifier 证明；
- capability 与 isolation 声明；
- raw provider evidence pointer；
- unresolved trust boundary；
- verdict 与 exit code。

## 7.5 验收标准

- 本地 Candidate 无法生成可通过 formal Gate 的自签 receipt；
- 重用 actor/context/provider-run 会 fail；
- packet hash、evidence hash 或 adapter hash 漂移会 fail；
- receipt root 位于受保护外部路径；
- 缺少真实能力时结果仍为 `INDEPENDENT_REVIEW_UNAVAILABLE / BLOCKED`；
- 至少完成一次真实外部部署演练；若环境不具备，交付实现与 blocked evidence，不伪造成功；
- formal PASS 必须经第十三独立只读 verifier；
- review 结果、成本与 dissent 全部保留。

---

# 8. P1-A：一条高层操作路径，但不隐藏白箱

Teleiosis 当前提供多个细粒度命令，这是审计优势，也是操作负担。增加 orchestration 时必须保留底层命令和中间产物。

## 8.1 避免 profile 命名冲突

当前 `--profile optimizer` 更接近打包/安装 profile。不要再用相同字段表示运行保障级别。建议命名：

```text
--run-mode diagnostic | engineering | formal
--package-profile optimizer | <future package profile>
--verification-level fast | release | deep
```

语义：

| Run mode | 允许输出 | 禁止输出 |
|---|---|---|
| `diagnostic` | 研究、预检、结构问题、成本估计 | formal PASS、自动 promotion |
| `engineering` | Candidate、真实 eval、installable engineering evidence | formal promotion（无外部 review 时） |
| `formal` | 完整 seal、真实任务、外部 `2×6 + 1`、promotion verdict | capability 缺失时伪造 PASS |

## 8.2 建议高层命令

```bash
python3 scripts/wbi.py optimize /absolute/path/to/target \
  --workspace /absolute/path/outside/skills/run \
  --run-mode engineering \
  --valid-as-of 2026-07-26 \
  --resume
```

高层命令必须：

- 先执行 preflight；
- 显示将要冻结的合同；
- 不隐藏每个底层命令；
- 写 durable run state；
- 可在中断后恢复；
- 对已 seal 的 evidence 不重复覆写；
- 对 missing capability fail closed；
- 输出下一可执行动作，而不是只给 Python traceback；
- 允许高级用户继续使用原始子命令。

建议同时增加：

```bash
python3 scripts/wbi.py preflight ...
python3 scripts/wbi.py run-status ...
python3 scripts/wbi.py resume ...
python3 scripts/wbi.py explain-block ...
```

## 8.3 验收标准

- 冷启动用户能通过一条命令进入正确流程；
- 每个自动步骤均有可复核命令记录；
- 中断前后 run identity 不漂移；
- `--resume` 不重跑已完成的不可变步骤；
- `formal` 缺 adapter 时在 Candidate 修改前尽早阻断或明确转为非 promotional；
- 高层命令不绕过任何 Genesis Gate。

---

# 9. P1-B：Reviewer Ablation——量化“更多评审是否值得”

这是下一轮最重要的反直觉实验之一。

## 9.1 实验设计

对同一 frozen evidence packet，比较：

- 2 reviewers；
- 6 reviewers；
- 12 reviewers；
- 12 reviewers + 第十三 verifier。

记录：

- unique valid findings；
- CRITICAL/HIGH finding recall；
- 重复率；
- false-positive/unsupported finding；
- dissent；
- reviewer 间相关性；
- token、成本、时延；
- final decision 是否改变；
- verifier 实际解决了哪些争议。

## 9.2 判定

不要预设 12 一定最好。若 6 reviewers 已覆盖绝大多数高风险发现，而 12 只增加重复与成本，应：

- 保留 Genesis 所要求的正式 `2×6` 不变；
- 但在普通 engineering mode 使用更小 panel；
- 把 full panel 的额外价值和成本透明呈现；
- 将 reviewer diversity 优先于简单数量扩张。

---

# 10. P1-C：跨 Runtime / 跨模型验证

## 10.1 最低矩阵

至少覆盖：

- 两个 Agent runtime；
- 两个模型家族；
- 一个无 SubAgent 能力的 runtime；
- 一个具备可信隔离能力的 runtime（若现实可用）；
- Linux/macOS 中至少一种正式支持环境，并明确其他环境状态。

## 10.2 测试内容

- Skill discovery 与 trigger；
- frontmatter/目录兼容；
- CLI 与 Python 版本；
- workspace 路径、symlink、防穿越；
- 外部 adapter contract；
- token/cost counters；
- install、upgrade、interruption recovery、rollback；
- no-subagent 环境下的 truthful blocked behavior；
- 相同 target 的 outcome transfer。

## 10.3 验收标准

- “platform-neutral” 结论只覆盖真实验证过的矩阵；
- 未测 runtime 为 `UNVERIFIED`，不能写成 supported；
- runtime-specific helper 不进入 Genesis；
- 跨模型结果按 subgroup 报告，不用 aggregate 掩盖失败。

---

# 11. 建议文件级实施图

以下为建议，不是强制架构；开发线程应先检查现有模块，避免重复实现。

| 建议文件 | 作用 |
|---|---|
| `scripts/wbi_core/benchmark.py` | benchmark contract、split binding、blind comparison、result aggregation |
| `scripts/wbi_core/telemetry.py` | invocation、token、cost、latency、human-minute 证据 |
| `scripts/wbi_core/status.py` | 多域状态模型与合法迁移 |
| `scripts/wbi_core/orchestrator.py` | preflight、optimize、resume、run-status |
| `scripts/wbi_core/review_adapter.py` | adapter protocol validation；不作为正式信任根 |
| `schemas/benchmark-contract.schema.json` | benchmark 冻结合同 |
| `schemas/benchmark-result.schema.json` | 分轨、分组、重复运行结果 |
| `schemas/invocation-evidence.schema.json` | 单次外部调用成本与身份 |
| `schemas/status-summary.schema.json` | 控制面/outcome/review/release 状态分离 |
| `schemas/review-attestation-contract.schema.json` | 明确 adapter 合同，而不是仅内嵌于 run contract |
| `templates/benchmark-contract.json` | 可复用模板 |
| `templates/status-summary.json` | 统一状态输出 |
| `references/BENCHMARK_PROTOCOL.md` | 公平性、数据 split、blind、统计与 claim policy |
| `references/STATUS_SEMANTICS.md` | 所有 PASS/BLOCKED/UNKNOWN 语义 |
| `references/OPERATOR_RUN_MODES.md` | diagnostic/engineering/formal |
| `delivery/EXTERNAL_REVIEW_ADAPTER.md` | 外部部署、信任根、receipt root 与演练 |
| `tests/test_benchmark.py` | seal、泄漏、identity、budget、blind |
| `tests/test_telemetry.py` | unknown、retry、aggregation、cost |
| `tests/test_status.py` | 合法/非法状态迁移 |
| `tests/test_orchestrator.py` | preflight、resume、idempotence、中断 |
| `tests/test_review_adapter.py` | hash、receipt、identity、外部路径与 fail-closed |
| `tests/test_outcome_claims.py` | 无 benchmark 时禁止 superiority claim |

若已有等价模块，扩展现有模块优先于创建平行实现。

---

# 12. 必须新增或保留的负面测试

至少覆盖：

1. Candidate 修改已 seal benchmark contract；
2. Candidate 读取 sealed holdout 正文；
3. result 绑定旧 Candidate tree，随后代码被修改；
4. Baseline hard-gate defect 被错误当作 evidence-integrity failure；
5. Candidate hard-gate failure 被总分补偿；
6. protected task regression 被 aggregate 隐藏；
7. 同一个 provider run 填充多个 reviewer seat；
8. 第十三 verifier 与 reviewer 复用 context；
9. bundled example adapter 自签 formal PASS；
10. adapter、packet、receipt 或 evidence hash 漂移；
11. receipt root 位于 Candidate 可写目录；
12. token usage 缺失被记为 0；
13. retry 成本漏算或双算；
14. benchmark 超预算后仍被宣布胜出；
15. `diagnostic` 或 `engineering` 被错误标记为 formal PASS；
16. 中断恢复后生成新 run identity 或覆盖 seal；
17. 高层命令绕过底层 Gate；
18. release docs、task pack 与 archive 名称再次不一致；
19. symlink/path traversal/oversized archive/concurrent mutation 回归；
20. benchmark 失败结果被删除，仅保留最佳 trial。

---

# 13. 验收矩阵

## 13.1 Genesis 与基线

- [ ] Genesis source byte-preserved；
- [ ] Genesis hash 仍为冻结值，除非用户明确授权 amendment；
- [ ] Baseline 只读，Candidate 独立；
- [ ] 变更前 research/evaluation/holdout/review policy seal 完成；
- [ ] Candidate 不能控制 exam、holdout、review packet 或 approval；
- [ ] 当前稳定 release 可完整恢复。

## 13.2 控制面回归

- [ ] 原有 142 项测试或其后继全集全部通过；
- [ ] 新测试全部通过；
- [ ] `verify-self --strict` 通过；
- [ ] `self-test` 有 durable duration 和 output-size evidence；
- [ ] deterministic package 重建 hash 一致；
- [ ] credential scan、manifest、install、upgrade、recovery、rollback 通过；
- [ ] 激活成本不超过已冻结 tolerance；使用现有成本 Gate，不另造宽松阈值。

## 13.3 Outcome benchmark

- [ ] 至少 6 个 target、三个类型；
- [ ] Track A/B/C 分开；
- [ ] 每个 target 至少 20 条 sealed holdout；
- [ ] stochastic trial 至少 3 次；
- [ ] 同模型、runtime、工具权限和预算；
- [ ] raw result 完整保留；
- [ ] subgroup、variance、p50/p95、失败原因可见；
- [ ] protected task 无隐藏负迁移；
- [ ] claim 与 frozen acceptance rule 一致。

## 13.4 外部 review

- [ ] adapter 路径、hash、receipt root 在 run 前冻结；
- [ ] 外部能力真实可用，或明确 BLOCKED；
- [ ] `2×6` seat identity 唯一；
- [ ] final verifier 独立且只读；
- [ ] unresolved CRITICAL 与 hard-domain HIGH 阻断；
- [ ] dissent、unknowns、residual trust 保留；
- [ ] 无本地自签或 Candidate-authored formal receipt。

## 13.5 文档与状态

- [ ] README、SKILL、INSTALL、TASK PACK、RELEASE NOTES、archive 名称一致；
- [ ] control plane、benchmark、outcome、review、engineering release、formal promotion 分域；
- [ ] 未验证 runtime/模型明确标记；
- [ ] 不宣称永久最好；
- [ ] 不把 stars、文件数、reviewer 数量或测试数当作 outcome 证据。

---

# 14. 实施顺序与 Gate

## Stage 0 — 冻结与差异核验

输出：

- baseline identity；
- current tree；
- Genesis 验证；
- 当前测试/安装证据；
- 本交接与仓库现状的 gap list。

**Gate**：基线不明确、Genesis 漂移或稳定版不可恢复时停止。

## Stage 1 — 状态模型与 benchmark 合同

先实现 Schema、状态语义、数据 split、身份绑定和 claim policy，不先写复杂 runner。

**Gate**：Candidate 无法修改合同；状态不能互相伪装。

## Stage 2 — Telemetry

实现 invocation-level token/cost/latency/human burden 证据与 aggregation。

**Gate**：missing 不得变 0；retry 可正确归因。

## Stage 3 — Benchmark runner 与最小 fixture

先用 deterministic fixture 验证完整链路，再接真实模型/runtime。

**Gate**：blind、seal、budget、raw-result retention、negative transfer 测试通过。

## Stage 4 — 高层 orchestration 与恢复

增加 preflight/optimize/status/resume，但保持底层命令与中间产物可见。

**Gate**：中断恢复不改变 immutable identity，不绕过 Gate。

## Stage 5 — 外部 review adapter

完成协议、参考实现、部署说明、integration tests；在现实环境可用时完成真实演练。

**Gate**：无真实外部能力时必须保持 formal blocked。

## Stage 6 — 同场 benchmark

执行 Track A/B/C，保留所有输赢和成本结果。

**Gate**：benchmark integrity 有缺口时 outcome 不得升级为 supported。

## Stage 7 — Candidate release

重跑完整回归、确定性封包、安装、升级、恢复、回滚和文档一致性检查。

**Gate**：只有满足对应状态域条件才写对应 PASS；允许 engineering installable 与 formal blocked 并存。

---

# 15. 最终交付要求

开发线程最终默认只给用户一个 ZIP，例如：

```text
Teleiosis-v0.0.0.2-Candidate-TaskPack.zip
├── source/
│   └── teleiosis/
├── reports/
│   ├── CHANGE_SUMMARY.md
│   ├── BASELINE_AND_DIFF.md
│   ├── TEST_REPORT.md
│   ├── BENCHMARK_REPORT.md
│   ├── REVIEW_STATUS.md
│   └── INSTALL_ROLLBACK_REPORT.md
├── machine/
│   ├── status-summary.json
│   ├── benchmark-contract.json
│   ├── benchmark-results.json
│   ├── test-results.json
│   ├── review-status.json
│   └── MANIFEST.sha256
├── delivery/
│   ├── CODEX_TASK_PACK_v0.0.0.2.md
│   ├── INSTALL.md
│   ├── RELEASE_NOTES.md
│   └── NEXT_HANDOFF.md
├── release/
│   ├── White-Box-Iteration-Skill-Teleiosis-v0.0.0.2-candidate.zip
│   └── SHA256SUMS.txt
└── INVENTORY.txt
```

交付必须明确：

- 哪些事实已验证；
- 哪些只是推断或建议；
- 哪些能力不可用；
- benchmark 是否支持 outcome claim；
- formal promotion 是 PASS、BLOCKED 还是 FAIL；
- 精确 Candidate tree/hash；
- 所有测试、安装、升级、恢复和回滚结果；
- 下一轮 reheat trigger。

---

# 16. 停止条件

以下情况必须停止当前 run，而不是自行放宽规则：

- Genesis hash 或 source 不一致；
- Baseline 无法唯一绑定；
- sealed holdout 泄漏；
- Candidate 获得 exam、review packet 或 approval 写权限；
- 发现 credential/secret；
- 外部 adapter 无法证明独立性却被要求 formal PASS；
- 安装、恢复或回滚状态不明确；
- benchmark 环境/预算不公平且无法重建；
- raw results 缺失，无法复核；
- CRITICAL 或 hard-domain HIGH 未解决；
- 用户未授权的不可逆或跨仓动作；
- 任何需要伪造事实才能继续的情况。

普通性能不佳、Teleiosis benchmark 输给对照、reviewer 意见不一致或 outcome 尚未证明，**不是删证据或修改考试的理由**；应如实输出结果并进入下一次 bounded reheat。

---

# 17. 开发线程启动文本

将下面文字作为开发线程的第一条执行指令：

```text
读取 TELEIOSIS_v0.0.0.2_ITERATION_HANDOFF.md，并把它作为本轮执行合同。

先只读核验 LinzeColin/AgentDatabase 中 CodexSkills/registry/codex/teleiosis 的当前稳定树、公开注册提交、Genesis、release record、测试、安装、恢复和回滚证据；若当前状态晚于交接基线，先输出 delta 并继续采用仍有效的任务。

不得原地覆盖 v0.0.0.1，不得修改或自动重签 Genesis。建立独立 Candidate 与 workspace，在任何 Candidate 修改前冻结研究、benchmark、sealed holdout、review policy、预算和状态语义。

本轮默认目标是 v0.0.0.2-candidate：优先完成可证伪的同场 outcome benchmark、状态分域、真实成本/时延/人工负担证据、外部独立复审 adapter 边界，以及可恢复的高层操作路径。不要以增加流程、文档或 reviewer 数量代替真实 outcome。

缺少真实外部 2×6 独立 SubAgents 与第十三只读 verifier 时，formal autonomous promotion 必须保持 INDEPENDENT_REVIEW_UNAVAILABLE / BLOCKED；不得角色模拟、自签 JSON 或复用上下文。

完成实现、测试、失败修复、benchmark、打包、安装、升级、恢复与回滚验证。最终仅交付一个完整 ZIP，并在其中清楚区分 CONTROL_PLANE、BENCHMARK_INTEGRITY、OUTCOME、COST_EVIDENCE、INDEPENDENT_REVIEW、ENGINEERING_RELEASE 与 FORMAL_PROMOTION 状态。
```

---

# 18. 证据来源

1. Teleiosis 当前公开目录与 README：  
   `https://github.com/LinzeColin/AgentDatabase/tree/main/CodexSkills/registry/codex/teleiosis`
2. Teleiosis `SKILL.md`：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/SKILL.md`
3. 注册提交 `a8f1f6ff8003db43fad722a5afd3b19615dd325e`：  
   `https://github.com/LinzeColin/AgentDatabase/commit/a8f1f6ff8003db43fad722a5afd3b19615dd325e`
4. Evaluation：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/references/EVALUATION.md`
5. Independent Review：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/references/INDEPENDENT_REVIEW.md`
6. Runtime Adapters：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/references/RUNTIME_ADAPTERS.md`
7. Research Sources：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/references/RESEARCH_SOURCES.md`
8. Roadmap：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/delivery/ROADMAP.md`
9. Pursuing Goal：  
   `https://github.com/LinzeColin/AgentDatabase/blob/main/CodexSkills/registry/codex/teleiosis/delivery/PURSUING_GOAL.md`
10. Darwin：  
    `https://github.com/alchaincyf/darwin-skill`
11. Luban Skill 的正确对照项目：  
    `https://github.com/LearnPrompt/luban-skill`

---

# 19. Context Kernel / 跨线程状态块

> 公开仓当前未检索到用户指定路径  
> `CodexSkills/registry/codex/context-kernel`，且 `CodexSkills/index.json` 中未发现 `context-kernel` 条目。以下为不冒充该 Skill 执行结果的手工等价交接。

```yaml
context_kernel:
  mode: MANUAL_FALLBACK
  generated_at: "2026-07-26 Australia/Sydney"
  reason: "Public context-kernel path unavailable/not indexed; private repositories inaccessible."
  mission:
    primary: "Iterate Teleiosis from control-plane strength toward evidence-backed outcome, cost, and external accountability."
    target_candidate: "v0.0.0.2-candidate"
  baseline:
    repository: "LinzeColin/AgentDatabase"
    path: "CodexSkills/registry/codex/teleiosis"
    commit: "a8f1f6ff8003db43fad722a5afd3b19615dd325e"
    version: "v0.0.0.1"
    genesis_sha256: "14ab08b9053db4ca87140e59a49f1de8105a718a87ec2d55590c6487c1a77086"
    engineering_status: "ENGINEERING_FINAL_INSTALLABLE"
    formal_promotion: "INDEPENDENT_REVIEW_UNAVAILABLE / BLOCKED"
    registered_regression_tests: 142
  decisions:
    - "Do not expand governance breadth by default."
    - "Separate control-plane validity from outcome support."
    - "Use separate benchmark tracks for optimization, productization, and assurance."
    - "Measure token, cost, latency, human burden, variance, and recovery."
    - "Preserve formal 2x6 plus distinct read-only verifier boundary."
    - "Add high-level orchestration without hiding low-level commands or evidence."
  hard_constraints:
    - "No Genesis modification or automatic re-signing."
    - "No in-place overwrite of stable baseline."
    - "No Candidate control over exam, sealed holdout, review packet, or approval."
    - "No local self-attestation as formal independence."
    - "No weighted compensation of hard regression."
    - "No unknown cost serialized as zero."
    - "No permanent world-best claim."
    - "One final ZIP deliverable."
  unknowns:
    - "Real equal-budget outcome versus Darwin."
    - "Productization outcome versus Luban."
    - "Marginal value of 12 reviewers."
    - "Availability of a genuinely external attestation runtime."
    - "Cross-runtime and cross-model transfer."
  next_actions:
    - "Freeze and verify current baseline."
    - "Implement status semantics and benchmark contract."
    - "Implement telemetry."
    - "Implement benchmark runner and negative tests."
    - "Implement recoverable high-level orchestration."
    - "Implement external adapter protocol/reference deployment."
    - "Run Track A/B/C benchmark."
    - "Package, install, upgrade, recover, rollback, and deliver evidence."
  stop_conditions:
    - "Genesis drift"
    - "Ambiguous baseline identity"
    - "Holdout leakage"
    - "Secret exposure"
    - "Untrusted formal review evidence"
    - "Irreversible unauthorized action"
    - "Unrecoverable install state"
    - "Missing raw evidence"
  handoff_owner: "Teleiosis Skill development thread"
  repository_landing_owner: "Codex landing thread; copy/commit/push only after acceptance"
```

---

## 最终完成定义

本轮完成不是“文件更多”“测试数更大”或“正式状态全绿”，而是：

> 在不弱化 Genesis、证据边界和可逆交付的前提下，Teleiosis 能对一个冻结任务集给出可复核的真实改善或诚实的未证明结果；能量化实现这种改善的全部成本；能在能力缺失时可靠阻断；能通过外部独立证据而不是自证完成正式责任闭环。
