# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `jethro-tull`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`9fc88f5c85b8278f32d9dd369f14ee0296850d43af1562d026b0e3c937fea134`
- 运行时调用版本：无
- 唯一登记身份：`农林牧渔师`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-independent-agents`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
