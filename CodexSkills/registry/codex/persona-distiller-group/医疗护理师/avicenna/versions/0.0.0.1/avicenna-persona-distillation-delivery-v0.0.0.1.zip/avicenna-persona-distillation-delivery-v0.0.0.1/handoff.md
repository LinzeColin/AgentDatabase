# Avicenna #524
