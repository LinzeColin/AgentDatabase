# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `lou-gerstner`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`2b71de53fa781a545843c400049bf5f0aada2d9cae62d72da4d5deaa8bc9311e`
- 运行时调用版本：无
- 唯一登记身份：`创业经营师`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-independent-agents`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
