# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `robert-a-kindler`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`f041d5a018361baa710c6989e160c6bcba85d71b04c3b640dea882872f41c875`
- 运行时调用版本：无
- 唯一登记身份：`投资资本师`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-serialized-isolation`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
