# Christopher Manning — 人物蒸馏完整交付

这是单一、完整、可校验的交付 ZIP。它包含人物运行时 Skill、安装器、登记卡、团队卡、来源覆盖、评测、验证、provenance 和交接信息。

- 人物产品版本：`0.0.0.1`
- 模型快照：`1.0.0-evidence-grounded`
- 唯一身份：`软件开发师`
- 运行时 SHA-256：`98fa1b9021d0be942423767b805107c9648b000b715c1f5db33ce6bd13100ce6`
- 交付状态：`native-v0.0.0.5`

安装到默认 Codex Skills 目录：

```bash
python3 install.py
```

覆盖同名旧版本：

```bash
python3 install.py --force
```

`0.0.0.N` 只标识已登记人物产品；人物 Skill 的单次调用不编号。人物模型不是本人、授权、背书或实时观点。
