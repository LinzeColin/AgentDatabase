# Directory Manifest

## Workspace summary

- Root: `/mnt/data/howard_marks_build/howard-marks`
- Files: 80
- Total bytes: 624,366

## Top-level counts

- `README.md`: 1 files
- `SKILL.md`: 1 files
- `agents`: 1 files
- `boundaries.md`: 1 files
- `capabilities.md`: 1 files
- `cognitive-os.md`: 1 files
- `corrections`: 2 files
- `decision-policy.md`: 1 files
- `divergence-map.md`: 1 files
- `evals`: 3 files
- `evidence`: 3 files
- `facts.md`: 1 files
- `hypotheses.md`: 1 files
- `identity-catalog.json`: 1 files
- `identity-facets`: 7 files
- `install.ps1`: 1 files
- `install.py`: 1 files
- `install.sh`: 1 files
- `memory`: 5 files
- `meta.json`: 1 files
- `persona.md`: 1 files
- `raw`: 1 files
- `references`: 8 files
- `reports`: 13 files
- `research`: 3 files
- `route-manifest.json`: 1 files
- `runtime`: 1 files
- `scenario-adapters`: 11 files
- `scripts`: 2 files
- `strategy.md`: 1 files
- `team-card.json`: 1 files
- `versions`: 1 files
- `work.md`: 1 files

## Major artifacts

| Path | Bytes | SHA-256 |
|---|---:|---|
| `SKILL.md` | 2,433 | `fe0b47135e28cffbe9347ecc5df55edfc94a1b0ee1ceae69da01385bd8c9f196` |
| `meta.json` | 1,530 | `f767c6d32fae2652cffd24ff439630ba2c0ddf195ced6c565a88057192aaf4ad` |
| `team-card.json` | 2,015 | `d5a1a5db746193a1e8f8764279b8a434476d58678e18d7367bf4d4c966b613d4` |
| `evidence/source-ledger.jsonl` | 71,032 | `8378f14773abbe66ae645c3e4d63946adb4d1d3aa69bfa09dca12608e2749498` |
| `evidence/claims.jsonl` | 36,837 | `d12cba2c549b01f6845156574427a6c499ee7fc008c5933169237702f2eb5604` |
| `evals/cases.jsonl` | 25,110 | `a974e9829974cfcb4a734641cceb85d020ac011c6d61a037e261568c5ccf3226` |
| `evals/results.jsonl` | 74,984 | `a058cda12b5cde8a1a598d228b1f17b91b9b07fa70f323cc5b7404557e5838a1` |
| `reports/Howard-Marks-Persona-Distillation-Report.pdf` | 261,300 | `2e77d1e8c940c6c8c37e24298637e9d5113bd478eca62161de84d9b476024e77` |
| `reports/Howard-Marks-Persona-Distillation-Report.md` | 6,946 | `77542f36b04261948fe103d2532010b06b5ba711c5cad1279658c893bb3ab8fc` |
| `reports/handoff.md` | 5,010 | `a6d3eb01f99422a05f220585da18704436b4a1d1cdb386b533e5880a60ab927d` |

## Full file list

- `README.md` (1,294 bytes)
- `SKILL.md` (2,433 bytes)
- `agents/openai.yaml` (268 bytes)
- `boundaries.md` (1,812 bytes)
- `capabilities.md` (2,633 bytes)
- `cognitive-os.md` (3,003 bytes)
- `corrections/ACTIVE.md` (182 bytes)
- `corrections/corrections.jsonl` (0 bytes)
- `decision-policy.md` (3,038 bytes)
- `divergence-map.md` (2,152 bytes)
- `evals/README.md` (632 bytes)
- `evals/cases.jsonl` (25,110 bytes)
- `evals/results.jsonl` (74,984 bytes)
- `evidence/.gitkeep` (0 bytes)
- `evidence/claims.jsonl` (36,837 bytes)
- `evidence/source-ledger.jsonl` (71,032 bytes)
- `facts.md` (11,496 bytes)
- `hypotheses.md` (852 bytes)
- `identity-catalog.json` (7,170 bytes)
- `identity-facets/developer-designer.md` (623 bytes)
- `identity-facets/entrepreneur-operator.md` (648 bytes)
- `identity-facets/investor-capital-allocator.md` (1,008 bytes)
- `identity-facets/multi-identity.md` (552 bytes)
- `identity-facets/political-legal.md` (623 bytes)
- `identity-facets/technical-engineer.md` (623 bytes)
- `identity-facets/thinker-educator.md` (708 bytes)
- `install.ps1` (72 bytes)
- `install.py` (4,901 bytes)
- `install.sh` (68 bytes)
- `memory/.gitkeep` (0 bytes)
- `memory/episodic.jsonl` (0 bytes)
- `memory/procedural.md` (160 bytes)
- `memory/promotion-queue.md` (150 bytes)
- `memory/user-overlay.md` (145 bytes)
- `meta.json` (1,530 bytes)
- `persona.md` (2,187 bytes)
- `raw/.gitkeep` (0 bytes)
- `references/holdout/.gitkeep` (0 bytes)
- `references/research/01-writings.md` (1,841 bytes)
- `references/research/02-conversations.md` (1,622 bytes)
- `references/research/03-expression.md` (1,390 bytes)
- `references/research/04-external.md` (1,348 bytes)
- `references/research/05-decisions.md` (1,606 bytes)
- `references/research/06-timeline.md` (1,510 bytes)
- `references/sources/.gitkeep` (0 bytes)
- `reports/.gitkeep` (0 bytes)
- `reports/Howard-Marks-Persona-Distillation-Report.md` (6,946 bytes)
- `reports/Howard-Marks-Persona-Distillation-Report.pdf` (261,300 bytes)
- `reports/architect-skeptic-review.md` (1,147 bytes)
- `reports/directory-manifest.md` (5,737 bytes)
- `reports/evaluation-methodology.md` (876 bytes)
- `reports/handoff.md` (5,010 bytes)
- `reports/quality-release-20260723T222154Z.json` (7,263 bytes)
- `reports/quality-release-20260723T222154Z.md` (5,322 bytes)
- `reports/quality-release-20260723T222247Z.json` (2,092 bytes)
- `reports/quality-release-20260723T222247Z.md` (1,917 bytes)
- `reports/quality-release-20260723T223122Z.json` (2,092 bytes)
- `reports/quality-release-20260723T223122Z.md` (1,917 bytes)
- `research/coverage-map.json` (1,922 bytes)
- `research/saturation-report.md` (1,237 bytes)
- `research/source-universe.json` (23,158 bytes)
- `route-manifest.json` (2,871 bytes)
- `runtime/invocations.jsonl` (0 bytes)
- `scenario-adapters/auto.md` (329 bytes)
- `scenario-adapters/communication-negotiation.md` (203 bytes)
- `scenario-adapters/general-agentic-work.md` (281 bytes)
- `scenario-adapters/governance-legal.md` (238 bytes)
- `scenario-adapters/investment-business.md` (257 bytes)
- `scenario-adapters/leadership-organization.md` (203 bytes)
- `scenario-adapters/product-creation.md` (213 bytes)
- `scenario-adapters/red-team-risk.md` (248 bytes)
- `scenario-adapters/research-problem-solving.md` (227 bytes)
- `scenario-adapters/strategy-decision.md` (230 bytes)
- `scenario-adapters/teaching-learning.md` (244 bytes)
- `scripts/runtime_recorder.py` (7,850 bytes)
- `scripts/runtime_router.py` (7,758 bytes)
- `strategy.md` (2,651 bytes)
- `team-card.json` (2,015 bytes)
- `versions/.gitkeep` (0 bytes)
- `work.md` (2,369 bytes)
