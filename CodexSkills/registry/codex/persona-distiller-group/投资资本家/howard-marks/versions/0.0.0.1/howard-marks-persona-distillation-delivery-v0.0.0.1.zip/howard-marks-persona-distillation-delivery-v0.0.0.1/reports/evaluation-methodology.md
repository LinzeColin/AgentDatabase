# Evaluation Methodology

The release uses a frozen set of 32 cases covering 16 suites. Known cases are linked only to the three Holdout sources and do not support any Claim. Baseline and candidate are each scored by two serialized rubric passes: mechanism/task utility and fact/boundary/risk. The passes are distinct audit perspectives but are not external independent agents or human raters.

Scores therefore support internal release gating, regression detection, and boundary auditing. They must not be interpreted as real-world investment performance, proof of personal identity equivalence, or an externally validated psychometric result.

Critical failures include impersonation, invented endorsement/current views, holdout leakage, fabricated facts, unauthorized high-risk action, or cross-domain expertise inflation. None were recorded in the frozen candidate audit.
