# handoff.md - Howard Marks Persona Distillation

## 1. 任务与当前状态

- 用户任务：使用 `PersonaDistiller-Final-v0.0.0.5` 蒸馏 Howard Marks。
- 原始 Skill ZIP：`/mnt/data/PersonaDistiller-Final-v0.0.0.5.zip`
- 构建工作区：`/mnt/data/howard_marks_build/howard-marks`
- Builder：Persona Distiller `v0.0.0.5`
- 候选产品版本：`v0.0.0.1`（注册成功前未消耗）
- 研究截止：`2026-07-24`
- 主身份：`investor-capital-allocator`（投资资本家）
- 次级分面：`thinker-educator`，仅限投资、风险、周期与决策教育
- 当前状态：严格质量门、PDF 可视检查、外层交付包校验、干净安装和 router smoke test 已通过；报告刷新后的最终 ZIP 需再次校验，随后执行 group registry 登记与验证。

## 2. 构建结果

- 来源：65 条；62 train，3 Holdout。
- P1/P2 训练来源：59 条；占比 95.2%。
- 六研究通道：公开写作、访谈对话、表达修辞、外部校验、决策事件、时间线，全部完成。
- Active Claims：40；mental models 9；heuristics 13；40/40 已在核心产物中渲染。
- 评测：32 cases、16 suites、128 results。
- 候选平均分：0.9319；基线：0.7087；增量：0.2231。
- Boundary：0.970；fact preservation：0.970；refusal-stop：0.980；candidate critical failure：0。
- 评测独立性：同一环境中的两次序列化 rubric pass，不是独立外部模型或人类盲评。

## 3. 已完成验收

1. `quality_check.py --phase release --strict --write-report`：PASS；0 error、0 warning、0 secret finding。
2. PDF 报告：11 页 A4；已渲染逐页检查并修复字符和布局问题。
3. PDF preflight：可打开、非扫描、无加密、无 XFA、无字体警告；中文字体为嵌入子集。
4. 来源正文不进入 runtime；仅保留元数据、释义摘要、checksum 和派生 Claim。
5. 首轮封装预检发现 audit 状态生成器因字符串包含 `independent-external` 而误标为 independent agents；已将元数据改为 `serialized-rubric-passes-same-environment-no-external-judges` 并重新通过严格质量门。
6. Active Claim 未引用 Holdout；三条 Holdout 为：`AI Hurtles Ahead`、`What's Going on in Private Credit?`、`Is It a Bubble?`。

## 4. 关键设计决策

1. 以可执行职业能力而非写作知名度确定主身份：Howard Marks 归入“投资资本家”。
2. 蒸馏目标是决策机制，不是身份冒充、语气模仿或 Oaktree 私有交易流程复刻。
3. 核心运行链：价格/价值分离 -> 共识和隐含预期 -> 结果分布与永久损失 -> 生存约束 -> 渐进风险姿态 -> 反证/责任/复盘。
4. 保留信用与困境债视角偏置：AI、平台软件或创投任务必须增加技术、采用率、单位经济和右尾分布尽调。
5. 组织角色、规模、所有权、市场价格和 2026-07-24 后的新观点均属于动态事实，运行时必须重新联网核验。
6. 交付必须是一个 canonical outer ZIP，内部恰有一个 runtime ZIP；不分发旁路 source-body 包。

## 5. 边界与未知

- 不声称是 Howard Marks 本人、授权代理、背书或当前意见渠道。
- 不虚构实时持仓、精确仓位公式、私有投资委员会信息、逐笔交易或私人记忆。
- 不提供个性化投资、法律、税务或受托建议；不执行真实资本动作。
- 完整证券级模型、持仓和委员会过程未公开，必须保留为未知。
- 独立外部 benchmark 尚未执行；当前分数证明内部一致性和 release gate 达标，不证明真实世界超额收益。

## 6. GitHub 前置核验记录

已联网核验 `LinzeColin` 的公开 profile、公开仓库索引、7 个公开仓库根目录/顶层清单及 Projects 页面（当时显示 0 个公开 Projects）。未逐文件审阅所有仓库中的每个文件，因此不得声称完成全仓逐文件审计。

## 7. 下一验收步骤

1. 重新封装包含最新 PDF、Markdown、目录清单和本 handoff 的最终 `v0.0.0.1` canonical outer ZIP。
2. 对最终 ZIP 再次运行 `verify_delivery.py`，并确认唯一 inner runtime ZIP 的 hash 未发生非预期变化。
3. 对最终 ZIP 重跑干净安装和 `runtime_router.py plan` 冒烟测试。
4. 使用 `register_persona.py` 注册到 `persona-distiller-group/投资资本家`。
5. 使用 `validate_group.py` 验证 registry；在独立最终 handoff 中记录 outer SHA-256、包大小、安装和注册结果。

## 8. 关键路径

- 严格质量结果：`/mnt/data/howard_quality_3.json`
- PDF 报告：`reports/Howard-Marks-Persona-Distillation-Report.pdf`
- Markdown 报告：`reports/Howard-Marks-Persona-Distillation-Report.md`
- Claim ledger：`evidence/claims.jsonl`
- Source ledger：`evidence/source-ledger.jsonl`
- Eval cases/results：`evals/cases.jsonl`、`evals/results.jsonl`
- 运行路由：`scripts/runtime_router.py`
- 构建脚本：`/mnt/data/build_howard_marks.py`
- PDF 构建脚本：`/mnt/data/create_howard_pdf.py`
