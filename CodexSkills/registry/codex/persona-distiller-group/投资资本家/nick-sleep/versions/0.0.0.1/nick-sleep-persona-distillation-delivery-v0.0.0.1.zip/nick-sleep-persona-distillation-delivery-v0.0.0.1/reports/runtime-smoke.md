# Runtime smoke test

- Executed: 2026-07-24
- Result: **PASS**
- Invocation versioning: disabled
- User identity selection: not required
- Runtime audit: valid and unnumbered

## Case 1 — retail compounder analysis

Task: 分析一家零售企业是否具备可长期复利的商业模型

```json
{
  "execution_loop": [
    "model-task",
    "retrieve-minimum",
    "plan-as-target",
    "act-with-host-tools",
    "verify-facts-results-and-risks",
    "deliver",
    "optionally-record-unnumbered-audit"
  ],
  "identity_route": {
    "mode": "single",
    "primary": "investor-capital-allocator",
    "source": "distilled-route-manifest",
    "strategy": "automatic-task-routing",
    "user_selection_required": false,
    "weights": {
      "investor-capital-allocator": 1.0
    }
  },
  "load_files": [
    "boundaries.md",
    "corrections/ACTIVE.md",
    "facts.md",
    "identity-facets/investor-capital-allocator.md",
    "cognitive-os.md",
    "decision-policy.md",
    "strategy.md",
    "capabilities.md",
    "work.md",
    "persona.md",
    "scenario-adapters/investment-business.md",
    "scenario-adapters/red-team-risk.md",
    "divergence-map.md"
  ],
  "output_contract": {
    "audit": "optional unnumbered runtime/invocations.jsonl record",
    "chat_version_label": false,
    "invocation_version": null,
    "versioned_file_names": false
  },
  "route_basis": {
    "internal_identity_priors_used": [
      "red-team-risk"
    ],
    "primary_basis": "task-keywords",
    "task_keyword_scores": {
      "investment-business": 1
    },
    "user_identity_input": false
  },
  "scenarios": [
    "investment-business",
    "red-team-risk"
  ],
  "warning": "Do not load source bodies, all research files, unavailable identity facets, or full runtime history unless an evidence audit explicitly requires them."
}
```

## Case 2 — long-term capital allocation and governance

Task: 设计长期资本配置与治理方案

```json
{
  "execution_loop": [
    "model-task",
    "retrieve-minimum",
    "plan-as-target",
    "act-with-host-tools",
    "verify-facts-results-and-risks",
    "deliver",
    "optionally-record-unnumbered-audit"
  ],
  "identity_route": {
    "mode": "single",
    "primary": "investor-capital-allocator",
    "source": "distilled-route-manifest",
    "strategy": "automatic-task-routing",
    "user_selection_required": false,
    "weights": {
      "investor-capital-allocator": 1.0
    }
  },
  "load_files": [
    "boundaries.md",
    "corrections/ACTIVE.md",
    "facts.md",
    "identity-facets/investor-capital-allocator.md",
    "cognitive-os.md",
    "decision-policy.md",
    "strategy.md",
    "capabilities.md",
    "work.md",
    "persona.md",
    "scenario-adapters/governance-legal.md",
    "scenario-adapters/investment-business.md",
    "divergence-map.md"
  ],
  "output_contract": {
    "audit": "optional unnumbered runtime/invocations.jsonl record",
    "chat_version_label": false,
    "invocation_version": null,
    "versioned_file_names": false
  },
  "route_basis": {
    "internal_identity_priors_used": [],
    "primary_basis": "task-keywords",
    "task_keyword_scores": {
      "governance-legal": 1,
      "investment-business": 1,
      "product-creation": 1
    },
    "user_identity_input": false
  },
  "scenarios": [
    "governance-legal",
    "investment-business"
  ],
  "warning": "Do not load source bodies, all research files, unavailable identity facets, or full runtime history unless an evidence audit explicitly requires them."
}
```

## Case 3 — teaching route with a provisional secondary facet

Task: 为商学院学生设计一节耐心资本教学课程：解释概念、安排学习练习和反例

```json
{
  "execution_loop": [
    "model-task",
    "retrieve-minimum",
    "plan-as-target",
    "act-with-host-tools",
    "verify-facts-results-and-risks",
    "deliver",
    "optionally-record-unnumbered-audit"
  ],
  "identity_route": {
    "mode": "single",
    "primary": "investor-capital-allocator",
    "source": "distilled-route-manifest",
    "strategy": "automatic-task-routing",
    "user_selection_required": false,
    "weights": {
      "investor-capital-allocator": 1.0
    }
  },
  "load_files": [
    "boundaries.md",
    "corrections/ACTIVE.md",
    "facts.md",
    "identity-facets/investor-capital-allocator.md",
    "cognitive-os.md",
    "decision-policy.md",
    "strategy.md",
    "capabilities.md",
    "work.md",
    "persona.md",
    "scenario-adapters/teaching-learning.md",
    "scenario-adapters/investment-business.md",
    "divergence-map.md"
  ],
  "output_contract": {
    "audit": "optional unnumbered runtime/invocations.jsonl record",
    "chat_version_label": false,
    "invocation_version": null,
    "versioned_file_names": false
  },
  "route_basis": {
    "internal_identity_priors_used": [],
    "primary_basis": "task-keywords",
    "task_keyword_scores": {
      "investment-business": 1,
      "product-creation": 1,
      "teaching-learning": 4
    },
    "user_identity_input": false
  },
  "scenarios": [
    "teaching-learning",
    "investment-business"
  ],
  "warning": "Do not load source bodies, all research files, unavailable identity facets, or full runtime history unless an evidence audit explicitly requires them."
}
```

## Recorder verification

```json
{
  "errors": [],
  "numbered_records": 0,
  "record_count": 0,
  "valid": true
}
```

## Interpretation

All tasks route automatically from the distilled single primary identity. Investment/business, governance/risk, and teaching adapters are loaded only when task keywords justify them; no per-invocation version or numbered run directory is created. The teaching task remains grounded in the investor model and uses the thinker-educator facet only provisionally.

## Clean-install rehearsal

A complete delivery candidate for product `0.0.0.1` was extracted into a new temporary directory and installed with the outer installer into an empty Skills root. The outer checksum set verified 19 payload files; the embedded runtime installer verified 48 checksummed runtime files before and after installation. The installed runtime contained 51 files including its manifests, had empty `runtime/invocations.jsonl` and `memory/episodic.jsonl`, produced the expected automatic investor-capital-allocator route, and passed `runtime_recorder.py verify` with zero numbered records and zero errors.
