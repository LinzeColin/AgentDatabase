# Refinement Architect review

## Role and isolation

This is a serialized Architect pass over the accepted evidence graph, rendered model, evaluation packet, and baseline/candidate traces. It did not read sealed Holdout bodies while proposing Claim changes. It is not an independent external-agent review.

## Smallest causal defects identified

### 1. Joint-authorship collapse

A generic “Nick Sleep” persona can silently turn jointly authored Nomad material into solo authorship. That would corrupt factual attribution and encourage fabricated first-person memory.

- Relevant Claims: `clm-fb5c28a2daa5`, `clm-cb0f5dd79194`, `clm-68af631c1640`, `clm-cdf117101e65`, `clm-8263544c7723`.
- Minimal patch: make Sleep–Zakaria the default attribution in `facts.md`, `persona.md`, `divergence-map.md`, and `boundaries.md`; reserve Nick-only attribution for solo speech or signature evidence.
- Expected suites: fact-preservation, boundary, voice, anonymous-fidelity.

### 2. Temporal collapse

The mature quality-compounder framework risks being projected back onto an early period that included discounted assets and cigar-butt investing.

- Relevant Claims: `clm-a97e80b54185`, `clm-71e7b712c72a`.
- Minimal patch: encode a three-stage trajectory and require the runtime to select the relevant period before transferring a rule.
- Expected suites: trajectory, contrast, task-completion.

### 3. Exit-level conflation

Closing a fund vehicle can be misread as selling every holding or losing confidence in the underlying businesses.

- Relevant Claims: `clm-872e05dc07b9`, `clm-9cecad949c2d`, `clm-e40074588068`.
- Minimal patch: separate asset thesis, security valuation, institutional vehicle, professional role, and life objective in `strategy.md`, `decision-policy.md`, and `divergence-map.md`.
- Expected suites: trajectory, fact-preservation, long-horizon.

### 4. Patience becoming thesis inertia

“Do not sell merely because price rose” can overfit into “never sell,” especially under concentration.

- Relevant Claims: `clm-0fca34c8523d`, `clm-37ef4652aad9`, `clm-be38ce460a29`, `clm-dd3dd79d3a0f`.
- Minimal patch: require periodic destination re-underwriting, a no-position re-buy test, explicit falsifiers, and hard stops for mechanism fracture or survival risk.
- Expected suites: refusal-stop, long-horizon, contrast, token-efficiency.

### 5. Current-fact and cross-domain leakage

Historical investment reasoning can be mistaken for current holdings, present endorsement, individualized advice, or technical/medical/legal expertise.

- Relevant Claims: `clm-3c8f6a8220b8`, `clm-aa7683ef28ea`, `clm-1094b7b33be6`, `clm-b84c725bc165`, `clm-4710c8284910`, `clm-177c8dc8f420`.
- Minimal patch: separate live verification from persona reasoning; downgrade non-investment facets; require accountable specialists for high-stakes domains.
- Expected suites: boundary, tool-use, capability-calibration, identity-routing.

## Patch proposal

Apply only the five controls above. Do not add biography, slogans, psychological diagnoses, private motives, or generic expert prose. Keep the core runtime compact: destination → mechanism → probabilities → incentives/capital duration → downside/opportunity cost → falsifiers/exit.

## Required regression tests

Rerun all 16 suites, with special gates on boundary, fact-preservation, trajectory, refusal-stop, tool-use, capability-calibration, long-horizon, identity-routing, and token-efficiency. Also rerun strict source/Claim validation, automatic route smoke tests, secret scanning, package validation, and clean installation.

## Rollback condition

Rollback any patch that lowers fact preservation, creates solo-authorship claims, turns live facts into model memory, increases cross-domain authority, makes routing nondeterministic, or adds prose without a measurable decision-policy change.

## Architect verdict

**Promote the minimal controls for Skeptic review.** They repair causal errors rather than merely increasing stylistic resemblance.
