# Refinement ratchet record

## Snapshot

- Profile: `deep`
- Research cutoff: `2026-07-24`
- Sources: 55 total; 51 train; 4 sealed Holdout
- Primary-source ratio in train: 78.43%
- Active Claims: 72
- Evaluation: 16 suites × 2 cases; 128 baseline/candidate judge records
- Judge method: two serialized sealed-context rubric passes; not independent external agents

## Accepted minimal patches

| Patch | Files | Primary failure prevented | Status |
|---|---|---|---|
| Default joint attribution to Sleep–Zakaria | `facts.md`, `persona.md`, `divergence-map.md`, `boundaries.md` | Solo-authorship fabrication | Kept |
| Encode early discount-to-late compounder trajectory | `strategy.md`, `divergence-map.md` | Temporal collapse | Kept |
| Separate asset, price, vehicle, profession, life objective | `decision-policy.md`, `strategy.md`, `divergence-map.md` | Closure/sale conflation | Kept |
| Add destination re-underwrite, falsifiers, no-position test | `decision-policy.md`, `work.md`, `boundaries.md` | Thesis inertia under concentration | Kept |
| Require live verification and cross-domain downgrade | `capabilities.md`, `work.md`, `boundaries.md`, route facets | Current-fact and capability hallucination | Kept |

## Regression outcome

Candidate overall: `0.9503`; baseline: `0.5556`; delta: `+0.3947`.

Critical suite means:

- Boundary: `0.9650`
- Fact preservation: `0.9750`
- Trajectory: `0.9550`
- Tool use: `0.9650`
- Capability calibration: `0.9700`
- Refusal/stop: `0.9750`
- Long horizon: `0.9450`
- Identity routing: `0.9550`

No candidate critical failure was recorded. Strict research and synthesis gates passed without warnings.

## Why no further prose patch was accepted

The remaining limitations—edited public writing, sparse unscripted pressure evidence, joint authorship, incomplete transaction-level attribution, and serialized rather than external evaluation—cannot be repaired by adding personality text. They are preserved as confidence limits and release disclosures.

## Rollback rule

A future update is promoted only when it adds source-grounded behavioral value and does not regress boundary, fact preservation, routing determinism, token efficiency, package integrity, or clean installation. Otherwise restore the prior registered product.
