# Refinement Skeptic / red-team review

## Role and independence disclosure

This is a separately labeled, serialized Skeptic pass with sealed evaluation inputs. It is not an independently running external model. The weaker independence is recorded in `meta.json`, `evals/README.md`, and delivery audit files.

## Challenges to the Architect proposal

### Holdout leakage

The four Holdout source IDs appear only in known-case metadata and sealed evaluation storage. They are absent from active Claim support and rendered model evidence. The proposed patches are supported by training Claims and primary sources, not by Holdout summaries. **No leakage found.**

### Overfitting to evaluation prompts

The proposed controls are general rules—joint attribution, period selection, exit-level separation, live verification, and falsifier-driven stopping—not phrases copied from a single case. They affect multiple suites and runtime tasks. **Low prompt-overfit risk.**

### Temporal and audience confounding

The early/late split is necessary, but it must not imply a clean overnight conversion. The final model correctly presents a gradual transition and uses “about” or phase language. The partner-letter voice must remain an output method, not evidence that every audience should receive a long letter. `persona.md` explicitly permits compression for simple tasks. **Accepted.**

### Generic-expert collapse

The investment framework transfers only as a bounded lens. Entrepreneur and thinker facets remain provisional; technical, legal/political, and engineering facets remain unavailable. Philanthropy is restricted to public capital-allocation principles and does not confer program-operation or medical expertise. **Accepted.**

### Thesis-inertia regression

The most dangerous failure would be using “price is not a sell signal” to suppress material business evidence. The final `decision-policy.md`, `work.md`, and `boundaries.md` require mechanism review, probability updates, no-position re-buy tests, and stopping when evidence or downside cannot be verified. **Accepted with hard-stop retention.**

### Factual and identity risk

The model does not claim to be Nick Sleep, sign for him, disclose private holdings, or provide current recommendations. Joint-authorship language is repeated across facts, persona, divergence, and boundaries, which is justified redundancy for a high-impact failure mode. **Accepted.**

### Evaluation independence and coverage limitation

Two judge IDs represent serialized sealed rubric passes, not independent external judges. The package must not describe them as external evidence. The build includes a baseline and anonymous-fidelity conditions, but not a separately generated neighboring-person foil system; the contrast suite partly covers that risk. This is a disclosed evaluation limitation, not a reason to falsify additional evidence. Future refinement should add a true external foil only when an independent execution context exists.

## Required suites before promotion

All 16 suites, with explicit review of:

- `boundary` and `fact-preservation` for identity/current-fact integrity;
- `trajectory` for early/late and vehicle/asset separation;
- `refusal-stop` and `long-horizon` for thesis inertia;
- `tool-use` and `capability-calibration` for live verification and cross-domain limits;
- `identity-routing` and `token-efficiency` for deterministic, compact execution.

## Skeptic verdict

**ACCEPT with disclosed serialized-evaluation limitation.** No Claim-strength increase, Holdout leakage, private-motive inference, or capability inflation is required. Keep all five minimal controls and reject any future patch that turns them into slogans without executable checks.
