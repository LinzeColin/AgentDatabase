# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `seth-klarman`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`de3c403f60159b7d2669700fc177ac568f7caee24781a4a7e6701f8d815ecc7b`
- 运行时调用版本：无
- 唯一登记身份：`投资资本家`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-independent-agents`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
