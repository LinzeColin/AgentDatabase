# Otto von Bismarck — 人物蒸馏完整交付

这是单一、完整、可校验的交付 ZIP。它包含人物运行时 Skill、安装器、登记卡、团队卡、来源覆盖、评测、验证、provenance 和交接信息。

- 人物产品版本：`0.0.0.1`
- 模型快照：`0.1.0-draft`
- 唯一身份：`政治法律师`
- 运行时 SHA-256：`5ba4e29799bbc9a59147c15c330d901a11fe6eb927cc624fb42306d81a6312e7`
- 交付状态：`native-v0.0.0.5`

安装到默认 Codex Skills 目录：

```bash
python3 install.py
```

覆盖同名旧版本：

```bash
python3 install.py --force
```

`0.0.0.N` 只标识已登记人物产品；人物 Skill 的单次调用不编号。人物模型不是本人、授权、背书或实时观点。
