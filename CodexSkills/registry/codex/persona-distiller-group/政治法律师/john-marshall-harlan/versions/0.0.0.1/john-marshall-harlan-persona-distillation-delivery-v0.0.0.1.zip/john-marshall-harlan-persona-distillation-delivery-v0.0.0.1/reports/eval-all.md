# Evaluation aggregate

- Run: `all`
- Profile: `quick`
- Result: **PASS**
- Candidate overall: `0.9105`
- Baseline overall: `0.8488`
- Delta: `0.0617`

## Gates

- PASS: `candidate_overall`
- PASS: `baseline_delta`
- PASS: `boundary`
- PASS: `fact_preservation`
- PASS: `no_candidate_critical_failure`
- PASS: `has_results`

## Suite means

```json
{
  "known": {
    "baseline": 0.8625,
    "candidate": 0.895
  },
  "boundary": {
    "baseline": 0.865,
    "candidate": 0.94
  },
  "voice": {
    "baseline": 0.785,
    "candidate": 0.9375
  },
  "trajectory": {
    "baseline": 0.85,
    "candidate": 0.89
  },
  "contrast": {
    "baseline": 0.845,
    "candidate": 0.895
  },
  "fact-preservation": {
    "baseline": 0.8675,
    "candidate": 0.9075
  },
  "style-decoy": {
    "baseline": 0.855,
    "candidate": 0.925
  },
  "task-completion": {
    "baseline": 0.83,
    "candidate": 0.925
  },
  "planning-fidelity": {
    "baseline": 0.855,
    "candidate": 0.915
  },
  "tool-use": {
    "baseline": 0.865,
    "candidate": 0.8775
  },
  "capability-calibration": {
    "baseline": 0.8475,
    "candidate": 0.9325
  },
  "refusal-stop": {
    "baseline": 0.8625,
    "candidate": 0.94
  },
  "long-horizon": {
    "baseline": 0.8375,
    "candidate": 0.875
  },
  "identity-routing": {
    "baseline": 0.8625,
    "candidate": 0.935
  },
  "anonymous-fidelity": {
    "baseline": 0.8325,
    "candidate": 0.885
  },
  "token-efficiency": {
    "baseline": 0.8575,
    "candidate": 0.8925
  }
}
```

## Critical failures

- None

## Errors

- None
