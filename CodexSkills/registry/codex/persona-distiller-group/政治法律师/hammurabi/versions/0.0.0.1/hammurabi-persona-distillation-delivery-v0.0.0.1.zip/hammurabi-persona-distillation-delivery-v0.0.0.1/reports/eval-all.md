# Evaluation aggregate

- Run: `all`
- Profile: `quick`
- Result: **PASS**
- Candidate overall: `0.8497`
- Baseline overall: `0.8173`
- Delta: `0.0324`

## Gates

- PASS: `candidate_overall`
- PASS: `baseline_delta`
- PASS: `boundary`
- PASS: `fact_preservation`
- PASS: `no_candidate_critical_failure`
- PASS: `has_results`

## Suite means

```json
{
  "known": {
    "baseline": 0.805,
    "candidate": 0.8225
  },
  "boundary": {
    "baseline": 0.8275,
    "candidate": 0.8625
  },
  "voice": {
    "baseline": 0.835,
    "candidate": 0.8425
  },
  "trajectory": {
    "baseline": 0.8275,
    "candidate": 0.835
  },
  "contrast": {
    "baseline": 0.84,
    "candidate": 0.8475
  },
  "fact-preservation": {
    "baseline": 0.7625,
    "candidate": 0.84
  },
  "style-decoy": {
    "baseline": 0.8025,
    "candidate": 0.8675
  },
  "task-completion": {
    "baseline": 0.68,
    "candidate": 0.8425
  },
  "planning-fidelity": {
    "baseline": 0.7925,
    "candidate": 0.85
  },
  "tool-use": {
    "baseline": 0.825,
    "candidate": 0.825
  },
  "capability-calibration": {
    "baseline": 0.845,
    "candidate": 0.8625
  },
  "refusal-stop": {
    "baseline": 0.8525,
    "candidate": 0.85
  },
  "long-horizon": {
    "baseline": 0.845,
    "candidate": 0.8675
  },
  "identity-routing": {
    "baseline": 0.84,
    "candidate": 0.855
  },
  "anonymous-fidelity": {
    "baseline": 0.8525,
    "candidate": 0.8675
  },
  "token-efficiency": {
    "baseline": 0.845,
    "candidate": 0.8575
  }
}
```

## Critical failures

- None

## Errors

- None
