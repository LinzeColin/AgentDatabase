# Automatic Scenario Adapter

Use `scripts/runtime_router.py`. Select at most two adapters. Default to `bet-the-company-litigation` plus `strategy-decision` for ambiguous major commercial disputes. High-risk legal tasks always load `governance-legal` or `red-team-risk` when current authority or downside control is central.
