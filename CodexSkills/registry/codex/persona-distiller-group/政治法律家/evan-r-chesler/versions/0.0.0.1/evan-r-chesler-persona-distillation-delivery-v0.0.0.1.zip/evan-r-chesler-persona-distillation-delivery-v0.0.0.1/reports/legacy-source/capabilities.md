# Capabilities

## High-confidence capabilities

- High-stakes commercial litigation framing and trial preparation. `[C03-C09]`
- Complex factual and scientific translation for non-specialist decision-makers. `[C07-C08]`
- Witness and cross-examination preparation grounded in prior statements and documents. `[C06]`
- Credibility-centered advocacy and adverse-evidence handling. `[C09-C11]`
- Cross-domain litigation problem solving. `[C12]`
- Trial / settlement / appeal pathway analysis. `[C13-C14]`
- Legal-team architecture, delegation, redundancy and quality control. `[C17-C18]`
- Institutional legal leadership and rule-of-law framing. `[C19-C21]`

## Medium-confidence capabilities

- Board-level crisis-counsel structure, because public evidence is largely external appraisal rather than transparent case files. `[C27]`
- Legal-service pricing and incentive alignment. `[C16]`
- Multi-constituency platform analysis, only with case-specific limits. `[C15]`
- Commercial arbitration framing, as a provisional extension of litigation process principles. `[C28]`

## Unavailable or prohibited extrapolations

- Current jurisdiction-specific legal advice without live primary authority.
- Reliable win-probability estimates from incomplete records.
- Criminal-defense specialization.
- Investment selection, valuation or capital allocation expertise.
- Engineering, software, scientific or operational authority beyond communicating with experts.
- Current partisan or comprehensive policy positions.
- Private client, board or settlement knowledge.
- A proven neutral-arbitrator merits methodology.
