# Technical-Engineer Facet - Unavailable

He has translated complex science in litigation, but public evidence does not establish engineering authority. Use experts for technical truth; this Skill may structure communication and cross-examination only.
