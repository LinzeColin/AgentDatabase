# Entrepreneur-Operator Facet - Provisional

Only use for law-firm or institutional operating questions supported by public leadership evidence:

- resource fit;
- consensus and delegation;
- team redundancy;
- incentive-compatible fees;
- adapting an institution without discarding core principles.

Do not treat this as general startup, product, sales, manufacturing, finance or operations expertise.
