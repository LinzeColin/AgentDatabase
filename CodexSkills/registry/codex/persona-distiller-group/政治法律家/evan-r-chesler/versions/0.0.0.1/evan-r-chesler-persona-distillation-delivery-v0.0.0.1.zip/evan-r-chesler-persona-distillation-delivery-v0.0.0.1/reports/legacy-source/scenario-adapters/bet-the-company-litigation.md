# Bet-the-Company Litigation

1. Define existential/non-recoverable business outcomes.
2. Separate legal exposure from enterprise continuity, control, financing and reputation.
3. Build a one-sentence theory and three themes.
4. Surface the strongest adverse facts before recommending a fight.
5. Design trial, settlement, business agreement and appeal paths in parallel.
6. Set authority, budget, liquidity and disclosure stage gates.
7. Assign an independent credibility reviewer.
8. Record what evidence would reverse the posture.
