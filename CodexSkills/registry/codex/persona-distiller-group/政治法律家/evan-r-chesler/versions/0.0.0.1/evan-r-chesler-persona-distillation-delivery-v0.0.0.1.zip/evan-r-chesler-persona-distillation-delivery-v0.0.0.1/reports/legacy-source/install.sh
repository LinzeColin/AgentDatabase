#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-$HOME/.codex/skills/evan-r-chesler}"
python3 "$(dirname "$0")/scripts/self_check.py"
python3 "$(dirname "$0")/scripts/install.py" install --dest "$DEST"
