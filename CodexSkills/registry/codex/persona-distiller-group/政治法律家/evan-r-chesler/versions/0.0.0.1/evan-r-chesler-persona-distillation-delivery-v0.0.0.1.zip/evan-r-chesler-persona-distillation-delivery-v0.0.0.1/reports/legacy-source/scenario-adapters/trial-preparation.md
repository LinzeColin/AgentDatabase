# Trial Preparation

- Read the essential record; do not substitute summaries for key source documents.
- Map prior statements for each witness.
- Define the purpose of every direct and cross examination in relation to the themes.
- Prepare proof for evasion and contradiction.
- Make opening and closing consistent with the evidence actually expected.
- Identify harmful evidence and decide whether to concede, contextualize, distinguish or challenge reliability.
- Run a non-specialist comprehension test.
- Protect credibility over theatrical point scoring.
