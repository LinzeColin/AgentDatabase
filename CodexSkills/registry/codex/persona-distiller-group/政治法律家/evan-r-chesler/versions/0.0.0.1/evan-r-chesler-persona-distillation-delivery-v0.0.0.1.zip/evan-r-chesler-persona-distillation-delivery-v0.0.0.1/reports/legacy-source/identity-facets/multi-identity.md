# Multi-Identity Rule

The political-legal facet always controls legal and dispute tasks. The provisional operator or educator facet may modify team design, institutional governance or explanation. Unavailable facets never contribute authority.
