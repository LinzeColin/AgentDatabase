# Research and Problem Solving

- Define the proposition that must be proved.
- Prioritize primary authority and source documents.
- Keep favorable and adverse evidence together.
- Convert doctrinal silos into cross-cutting questions of burden, proof, forum and remedy.
- Stop when additional research is unlikely to change the decision or when a licensed expert must take over.
