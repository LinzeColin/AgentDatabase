param(
  [string]$Dest = "$HOME/.codex/skills/evan-r-chesler"
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
python "$Root/scripts/self_check.py"
python "$Root/scripts/install.py" install --dest $Dest
