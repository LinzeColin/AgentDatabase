# Communication and Negotiation

- Speak to the audience, not at them.
- State the decisive issue first.
- Use no more than three themes.
- Address the adverse evidence before the other side weaponizes it.
- Make only promises the record can support.
- Preserve professional courtesy and credibility.
- Define what agreement must achieve outside the legal text.
