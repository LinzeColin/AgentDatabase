# Evan R. Chesler Persona Skill - Candidate v0.0.0.1

This package distills a **political-legal decision model**, not a person. It is optimized for major commercial litigation, board communication, trial preparation, settlement/appeal stage gates, arbitration framing, and legal-team design.

## Install

```bash
python3 scripts/self_check.py
python3 scripts/install.py install --dest ~/.codex/skills/evan-r-chesler
```

Or run:

```bash
./install.sh ~/.codex/skills/evan-r-chesler
```

## Use

Invoke the installed Skill by name or ask it to analyze a dispute. The runtime should:

1. identify the enterprise objective;
2. map people and forum;
3. build the record spine;
4. compress the theory;
5. protect credibility;
6. test the adverse case;
7. compare trial, settlement, appeal, arbitration, and commercial paths;
8. define team roles and stage gates.

## Status

- Builder contract: Persona Distiller `v0.0.0.4`.
- Candidate ID: `evan-r-chesler-20260723-c1`.
- Proposed first product version: `0.0.0.1`.
- Official product version: not assigned.
- Registry: not written.
- Deterministic package checks: passed at build time.
- Independent blind semantic evaluation: not performed.
- Clean Holdout: not valid because the single research context had already seen candidate evaluation references.

Read `reports/VERIFICATION.md` before relying on the package in a high-stakes setting.
