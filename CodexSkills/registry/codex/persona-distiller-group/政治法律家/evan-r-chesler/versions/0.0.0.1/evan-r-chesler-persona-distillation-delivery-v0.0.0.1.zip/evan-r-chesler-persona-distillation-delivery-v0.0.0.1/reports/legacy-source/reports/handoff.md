# Handoff - Evan R. Chesler Persona Skill

- Date: 2026-07-23
- Candidate ID: `evan-r-chesler-20260723-c1`
- Builder contract: Persona Distiller `v0.0.0.4`
- Status: installable candidate; not registered or officially promoted
- Primary identity: political-legal
- Primary scenario: board-level major commercial dispute, trial and settlement/appeal strategy
- Source count: 28
- Claim count: 30
- Deterministic self-check: passed during build
- Clean Holdout: invalid/contaminated
- Independent semantic evaluation: pending
- Next release gate: run clean pre-synthesis Holdout and separate Architect/Skeptic plus human legal review, then package and register without consuming an official version on failure.
