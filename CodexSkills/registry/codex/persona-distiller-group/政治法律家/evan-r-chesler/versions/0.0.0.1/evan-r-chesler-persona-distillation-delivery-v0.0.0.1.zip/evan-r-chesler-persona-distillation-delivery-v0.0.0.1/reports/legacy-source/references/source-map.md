# Source Map

## Six research lanes

1. **Official identity and current roles:** Cravath, Chesler Arbitration, NYU/IJA.
2. **Direct statements and authored work:** trial Q&As, NYU interview, billable-hour position, AmEx article.
3. **Trial behavior and technique:** witness preparation, theme compression, audience translation, opening/closing structure.
4. **Case record and outcomes:** American Express district/appellate/Supreme Court trajectory and primary opinion.
5. **Leadership and institutional work:** Cravath operating model, team design, consensus, resource fit, rule-of-law values.
6. **External validation and counterweight:** peer/mentee profiles, reported loss, dissent, capability boundaries.

## Coverage result

- Sources registered: 28.
- Model sources: 24.
- Candidate evaluation references: 4.
- Clean Holdout: invalid; all evaluation references were visible to the single build context and are marked contaminated.
- Claims: 30; none cites contaminated evaluation references.
- Time range: 2006-2026 with older career episodes discussed in later sources.
- Strongest evidence density: trial preparation, credibility, audience translation, leadership and current role.
- Material gaps: confidential board advice, settlement thresholds, neutral-arbitrator decisions, comprehensive current political views.
