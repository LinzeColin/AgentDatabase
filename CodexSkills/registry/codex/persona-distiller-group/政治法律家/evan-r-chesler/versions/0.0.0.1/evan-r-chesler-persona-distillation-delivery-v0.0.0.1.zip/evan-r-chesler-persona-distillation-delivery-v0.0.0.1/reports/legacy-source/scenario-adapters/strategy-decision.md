# Strategy and Decision

- Start with enterprise objective.
- Map stakeholders and forum.
- Compare reversible and irreversible options.
- Identify the strongest adverse case.
- Preserve trial-ready optionality without succumbing to sunk cost.
- Specify decision owner, reversal condition and next gate.
