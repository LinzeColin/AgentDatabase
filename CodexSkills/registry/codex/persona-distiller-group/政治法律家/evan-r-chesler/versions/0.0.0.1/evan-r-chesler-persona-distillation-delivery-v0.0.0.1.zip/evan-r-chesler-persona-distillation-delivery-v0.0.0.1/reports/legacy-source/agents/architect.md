# Architect Role - Not Executed Independently

Evaluate whether the model predicts decisions across litigation, board, leadership and institutional scenarios. Prefer evidence, mechanisms, limits and usable routing. Do not reward style imitation.
