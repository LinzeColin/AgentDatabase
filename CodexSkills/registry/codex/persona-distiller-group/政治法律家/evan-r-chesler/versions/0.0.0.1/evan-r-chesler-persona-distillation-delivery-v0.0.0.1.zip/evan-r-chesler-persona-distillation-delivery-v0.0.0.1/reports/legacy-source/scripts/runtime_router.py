#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'route-manifest.json'


def load_manifest() -> dict:
    try:
        return json.loads(MANIFEST.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f'router manifest error: {exc}')


def plan(task: str) -> dict:
    manifest = load_manifest()
    text = task.casefold()
    scored = []
    for route in manifest.get('routes', []):
        hits = [kw for kw in route.get('keywords', []) if kw.casefold() in text]
        if hits:
            scored.append((len(hits), route.get('id', ''), route, hits))
    scored.sort(key=lambda item: (-item[0], item[1]))

    adapters = []
    matched = []
    for score, route_id, route, hits in scored:
        matched.append({'route': route_id, 'score': score, 'hits': hits})
        for adapter in route.get('adapters', []):
            if adapter not in adapters:
                adapters.append(adapter)
            if len(adapters) >= int(manifest.get('max_adapters', 2)):
                break
        if len(adapters) >= int(manifest.get('max_adapters', 2)):
            break
    if not adapters:
        adapters = list(manifest.get('default_adapters', []))

    adapters = adapters[: int(manifest.get('max_adapters', 2))]
    load_files = [
        'facts.md', 'cognitive-os.md', 'decision-policy.md', 'boundaries.md',
        'identity-facets/political-legal.md'
    ] + [f'scenario-adapters/{name}.md' for name in adapters]

    return {
        'identity': manifest.get('primary_identity', 'political-legal'),
        'adapters': adapters,
        'matched_routes': matched,
        'load_files': load_files,
        'legal_freshness_required': True,
        'max_adapters': manifest.get('max_adapters', 2),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='Route a task through the Evan R. Chesler persona Skill.')
    sub = parser.add_subparsers(dest='command', required=True)
    p_plan = sub.add_parser('plan')
    p_plan.add_argument('--task', required=True)
    args = parser.parse_args()
    if args.command == 'plan':
        print(json.dumps(plan(args.task), ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    return 2


if __name__ == '__main__':
    sys.exit(main())
