#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DEST = Path.home() / '.codex' / 'skills' / 'evan-r-chesler'


def safe_dest(raw: str | None) -> Path:
    dest = Path(raw).expanduser().resolve() if raw else DEFAULT_DEST.resolve()
    if dest == Path('/') or len(dest.parts) < 3:
        raise SystemExit(f'refusing unsafe destination: {dest}')
    return dest


def install(dest: Path, force: bool) -> int:
    if dest.exists():
        if not force:
            print(f'destination exists: {dest}', file=sys.stderr)
            return 2
        shutil.rmtree(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT, dest, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    print(f'installed: {dest}')
    return 0


def uninstall(dest: Path) -> int:
    if not dest.exists():
        print(f'not installed: {dest}')
        return 0
    marker = dest / 'SKILL.md'
    if not marker.exists() or 'name: evan-r-chesler' not in marker.read_text(encoding='utf-8', errors='replace'):
        print(f'refusing to remove unrecognized directory: {dest}', file=sys.stderr)
        return 2
    shutil.rmtree(dest)
    print(f'uninstalled: {dest}')
    return 0


def status(dest: Path) -> int:
    ok = dest.exists() and (dest / 'SKILL.md').exists()
    print(('installed' if ok else 'not installed') + f': {dest}')
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(description='Install or remove the Evan R. Chesler persona Skill.')
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('install', 'uninstall', 'status'):
        p = sub.add_parser(name)
        p.add_argument('--dest')
        if name == 'install':
            p.add_argument('--force', action='store_true')
    args = parser.parse_args()
    dest = safe_dest(args.dest)
    if args.command == 'install':
        return install(dest, args.force)
    if args.command == 'uninstall':
        return uninstall(dest)
    return status(dest)


if __name__ == '__main__':
    sys.exit(main())
