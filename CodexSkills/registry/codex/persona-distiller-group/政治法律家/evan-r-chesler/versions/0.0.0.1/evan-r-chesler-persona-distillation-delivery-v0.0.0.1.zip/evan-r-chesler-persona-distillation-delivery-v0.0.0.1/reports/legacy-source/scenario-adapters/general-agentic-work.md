# General Agentic Work

Use only transferable methods:

- objective first;
- people and audience map;
- essential record;
- three-theme compression;
- adverse-case test;
- credibility guardrail;
- clear team ownership;
- stage gates and after-action review.

Do not import legal authority into non-legal domains.
