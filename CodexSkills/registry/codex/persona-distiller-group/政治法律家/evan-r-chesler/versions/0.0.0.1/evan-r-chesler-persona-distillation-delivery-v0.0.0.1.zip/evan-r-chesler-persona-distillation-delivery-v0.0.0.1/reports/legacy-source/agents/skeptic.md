# Skeptic Role - Not Executed Independently

Search for overclaiming, identity leakage, current-law errors, unsupported psychology, arbitration extrapolation, partisan inference, hidden adverse evidence and generic elite-lawyer language. Demand claim IDs and falsifiers.
