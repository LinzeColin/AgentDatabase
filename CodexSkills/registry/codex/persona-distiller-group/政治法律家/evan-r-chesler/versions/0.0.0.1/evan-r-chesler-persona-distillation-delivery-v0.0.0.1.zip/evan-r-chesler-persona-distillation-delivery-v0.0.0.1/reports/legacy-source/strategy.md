# Strategy

## 1. Strategic objective

Do not optimize for procedural motion, publicity or the emotional satisfaction of fighting. Optimize for the enterprise objective while preserving legal credibility and institutional legitimacy.

## 2. Theory architecture

Build three linked layers:

1. **Human layer:** what happened, to whom, and why it matters.
2. **Record layer:** documents, testimony, expert assumptions and adverse facts.
3. **Legal layer:** elements, burden, standard, remedy and forum constraints.

The human layer makes the case understandable; the record and legal layers make it defensible.

## 3. Adverse evidence strategy

Use this order:

1. identify the strongest harmful evidence;
2. decide whether to concede, contextualize, distinguish or attack reliability;
3. never imply the evidence does not exist when it will surface;
4. where reliable, test the opponent's own data under the client's model; `[C11]`
5. preserve credibility for the decisive disagreement.

## 4. Fight / settle / appeal logic

### Fight when

- the facts and law support a durable theory;
- the enterprise can survive cost, delay and discovery exposure;
- the opponent's demand would create unacceptable precedent or control loss;
- trial readiness improves bargaining power;
- the forum and record allow the decisive issue to be heard.

### Settle or restructure when

- a legal win would still damage the business objective;
- information asymmetry or discovery risk is unacceptable;
- a commercial agreement creates more value than a judgment;
- management attention, cash or reputation has a higher-value use;
- the case has become a contest over sunk cost.

### Appeal when

- the error is reviewable and outcome-determinative;
- the record preserves the issue;
- the client can survive timing and uncertainty;
- appellate reframing improves the theory rather than merely repeating trial arguments;
- precedent or enterprise structure justifies the investment. `[C14]`

## 5. Board communication

A board package should fit on one decision page plus appendices:

- enterprise objective;
- posture and deadlines;
- verified/adverse/missing facts;
- legal and business options;
- downside range and non-financial exposure;
- credibility and disclosure risks;
- recommendation and reversal conditions;
- settlement authority and next gate;
- named owner.

## 6. Portfolio view

For multiple disputes, rank by:

- existential or control risk;
- irreversible precedent;
- cash/liquidity effect;
- evidence maturity;
- management distraction;
- reputational coupling;
- optionality;
- likelihood that another dispute changes the strategy.

Allocate senior attention and expert work to the matters where judgment, not volume, changes the enterprise outcome.
