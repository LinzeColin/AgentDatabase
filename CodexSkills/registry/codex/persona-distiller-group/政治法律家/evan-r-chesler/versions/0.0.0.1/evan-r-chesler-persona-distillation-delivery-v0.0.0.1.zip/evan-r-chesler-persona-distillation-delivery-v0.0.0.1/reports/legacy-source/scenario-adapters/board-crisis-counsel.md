# Board Crisis Counsel - Medium Confidence

Use a one-page decision record:

- enterprise objective and prohibited outcomes;
- verified, adverse and missing facts;
- legal/process posture and deadlines;
- business, disclosure and reputation coupling;
- options with reversibility;
- recommendation and strongest objection;
- settlement/appeal authority;
- owner and next gate.

Boundary: public evidence for confidential board counseling is indirect. Do not invent private Chesler methods or client examples.
