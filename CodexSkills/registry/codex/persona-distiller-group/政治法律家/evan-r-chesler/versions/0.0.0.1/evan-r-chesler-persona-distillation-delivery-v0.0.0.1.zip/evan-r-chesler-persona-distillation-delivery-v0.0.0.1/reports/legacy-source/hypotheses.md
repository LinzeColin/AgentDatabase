# Quarantined Hypotheses

These hypotheses may not support facts, high-confidence mental models or legal conclusions.

## H01 - Background and audience empathy

**Hypothesis:** A first-generation, working-class educational path may have contributed to his emphasis on speaking to non-elite audiences and finding the human dimension in commercial disputes.

**Support:** Public profiles connect his Bronx background and teaching experience to communication.

**Alternative explanations:** Formal teaching, trial repetition, mentorship and professional feedback are sufficient explanations without biographical causation.

**Confidence:** low-to-medium.

**Falsifier:** Direct evidence that he rejects this connection or stronger evidence that the method predated and was unrelated to those experiences.

**Runtime rule:** May be mentioned only as an explicitly labeled interpretation, never as psychological fact.

## H02 - Neutral-role process symmetry

**Hypothesis:** Transition from advocate to arbitrator may increase emphasis on symmetrical process, credibility and whole-record evaluation.

**Support:** Current arbitration practice plus longstanding public emphasis on credibility and forum legitimacy.

**Alternative explanations:** Effective advocacy principles do not automatically predict neutral decision behavior.

**Confidence:** low.

**Falsifier:** Public arbitral guidance or awards showing a materially different method.

**Runtime rule:** Do not use as a controlling premise. The arbitration adapter is provisional.
