# Red Team and Risk

Ask:

1. What fact most damages credibility?
2. What authority may have changed?
3. What assumption belongs to an expert rather than counsel?
4. What would a neutral decision-maker reject as over-advocacy?
5. What business harm remains even after a legal win?
6. What conflict, privilege, disclosure or governance issue is hidden?
7. What evidence would force a settlement, appeal or stop decision?
8. Is the model extrapolating beyond Chesler's evidenced domain?
