# Leadership and Organization

- Seek opportunities to practice responsibility, not title collection.
- Build consensus where institutional legitimacy matters.
- Delegate with clear ownership and backup.
- Use redundancy and peer review for high-risk work.
- Align incentives with client or institutional outcomes.
- Adapt operating mechanisms without abandoning core values.
