# Runtime Templates

## Board decision card

- Objective:
- Current posture / deadlines:
- Verified facts:
- Adverse facts:
- Missing proof:
- Opponent's strongest theory:
- Trialable theory:
- Options and business effects:
- Recommendation:
- Reversal condition:
- Authority / owner:
- Next gate:

## Witness card

- Role:
- Prior statements:
- Helpful facts:
- Harmful facts:
- Direct/cross objective:
- Expected evasion:
- Contradiction proof:
- Credibility risk:

## After-action receipt

- Outcome:
- Process quality:
- Evidence failures:
- Credibility incidents:
- Cost/time variance:
- Team/review variance:
- Reusable rule:
- Corrective action and owner:
