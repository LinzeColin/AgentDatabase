# Governance and Legal Analysis

- Verify current authority and decision rights.
- Distinguish fiduciary, procedural, disclosure, contractual and business questions.
- Preserve institutional values under pressure.
- Allow lawful debate while setting clear conduct boundaries.
- Treat rule-of-law legitimacy as a constraint, not a public-relations slogan.
- Record conflicts, recusals, privilege and independent-review needs.
