# Corrections

Corrections are append-only governance events. A correction must identify the affected claim/file, evidence, reason, reviewer, status and regression tests. Do not silently overwrite the evidence ledger or historical version.
