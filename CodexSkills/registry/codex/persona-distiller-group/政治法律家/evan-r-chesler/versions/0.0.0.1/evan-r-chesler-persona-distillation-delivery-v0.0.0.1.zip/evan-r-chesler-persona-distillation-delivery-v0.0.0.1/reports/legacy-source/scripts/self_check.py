#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    'SKILL.md', 'README.md', 'VERSION', 'facts.md', 'cognitive-os.md',
    'decision-policy.md', 'strategy.md', 'capabilities.md', 'work.md',
    'persona.md', 'divergence-map.md', 'boundaries.md', 'hypotheses.md',
    'identity-catalog.json', 'route-manifest.json', 'release-manifest.json',
    'evidence/source-ledger.jsonl', 'evidence/claims.jsonl',
    'scenario-adapters/auto.md', 'scripts/runtime_router.py', 'scripts/install.py',
    'reports/VERIFICATION.md', 'CHECKSUMS.sha256'
]

SECRET_PATTERNS = [
    re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    re.compile(r'(?i)api[_-]?key\s*[:=]\s*[A-Za-z0-9_\-]{16,}'),
    re.compile(r'(?i)secret\s*[:=]\s*[A-Za-z0-9_\-]{16,}'),
]


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    for i, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise AssertionError(f'{path.relative_to(ROOT)} line {i}: {exc}')
    return rows


def check_checksums() -> None:
    checksum_path = ROOT / 'CHECKSUMS.sha256'
    for line in checksum_path.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        expected, rel = line.split('  ', 1)
        p = ROOT / rel
        assert p.exists(), f'checksum target missing: {rel}'
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        assert actual == expected, f'checksum mismatch: {rel}'


def main() -> int:
    errors = []
    try:
        for rel in REQUIRED:
            assert (ROOT / rel).exists(), f'missing required file: {rel}'

        skill = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        assert skill.startswith('---\n'), 'SKILL.md missing frontmatter'
        assert 'name: evan-r-chesler' in skill, 'frontmatter name mismatch'
        assert 'not Evan R. Chesler' in skill, 'identity boundary missing'

        version = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()
        assert re.fullmatch(r'candidate-\d+\.\d+\.\d+\.\d+', version), f'invalid VERSION: {version}'

        for rel in ('identity-catalog.json', 'route-manifest.json', 'release-manifest.json'):
            json.loads((ROOT / rel).read_text(encoding='utf-8'))

        sources = read_jsonl(ROOT / 'evidence/source-ledger.jsonl')
        claims = read_jsonl(ROOT / 'evidence/claims.jsonl')
        assert len(sources) >= 24, f'insufficient sources: {len(sources)}'
        assert len(claims) >= 20, f'insufficient claims: {len(claims)}'
        source_ids = {row['source_id'] for row in sources}
        contaminated = {row['source_id'] for row in sources if row.get('split') == 'evaluation_reference_contaminated'}
        assert len(source_ids) == len(sources), 'duplicate source IDs'
        assert len({row['claim_id'] for row in claims}) == len(claims), 'duplicate claim IDs'
        for claim in claims:
            ev = claim.get('evidence', [])
            assert ev, f"claim has no evidence: {claim.get('claim_id')}"
            missing = set(ev) - source_ids
            assert not missing, f"claim {claim.get('claim_id')} missing sources: {sorted(missing)}"
            leaked = set(ev) & contaminated
            assert not leaked, f"claim {claim.get('claim_id')} uses contaminated evaluation sources: {sorted(leaked)}"

        release = json.loads((ROOT / 'release-manifest.json').read_text(encoding='utf-8'))
        assert release['status'] == 'candidate_unregistered'
        assert release['product_version'] is None
        assert release['quality_gates']['independent_blind_semantic_eval']['status'] == 'not_run'
        assert release['quality_gates']['clean_holdout_isolation']['status'] == 'invalid_contaminated'

        for p in ROOT.rglob('*'):
            if not p.is_file() or p.name == 'CHECKSUMS.sha256':
                continue
            if p.suffix.lower() in {'.png', '.jpg', '.jpeg', '.gif', '.zip', '.pdf'}:
                continue
            text = p.read_text(encoding='utf-8', errors='replace')
            for pattern in SECRET_PATTERNS:
                assert not pattern.search(text), f'secret-like pattern in {p.relative_to(ROOT)}'

        router = ROOT / 'scripts/runtime_router.py'
        tests = [
            ('Prepare a cross-examination for a patent trial', 'trial-preparation'),
            ('董事会需要决定重大商业争议是否和解', 'bet-the-company-litigation'),
            ('设计商业仲裁案件的争点和证据计划', 'arbitration-dispute-resolution'),
            ('How should an institution protect rule of law under pressure?', 'governance-legal'),
        ]
        for task, expected in tests:
            out = subprocess.check_output([sys.executable, str(router), 'plan', '--task', task], text=True)
            plan = json.loads(out)
            assert expected in plan['adapters'], (task, plan)
            assert len(plan['adapters']) <= 2

        check_checksums()
    except (AssertionError, OSError, subprocess.CalledProcessError, json.JSONDecodeError) as exc:
        errors.append(str(exc))

    if errors:
        print('SELF_CHECK: FAIL')
        for err in errors:
            print(f'- {err}')
        return 1
    print('SELF_CHECK: PASS')
    print(f'- root: {ROOT}')
    print(f'- sources: {len(sources)}')
    print(f'- claims: {len(claims)}')
    print('- candidate status and unresolved semantic gates preserved')
    return 0


if __name__ == '__main__':
    sys.exit(main())
