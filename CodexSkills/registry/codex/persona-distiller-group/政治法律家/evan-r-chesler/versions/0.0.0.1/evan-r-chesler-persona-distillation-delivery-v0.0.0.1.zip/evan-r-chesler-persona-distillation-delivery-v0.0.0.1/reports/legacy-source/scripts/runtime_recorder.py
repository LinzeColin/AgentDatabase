#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG = ROOT / 'runtime' / 'invocations.jsonl'


def digest(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description='Append a privacy-minimized runtime receipt.')
    parser.add_argument('record', nargs='?')
    parser.add_argument('--task', required=True)
    parser.add_argument('--route', required=True, help='JSON route summary')
    parser.add_argument('--status', choices=['completed', 'degraded', 'refused', 'error'], required=True)
    parser.add_argument('--result-summary', default='')
    args = parser.parse_args()

    try:
        route = json.loads(args.route)
    except json.JSONDecodeError as exc:
        print(f'invalid route JSON: {exc}', file=sys.stderr)
        return 2

    LOG.parent.mkdir(parents=True, exist_ok=True)
    row = {
        'recorded_at': datetime.now(timezone.utc).isoformat(),
        'task_sha256': digest(args.task),
        'task_length': len(args.task),
        'route': route,
        'status': args.status,
        'result_summary_sha256': digest(args.result_summary) if args.result_summary else None,
        'raw_task_stored': False,
        'raw_result_stored': False,
    }
    with LOG.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + '\n')
    print(json.dumps(row, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
