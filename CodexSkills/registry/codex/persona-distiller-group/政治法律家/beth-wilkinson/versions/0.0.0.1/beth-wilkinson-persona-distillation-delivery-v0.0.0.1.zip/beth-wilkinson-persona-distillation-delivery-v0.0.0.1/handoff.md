# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `beth-wilkinson`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`e0a30abd20dc8740bc35fd21840ff62d2492ffc64fb1b59ced4525a0e66e9802`
- 运行时调用版本：无
- 唯一登记身份：`政治法律家`

## 审计可用性

- `verification.json`: `passed-runtime-integrity-only`
- `provenance.json`: `passed-sanitized-runtime-ledger`
- `source-coverage.json`: `not-available-in-source-artifact`
- `evaluation-summary.json`: `not-available-in-source-artifact`
- `review-record.json`: `passed-with-serialized-isolation`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
