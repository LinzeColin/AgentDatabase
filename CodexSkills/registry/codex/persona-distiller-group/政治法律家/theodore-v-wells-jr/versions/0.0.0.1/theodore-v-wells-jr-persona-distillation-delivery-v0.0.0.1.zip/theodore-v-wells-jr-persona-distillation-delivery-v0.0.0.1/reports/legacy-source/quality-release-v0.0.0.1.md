# Persona Distiller quality report

- Target: `/mnt/data/persona_workspaces/theodore-v-wells-jr`
- Phase: `release`
- Profile: `deep`
- Generated: `2026-07-23T08:31:33Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 67,
  "ledger_counts": {
    "sources": 67,
    "claims": 65
  },
  "sources_total": 67,
  "sources_train": 64,
  "sources_usable_train": 64,
  "sources_holdout": 3,
  "primary_sources": 46,
  "primary_ratio": 0.7188,
  "lane_source_counts": {
    "writings": 16,
    "conversations": 11,
    "expression": 15,
    "external": 41,
    "decisions": 39,
    "timeline": 49
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 65,
  "claims_active": 65,
  "mental_models": 7,
  "heuristics": 13,
  "claim_markers": 65,
  "eval_cases": 32,
  "eval_suite_counts": {
    "known": 2,
    "boundary": 2,
    "voice": 2,
    "trajectory": 2,
    "contrast": 2,
    "fact-preservation": 2,
    "style-decoy": 2,
    "task-completion": 2,
    "planning-fidelity": 2,
    "tool-use": 2,
    "capability-calibration": 2,
    "refusal-stop": 2,
    "long-horizon": 2,
    "identity-routing": 2,
    "anonymous-fidelity": 2,
    "token-efficiency": 2
  },
  "eval_results": 128,
  "candidate_overall": 0.9453,
  "baseline_overall": 0.7359,
  "candidate_baseline_delta": 0.2094,
  "suite_candidate_means": {
    "known": 0.944,
    "boundary": 0.974,
    "voice": 0.914,
    "trajectory": 0.924,
    "contrast": 0.934,
    "fact-preservation": 0.984,
    "style-decoy": 0.954,
    "task-completion": 0.944,
    "planning-fidelity": 0.934,
    "tool-use": 0.944,
    "capability-calibration": 0.964,
    "refusal-stop": 0.984,
    "long-horizon": 0.924,
    "identity-routing": 0.954,
    "anonymous-fidelity": 0.934,
    "token-efficiency": 0.914
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
