# Persona Distiller quality report

- Target: `/mnt/data/persona_workspaces/theodore-v-wells-jr`
- Phase: `research`
- Profile: `deep`
- Generated: `2026-07-23T08:31:32Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 67,
  "ledger_counts": {
    "sources": 67,
    "claims": 65
  },
  "sources_total": 67,
  "sources_train": 64,
  "sources_usable_train": 64,
  "sources_holdout": 3,
  "primary_sources": 46,
  "primary_ratio": 0.7188,
  "lane_source_counts": {
    "writings": 16,
    "conversations": 11,
    "expression": 15,
    "external": 41,
    "decisions": 39,
    "timeline": 49
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ]
}
```

## Errors

- None

## Warnings

- None
