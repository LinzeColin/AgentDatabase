# Research saturation report

- Cutoff: 2026-07-23
- Train sources: 64
- Holdout sources: 3（隔离）
- P1/P2 ratio: 71.9%
- Six-lane coverage: writings 16, conversations 11, expression 15, external 39, decisions 39, timeline 49

## Gap-expansion round 1

从官方职业简介与代表性胜诉出发后，主动扩展到：Donovan/Espy 的不举证细节、Barrack 的相反作证决策、Libby 败诉、Deflategate 技术与法律批评、Turner 司法处分、Harvard 2025 任期更正。该轮改变了模型：从“强势审判律师”升级为“证明责任—中心理论—阶段更新”，并新增调查独立性与幸存者偏差边界。

## Gap-expansion round 2

继续寻找近年民事/监管样本、团队准备方法、fresh-eyes、职业培养和制度治理材料。新增 Exxon 2026、Rio Tinto 2022—2026、Harvard 官方时间线和多元化资料。该轮加强了团队整合、非专家共鸣测试与多战线系统，但没有产生需要推翻核心模型的新高影响机制。

## Stop condition

连续第二轮新增来源主要用于三角验证、时间更新和边界强化，未出现新的高置信核心决策机制；所有六路均有一手/直接或高质量来源，且胜诉、败诉、争议、不同角色与时期均覆盖。因公开互联网不存在可证明的“全量”，本报告只声明**按定义的来源宇宙达到两轮边际饱和**，不声明穷尽所有网页或未公开材料。

## Remaining gaps

完整庭审逐字稿、和解谈判、低曝光案件、内部团队决策记录、客户视角和未公开报告不可得。后续更新优先补这些高信息增益来源，而非继续堆积排名与重复人物简介。
