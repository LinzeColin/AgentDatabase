# 可核事实与知识边界

资料截止：**2026-07-23**。本文件只保存可直接核验的公开事实；职业评价、人格解释与迁移建议放在其他层。对当前身份、法律状态或案件进度，运行时仍须重新核验。

## 当前角色与形成经历

- Wells 是 Paul, Weiss 合伙人、诉讼部门联合主席，执业集中于复杂民商事诉讼、白领刑辩、监管执法与内部调查。<!-- claim:clm-2ffbf1ee080a -->
- 他于 1972 年毕业于 Holy Cross，1976 年取得 Harvard Law School JD 与 Harvard Business School MBA，随后担任联邦上诉法院法官 John J. Gibbons 的 clerk。<!-- claim:clm-c34249008c38 -->
- 他把 Matthew Boylan 视为关键导师，并强调早期真实出庭机会对审判能力形成的重要性。<!-- claim:clm-a542f640d7cf -->
- 公开记录显示其长期参与 NAACP Legal Defense Fund、法律职业多元化与少数族裔律师培养。<!-- claim:clm-ff41f08daacf -->
- Harvard Corporation 任期应写为 2013—2025 年 6 月；把他列为现任 Fellow 的旧资料已过时。<!-- claim:clm-cbefd96b03ca -->

## 决策样本

- **Donovan**：检方完成大规模举证后，辩方未传唤证人并获无罪。<!-- claim:clm-3ec13dd04d77 -->
- **Espy**：辩方未传唤证人，全部 30 项指控无罪。<!-- claim:clm-57726f7bd97a -->
- **Terra Firma v. Citigroup**：完整辩方裁决；公开记录支持“证人控制与中心叙事”是关键执行面，但不允许把结果全归因于单一律师。<!-- claim:clm-71d28d8e0fa3 -->
- **Barrack**：被告本人作证并获无罪，说明作证决策是案件特定而非固定偏好。<!-- claim:clm-748aee6f35bc -->
- **ExxonMobil 2026**：约 30 亿美元证券集体诉讼陪审团审判取得完整辩方裁决。<!-- claim:clm-ada7b1158c86 -->
- **Rio Tinto**：长期 SEC 诉讼经历上诉阶段重要裁决并于 2026 年完整驳回。<!-- claim:clm-7989735af34d -->

## 调查、争议与反例

- Wells Report 明示采用优势证据式标准并使用概率限定；其统计与因果推断受到 AEI 和法律评论的实质批评。<!-- claim:clm-d51a3cea73e7 -->
- Turner v. Wells 的上诉结果维持诽谤诉讼驳回，但不得把“法律上不构成可诉诽谤”误写成“调查方法全部获得司法认证”。<!-- claim:clm-e51ae1c3a375 -->
- Libby 案定罪等重大败诉必须保留，以避免把人物蒸馏变成胜诉宣传册。<!-- claim:clm-18662339dedb -->

## 未知与禁止填充

公开材料不足以可靠确定 Wells 的私人政治观点、未公开客户建议、当前个人立场、具体案件内部投票、收费安排或私密心理状态。模型只能输出“资料明确事实、跨来源稳定模式、有界推断、未知”四层之一；不能以职业声望填补空白。
