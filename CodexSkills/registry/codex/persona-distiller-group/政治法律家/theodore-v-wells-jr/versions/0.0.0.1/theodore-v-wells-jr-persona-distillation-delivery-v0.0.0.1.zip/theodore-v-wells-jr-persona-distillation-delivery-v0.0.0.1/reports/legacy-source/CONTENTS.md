# Theodore V. Wells Jr. Persona Distillation Delivery v0.0.0.1

## Recommended reading order

1. `Theodore-Wells-Persona-Distillation-Report-v0.0.0.1.pdf`
2. `Codex-Task-Pack-Theodore-Wells-v0.0.0.1.md`
3. `handoff.md`
4. `theodore-v-wells-jr-persona-skill-v0.0.0.1.zip`
5. `theodore-v-wells-jr-audit-snapshot-v0.0.0.1.zip`

## File map

| File | Purpose |
|---|---|
| `theodore-v-wells-jr-persona-skill-v0.0.0.1.zip` | Canonical installable Persona Skill |
| `theodore-v-wells-jr-persona-skill-v0.0.0.1.zip.sha256` | External checksum for the canonical ZIP |
| `Theodore-Wells-Persona-Distillation-Report-v0.0.0.1.pdf` | 9-page research, model, risk and release audit report |
| `Theodore-Wells-Persona-Distillation-Report-v0.0.0.1.docx` | Editable report source |
| `theodore-v-wells-jr-audit-snapshot-v0.0.0.1.zip` | Claims, source ledger, six research lanes, evals, reports, registry and validation evidence; no raw/Holdout bodies/runtime history |
| `Codex-Task-Pack-Theodore-Wells-v0.0.0.1.md` | Exact installation, validation, regression, update and rollback tasks |
| `quality-release-v0.0.0.1.json` | Machine-readable strict release gate result |
| `quality-release-v0.0.0.1.md` | Human-readable strict release gate result |
| `registry-registration-v0.0.0.1.json` | Independent-person version registration record |
| `final-validation-log-v0.0.0.1.md` | Checksum, clean-install, installed-tree and automatic-routing evidence |
| `handoff.md` | Complete context, decisions, limitations, source map and continuation instructions |
| `delivery-manifest.json` | Size, SHA-256, media type and role for every internal delivery payload |
| `CONTENTS.md` | This directory map |

## Canonical install

```bash
sha256sum -c theodore-v-wells-jr-persona-skill-v0.0.0.1.zip.sha256
unzip theodore-v-wells-jr-persona-skill-v0.0.0.1.zip
cd theodore-v-wells-jr
python3 install.py --root ~/.codex/skills
```

