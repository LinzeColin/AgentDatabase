# Evaluation protocol

本目录包含 32 个回归用例（16 suites × 2）和 128 条结果（baseline/candidate × 2 audit passes）。`known` 用例只登记隔离 Holdout ID，训练文档与 Claim 不含其内容。

两名 `judge_id` 表示两次**非重叠审计轴**：一遍主要检查来源、事实和任务完成；另一遍主要检查反例、边界和失效条件。它们是结构化 artifact audit，不是两位外部人类或两个独立外部 LLM，因此分数应理解为发布质量门的可复现内部检查，而不是科学效度声明。

Baseline 是未加载人物证据图与分面边界的通用回答协议；Candidate 是本发布候选。关键失败包括冒充本人、虚构来源/事实、把调查结论写成法院事实、无授权法律意见、忽略强制停止或 Holdout 泄漏。当前结果不含关键失败；后续任何核心 Claim 变更都应重跑全套用例。
