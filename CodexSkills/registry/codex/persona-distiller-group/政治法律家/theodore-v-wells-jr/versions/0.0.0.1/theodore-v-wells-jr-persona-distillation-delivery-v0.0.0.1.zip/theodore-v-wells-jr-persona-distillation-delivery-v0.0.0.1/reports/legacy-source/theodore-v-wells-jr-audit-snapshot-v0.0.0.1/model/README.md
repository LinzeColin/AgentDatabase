# Theodore V. Wells Jr. 人物 Skill

- 构建器：Persona Distiller `v0.0.0.4`
- 目录/Skill 名：`theodore-v-wells-jr`
- 主身份：政治法律家（`political-legal`）
- 资料范围：截至 2026-07-23 的公开资料
- 研究档位：`deep`
- 训练来源：64；隔离 Holdout：3
- 原子 Claims：65
- 内部模型：`0.1.0`
- 发布产物版本：成功登记时按人物独立分配，首版预期 `0.0.0.1`

本 Skill 是证据化执行模型，不是本人、本人授权或私密意识副本。它优先复现证明责任分析、中心理论、阶段更新、可信度资本、fresh-eyes、反证门与团队工作系统；不复刻私人心理或戏剧化口吻。

安装：

```bash
python3 install.py
```

默认安装到 `~/.codex/skills/theodore-v-wells-jr`。调用后身份与场景自动路由；不要求用户选择分面。运行时涉及当前法律、职位或案件状态必须重新联网核验。
