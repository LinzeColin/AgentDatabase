# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `isambard-kingdom-brunel`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`42604d21376efa95d14f6e0f8cfc8d0873f6f78f123203b57b27e5b06cb16e4d`
- 运行时调用版本：无
- 唯一登记身份：`材料建工师`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-independent-agents`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
