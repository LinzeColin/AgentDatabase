# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `doc-palmer`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`1e676581a8be334b818291cbc2a9fd1539b09df95600b7ed5a1586a1e9437fa0`
- 运行时调用版本：无
- 唯一登记身份：`材料建工师`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-serialized-isolation`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
