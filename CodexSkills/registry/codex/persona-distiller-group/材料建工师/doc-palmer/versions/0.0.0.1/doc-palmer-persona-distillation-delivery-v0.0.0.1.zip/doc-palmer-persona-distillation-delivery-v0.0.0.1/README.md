# Richard (Doc) Palmer — 人物蒸馏完整交付

这是单一、完整、可校验的交付 ZIP。它包含人物运行时 Skill、安装器、登记卡、团队卡、来源覆盖、评测、验证、provenance 和交接信息。

- 人物产品版本：`0.0.0.1`
- 模型快照：`1.0.0`
- 唯一身份：`材料建工师`
- 运行时 SHA-256：`1e676581a8be334b818291cbc2a9fd1539b09df95600b7ed5a1586a1e9437fa0`
- 交付状态：`native-v0.0.0.5`

安装到默认 Codex Skills 目录：

```bash
python3 install.py
```

覆盖同名旧版本：

```bash
python3 install.py --force
```

`0.0.0.N` 只标识已登记人物产品；人物 Skill 的单次调用不编号。人物模型不是本人、授权、背书或实时观点。
