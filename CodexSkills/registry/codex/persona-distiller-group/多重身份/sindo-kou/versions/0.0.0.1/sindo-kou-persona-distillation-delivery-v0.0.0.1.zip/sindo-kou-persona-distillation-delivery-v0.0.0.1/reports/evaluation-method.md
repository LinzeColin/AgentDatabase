
# Evaluation Method and Independence Disclosure

- Profile: deep
- Suites: 16
- Cases: 32
- Systems: baseline and candidate
- Reviews per case/system: 2
- Review mode: serialized rubric passes in the same host environment
- Independence status: not independent external agents

The two passes are intentionally separated by judge ID and frozen output rows, but they share a common build context. This is weaker than review by independently provisioned agents or human domain experts. The delivery audit therefore reports `passed-with-serialized-isolation`, not `passed-with-independent-agents`.

Scores test structural fidelity, fact preservation, boundaries, planning, tool honesty, routing, and efficiency. They do not establish metallurgical correctness for a specific production weld; project-level validation remains mandatory.
