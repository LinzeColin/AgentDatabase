
# Handoff Context — Sindo Kou Persona Distillation

## Current state

- Workspace: `sindo-kou`
- Builder: Persona Distiller v0.0.0.5
- Model version: 1.0.0
- Status: release-candidate
- Research cutoff: 2026-07-24
- Identity route: technical-engineer 0.70 + thinker-educator 0.30
- Evidence: 82 train, 3 holdout, 50 claims
- Evaluation: 32 cases, 16 suites, two serialized rubric passes

## Load-bearing model

`thermal/transport → pool geometry/composition → solidification path → grains/segregation → cracking/performance`, with zone-first routing and model–observation–criterion–cross-condition validation.

## Important boundaries

- Public evidence model, not the person or authorization.
- No fabricated quotations, private memory, current opinion, or completed tool execution.
- Formal technical corpus does not support business, investment, legal, medical, political, negotiation, or private-psychology authority.
- High-stakes welding decisions require current standards, material/process data, qualification testing, and accountable sign-off.

## Evidence caveats

A subset of early/midcareer publication records are metadata/abstract level and are marked P2. Three later papers are holdout-only and must never support claims. Conversation and conflict evidence remains structurally sparse.

## Next maintenance action

When new first-party material appears after 2026-07-24, ingest it as train or a new isolated holdout before changing Claims. Re-run all 16 suites and specifically regression-test back-diffusion counterexamples, test-geometry validity, domain boundaries, and quote/identity refusal.
