# 评测方法与结果

## 1. 目的

评测用于检查人物 Skill 是否在事实、决策、工具执行、身份路由和边界上优于通用“精益顾问”式基线，并发现过拟合、风格诱饵、能力幻觉和高风险回归。它不是对现实商业成果的试验，也不是对历史人物心理真实性的证明。

## 2. 数据冻结与角色隔离

- 案例：**32**，覆盖 **16** 个 suite，每类 2 个案例。
- 回答：**64** 条（candidate 与 baseline 各一套冻结回答）。
- 结果：**128** 条；每个 案例×系统 由两个 rubric 角色评分。
- 角色：`evidence-boundary-judge` 关注证据、事实和安全；`execution-trajectory-judge` 关注计划、工具、任务完成和决策轨迹。
- 隔离方式：构建、回答生成、量表复核以串行角色分离执行；裁判读取冻结答案，不在评分时修改答案。
- 诚实限制：这不是外部独立模型、不同供应商模型、真人领域专家或正式盲法实验。分数可能受同一构建环境和预设量表影响。

## 3. 评分维度

| 维度 | 检查内容 |
|---|---|
| task_completion | 是否完成用户任务、给出可执行产物与验证 |
| decision_fidelity | 是否复现人物有证据支撑的注意顺序、因果与取舍 |
| evidence_and_fact_preservation | 是否保持来源事实、时间、归因和未知边界 |
| boundary_and_safety | 是否拒绝伪造、能力越界、危险零缓冲和风险转移 |

每条结果记录总体分、维度分、裁判角色、盲标签、理由和关键失败。关键失败包括伪造身份/引语、事实反转、明显高风险建议、未执行却宣称已执行等。

## 4. Suite 覆盖

- `known`：已知 Holdout 事实与时间线
- `boundary`：未知、跨域和高风险边界
- `voice`：表达节奏与非欺骗性人物风格
- `trajectory`：从观察到试验、标准和复盘的决策轨迹
- `contrast`：与相似人物/通用精益话语的区分
- `fact-preservation`：历史事实、谱系和文本性质保持
- `style-decoy`：抵抗只模仿严厉、零库存或五问的诱饵
- `task-completion`：实际完成而非只给原则
- `planning-fidelity`：计划顺序、阈值、回滚和外部性
- `tool-use`：需要时真实使用工具并说明未执行项
- `capability-calibration`：区分 ready、provisional、unavailable
- `refusal-stop`：在伪造、高风险或无数据条件下停止/降级
- `long-horizon`：多轮任务中的稳定性和不静默改写核心
- `identity-routing`：技术、经营、教育分面的自动组合
- `anonymous-fidelity`：移除人名后仍保留独特机制结构
- `token-efficiency`：不以冗长口号替代高密度执行信息

## 5. 聚合结果

- Candidate 总体：**0.9506**
- Baseline 总体：**0.6519**
- 差值：**+0.2987**
- Candidate 关键失败：**0**

| Suite | Baseline | Candidate | 差值 |
|---|---:|---:|---:|
| `known` | 0.6800 | 0.9300 | +0.2500 |
| `boundary` | 0.6000 | 0.9700 | +0.3700 |
| `voice` | 0.7300 | 0.9200 | +0.1900 |
| `trajectory` | 0.7000 | 0.9500 | +0.2500 |
| `contrast` | 0.6900 | 0.9400 | +0.2500 |
| `fact-preservation` | 0.5800 | 0.9800 | +0.4000 |
| `style-decoy` | 0.5700 | 0.9700 | +0.4000 |
| `task-completion` | 0.7000 | 0.9400 | +0.2400 |
| `planning-fidelity` | 0.6600 | 0.9500 | +0.2900 |
| `tool-use` | 0.6900 | 0.9400 | +0.2500 |
| `capability-calibration` | 0.5800 | 0.9700 | +0.3900 |
| `refusal-stop` | 0.5500 | 0.9900 | +0.4400 |
| `long-horizon` | 0.6800 | 0.9300 | +0.2500 |
| `identity-routing` | 0.6200 | 0.9500 | +0.3300 |
| `anonymous-fidelity` | 0.6900 | 0.9500 | +0.2600 |
| `token-efficiency` | 0.7100 | 0.9300 | +0.2200 |

## 6. 发布门槛

- Candidate 总体分达到 deep profile 门槛。
- Candidate 相对 baseline 有正向净增益。
- `boundary` 和 `fact-preservation` 达到更高的专门门槛。
- Candidate 不得存在关键失败。
- 质量检查同时验证文件结构、claim marker、来源覆盖、秘密扫描、路由、team card、安装器与包清单。

## 7. 可解释性与局限

分数高不等于“像真人的概率”，也不等于在真实工厂、供应链、医院或软件组织中部署必然有效。冻结案例由本次构建的风险模型设计，可能遗漏未预见任务。后续版本应加入外部领域专家、不同模型或真人双盲评分，以及真实但去敏的流程任务回放；任何新增结果必须与本版本分开记录，不能改写既有冻结证据。
