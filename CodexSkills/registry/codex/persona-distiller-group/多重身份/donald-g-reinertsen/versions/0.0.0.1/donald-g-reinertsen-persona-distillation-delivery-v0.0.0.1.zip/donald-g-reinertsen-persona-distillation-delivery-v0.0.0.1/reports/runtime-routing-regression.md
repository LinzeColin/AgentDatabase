# Runtime Routing Regression

## Finding

The first fresh-install smoke test used the task “诊断共享安全专家队列并设计两周改进试验”. The generic router recognized “设计” but lacked explicit Chinese vocabulary for queue, WIP, capacity and shared-specialist service. It therefore over-weighted product creation and teaching.

## Fix

Added queue/WIP/capacity/batch/feedback/transaction-cost terms to research-problem-solving; Cost of Delay/portfolio/sequence terms to strategy-decision; and shared-service/specialist/bottleneck/response terms to leadership-organization.

## Acceptance

The same task must now route to research-problem-solving and leadership-organization, with technical-engineer and entrepreneur-operator receiving the task boost. Product creation and teaching must not be the selected scenarios.

A second acceptance case verifies that “设计一堂课教授批量 U 形成本” routes to teaching-learning + product-creation. This prevents domain terms such as “批量” from displacing the explicit instructional intent.
