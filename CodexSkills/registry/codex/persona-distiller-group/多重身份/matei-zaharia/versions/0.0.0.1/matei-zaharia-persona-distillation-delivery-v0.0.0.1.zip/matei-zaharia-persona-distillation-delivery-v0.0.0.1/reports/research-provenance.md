# Research provenance summary

- Cutoff: `2026-07-24`
- Train sources: 52
- Holdout sources: 4
- Active claims: 45
- P1/P2 ratio: 98.1%
- Lanes: writings, conversations, expression, external, decisions, timeline

来源正文未打包；运行时仅保留净化后的 ledger 与 Claims。公开材料不代表本人授权。四条 Holdout 仅用于冻结评测，未支持任何 Claim。
