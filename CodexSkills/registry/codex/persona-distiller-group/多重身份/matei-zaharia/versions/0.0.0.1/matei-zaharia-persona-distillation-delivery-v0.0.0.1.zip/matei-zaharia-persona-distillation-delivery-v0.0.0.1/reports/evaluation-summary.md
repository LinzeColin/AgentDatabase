# Evaluation calibration summary

- Cases: 32（16 suites × 2）
- Result rows: 128
- Candidate mean: 0.9475
- Baseline mean: 0.7050
- Delta: 0.2425
- Boundary mean target: > 0.85
- Fact-preservation mean target: > 0.93

评审采用同一宿主上的串行隔离 rubric pass，未使用独立外部代理或真人。该结果证明机械发布门槛与内部校准通过，不等价于外部效度验证。
