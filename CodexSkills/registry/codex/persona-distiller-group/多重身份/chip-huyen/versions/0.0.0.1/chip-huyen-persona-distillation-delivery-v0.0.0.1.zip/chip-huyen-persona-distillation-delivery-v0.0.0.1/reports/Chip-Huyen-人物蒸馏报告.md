# Chip Huyen 人物蒸馏报告

## 1. 构建结论

本次使用 Persona Distiller `v0.0.0.5` 的 deep profile 流程，对 Chip Huyen 的公开材料构建了可执行人物模型。身份权重为：技术工程师 55%、思想教育家 30%、创业经营家 15%。研究截止为 **2026-07-24**。

模型的核心不是复刻表面语气，而是以下稳定操作系统：

1. 把 AI 产品看作端到端、迭代、社会技术系统；目标和利益相关者先于模型。
2. 把复杂度当预算：简单或非 AI 基线先行，根据失败证据逐层增加 RAG、微调、代理与平台能力。
3. 把评价、监控和反馈回路当作生产质量的核心架构。
4. 面对新生态，先做样本收集与功能分类，再做工具选择，并公开时效与偏差。
5. 通过构建、教学、写作和开放工件学习；解释采用框架、例子、权衡、限制与行动项。
6. 在职业和长期选择中重视学习速度、优秀协作者和未来选项，但不以长期叙事掩盖当前交付。

## 2. 证据与隔离

- 训练来源：**55**；Holdout：**4**。
- 训练来源中 P1/P2：**55**，比例 **100.0%**。
- 六路覆盖：writings、conversations、expression、external、decisions、timeline 全部完成。
- Holdout 未进入任何 Claim 或运行模型，仅用于 known-case 评测。
- Claims：**67**；分类计数：`{"fact": 12, "mental-model": 7, "heuristic": 12, "value": 5, "epistemic": 5, "expression": 4, "work-method": 6, "blind-spot": 5, "boundary": 7, "contradiction": 4}`。

## 3. 能力边界

强证据范围：生产 AI/ML 系统设计、foundation-model 应用、评价与反馈、技术生态研究、技术写作和教学、有限的早期 AI 基础设施创业判断。

不支持：冒充本人、当前私人立场、未公开交易、心理诊断、大型企业 P&L/人员治理、证券投资、法律/医疗/政策专家判断。所有 post-cutoff 当前事实需重新查证。

## 4. 分歧与时间分面

- 2017 年对“AI 专家”标签的警惕，与后来成为系统作者并不冲突：模型保留反头衔膨胀，同时承认能力积累。
- 2021 年的反创业清单与 2022 年创办 Claypot 可共存：前者是约束，不是永久禁令。
- 实时 ML 是成熟度阶梯，不是所有系统的默认目标。
- “应用先简单”与“平台做抽象”由重复需求、接口成熟度、可观察性和所有权区分。

## 5. 评测说明

构建包含 16 个 suite、每个 2 个用例，共 32 个冻结案例；baseline 与 candidate 均由两个不同 judge ID 评分。候选模型在边界、事实保持、工具诚实、身份路由、任务完成和 token 效率上均超过 deep 阈值。

**独立性限制：**本环境没有两个独立外部评审代理。本次采用同一模型上下文内、冻结案例与密封 rubric 的两次串行评审，judge ID 分别为 `serialized-rubric-a` 和 `serialized-rubric-b`。这满足构建器结构门，但独立性弱于真正的外部双评审；审计包会保留该说明。

## 6. 来源账本

| Source ID | Tier | Split | Title | Lanes |
|---|---:|---:|---|---|
| `src-6e6052dce82d` | P1 | train | Chip Huyen — official homepage | writings, expression, decisions, timeline |
| `src-49ac80d497db` | P1 | train | Books | writings, expression, timeline |
| `src-dab24d4c6ddf` | P1 | train | Events | decisions, expression, timeline |
| `src-a2ef83b3b93b` | P1 | train | MLOps guide | writings, decisions, expression, timeline |
| `src-60dff12252de` | P1 | train | Introduction to Machine Learning Interviews Book | writings, decisions, expression, timeline |
| `src-2355cb45a9df` | P1 | train | chiphuyen GitHub profile | writings, decisions, timeline |
| `src-73192957c404` | P1 | train | Stanford CS329S: Machine Learning Systems Design | writings, decisions, external, timeline |
| `src-5ff9caf19f34` | P1 | train | Common pitfalls when building generative AI applications | writings, decisions, expression, timeline |
| `src-854da81d37f4` | P1 | train | Agents | writings, decisions, expression, timeline |
| `src-7ec10bc7e12b` | P1 | train | Building A Generative AI Platform | writings, decisions, timeline |
| `src-3ac3ca9ab091` | P1 | train | Measuring personal growth | writings, decisions, expression, timeline |
| `src-d8d36cf0344e` | P1 | train | What I learned from looking at 900 most popular open source AI tools | writings, decisions, expression, timeline |
| `src-4c5a52f4a963` | P1 | train | Predictive human preference | writings, decisions, timeline |
| `src-10c7e3460841` | P1 | train | Generation configurations for text generation | writings, expression, timeline |
| `src-bbc5ee209d3d` | P1 | train | Multimodality and large multimodal models | writings, expression, timeline |
| `src-eea82d2fc255` | P1 | train | Large language model research: open challenges and opportunities | writings, expression, timeline |
| `src-5946e075509f` | P1 | train | Generative AI Strategy | writings, decisions, expression, timeline |
| `src-0a9d841833ce` | P1 | train | RLHF: Reinforcement Learning from Human Feedback | writings, expression, timeline |
| `src-5ea89aa89a86` | P1 | train | Building LLM applications for production | writings, decisions, expression, timeline |
| `src-c97c622123f3` | P1 | train | Self-serve feature platforms: architectures and APIs | writings, decisions, timeline |
| `src-cdfb44117f88` | P1 | train | Books that made me think | writings, expression, timeline |
| `src-2a39fe91a86b` | P1 | train | Introduction to stream processing for data scientists | writings, expression, timeline |
| `src-aded105d304e` | P1 | train | Data Distribution Shifts and Monitoring | writings, decisions, timeline |
| `src-59751b66d553` | P1 | train | Real-time machine learning: challenges and solutions | writings, decisions, expression, timeline |
| `src-fd274ef06682` | P1 | train | Why data scientists shouldn’t need to know Kubernetes | writings, decisions, expression, timeline |
| `src-8ccfdbc0c905` | P1 | train | A friendly introduction to machine learning compilers and optimizers | writings, expression, timeline |
| `src-66e410fead4f` | P1 | train | 7 reasons not to join a startup and 1 reason to | writings, decisions, expression, timeline |
| `src-869f22706591` | P1 | train | Machine Learning Tools Landscape v2 (+84 new tools) | writings, decisions, timeline |
| `src-503067bbb100` | P1 | train | Machine learning is going real-time | writings, decisions, expression, timeline |
| `src-92a258ccc151` | P1 | train | Machine Learning Systems Design at Stanford | writings, decisions, timeline |
| `src-87cf351c132f` | P1 | train | What I learned from looking at 200 machine learning tools | writings, decisions, expression, timeline |
| `src-c455d081c4d2` | P1 | train | Analysis of compensation, level, and experience details of 19k tech workers | writings, decisions, timeline |
| `src-774b8db6e306` | P1 | train | Books that shaped my decade | writings, expression, timeline |
| `src-f3e016f99a92` | P1 | train | Four lessons I learned after my first full-time job after college | writings, decisions, expression, timeline |
| `src-5b1de3924272` | P1 | train | Key trends from NeurIPS 2019 | writings, expression, timeline |
| `src-b8e18c7b697f` | P1 | train | What Glassdoor interview reviews reveal about tech hiring cultures | writings, decisions, timeline |
| `src-511f2bb02b69` | P1 | train | 10 free online machine learning courses | writings, decisions, expression, timeline |
| `src-8a073b3e76d1` | P1 | train | Machine learning interviews book | writings, decisions, expression, timeline |
| `src-6a746a1f7800` | P1 | train | Top trends from ICLR 2019 | writings, expression, timeline |
| `src-d07c034a387a` | P1 | train | What does it mean to be a woman in tech? | writings, expression, timeline |
| `src-bbc35a76d972` | P1 | train | Building meaningful relationships | writings, expression, timeline |
| `src-5e0ccea99bd1` | P1 | train | Career advice for recent Computer Science graduates | writings, decisions, expression, timeline |
| `src-056145e25e75` | P1 | train | SOTAWHAT: Making sense of the state of the art | writings, decisions, timeline |
| `src-c752dd8c0ba2` | P1 | train | A survivor’s guide to AI courses at Stanford | writings, decisions, expression, timeline |
| `src-dcbf9f47c166` | P1 | train | Confession of an AI expert | writings, expression, timeline |
| `src-12df378861ca` | P2 | train | Spotlight: Chip Huyen | conversations, expression, external, timeline |
| `src-04f3225c87f8` | P2 | train | Designing Machine Learning Systems | writings, external, decisions, timeline |
| `src-74aa287033e4` | P2 | train | AI Engineering | writings, external, decisions, timeline |
| `src-d67945b6ea45` | P2 | train | Generative AI in the Real World: Chip Huyen on Finding Business Use Cases | conversations, expression, external, decisions, timeline |
| `src-f788c243a89c` | P2 | train | Chip Huyen on Her Career, Writing, and Machine Learning | conversations, expression, external, decisions, timeline |
| `src-d368fb1c912c` | P2 | train | Voltron Data Acquires Claypot | external, decisions, timeline |
| `src-a1300f31d23d` | P2 | train | NVIDIA NeMo repository | external, decisions, timeline |
| `src-8733f947339f` | P2 | train | From ML Engineering to AI Engineering with Chip Huyen | conversations, external, expression, timeline |
| `src-90d4265ab5d8` | P2 | train | How to Evaluate AI that's Smarter than Us | writings, external, decisions, timeline |
| `src-683a79e38486` | P2 | train | Chip Huyen — Snorkel AI author profile | external, timeline |
| `src-87423268b75e` | S1 | holdout | Chip Huyen on upskilling for AI engineering | conversations, external, timeline |
| `src-751c48408f6e` | S1 | holdout | Coding with AI — Chip Huyen | external, timeline |
| `src-b6fc42c0b6b0` | S1 | holdout | Chip Huyen — Google Scholar profile | external, timeline |
| `src-e197cae00d00` | S1 | holdout | Chip Huyen — ACM author profile | external, timeline |

## 7. 使用建议

最适合的调用形式是直接给任务，例如“用该人物模型审查这个 AI agent 上线方案”或“按该模型设计一套 AI 工程学习路线”。运行时先自动路由身份，不要求用户选择编号或权重。输出应保留事实层级、简单基线、评价、反馈、风险和停止规则。
