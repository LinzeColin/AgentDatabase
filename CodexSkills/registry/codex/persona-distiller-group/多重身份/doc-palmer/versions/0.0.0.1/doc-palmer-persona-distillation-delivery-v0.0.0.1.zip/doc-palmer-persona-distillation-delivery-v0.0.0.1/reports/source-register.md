# Source Register

Research cutoff: 2026-07-24. `train` sources support Claims; `holdout` sources are evaluation-only. Rights are public-access-for-analysis; no source body is redistributed in the runtime package.

| Source ID | Split | Tier | Lanes | Title |
|---|---|---|---|---|
| src-d0b479d24577 | train | P1 | timeline / decisions / external | Richard Palmer and Associates — About Richard “Doc” Palmer |
| src-651bb53c5510 | train | P1 | writings / decisions / expression | Richard Palmer and Associates — The Maintenance Planning and Scheduling Handbook |
| src-fc7104f5a560 | train | P2 | timeline / writings / external | Doc Palmer — Plant Services author profile |
| src-cb5735b4accf | train | P1 | writings / decisions / expression | Organizational clarity for maintenance roles: A super quick run through |
| src-a3e3e500e920 | train | P1 | writings / decisions / expression | The enormous value of management protecting maintenance planners |
| src-8d590cd7ecfa | train | P1 | writings / decisions / expression | The real dollar value of planning: How to turn maintenance time into money |
| src-6e176336011b | train | P1 | writings / decisions / expression | Time estimates in work orders: To show or not to show? |
| src-914c6b4abe33 | train | P1 | writings / decisions / expression | Build a workflow process that helps you better manage your maintenance team |
| src-09a3e9001200 | train | P1 | writings / decisions / expression | How to establish a work priority system |
| src-584d41fe8ff7 | train | P1 | conversations / expression / decisions | Fix Reactive Maintenance with Better Planning ft. Doc Palmer |
| src-9d6b0ec9c1bc | train | P2 | writings / timeline / external | Maintenance Planning and Scheduling Handbook, 4th Edition — Apple Books |
| src-d01647036463 | train | P2 | writings / timeline / external | Maintenance Planning and Scheduling Handbook 3/E — Google Books |
| src-acf11c33891a | train | P2 | timeline / external | McGraw-Hill AccessEngineering catalog — Palmer handbook editions |
| src-d74040dbcfb7 | train | P2 | writings / external / timeline | Maintenance Planning and Scheduling Handbook — Fourth Edition |
| src-159c735a9ca1 | train | P2 | conversations / timeline / external | Doc Palmer — Planning & Scheduling workshop, Sydney, October 2023 |
| src-0047f092c1a8 | train | P2 | timeline / external / conversations | Doc Palmer — CMC Latinoamerica |
| src-de076bcdb82c | train | P2 | external / decisions / conversations | Principles of Maintenance Planning |
| src-8a39f8672507 | train | P2 | external / decisions / expression | The Impact of Workforce Availability on Maintenance Efficiency |
| src-7c6576775413 | train | P2 | external / decisions / expression | 6 Efficiency Tips From Leading Reliability & Maintenance Experts |
| src-cf4b08c39c04 | train | S1 | external / conversations / expression | The Very Best Maintenance Podcast Episodes of 2020 |
| src-7cbb3d96face | train | P2 | conversations / decisions / external | VIDEO: Maintenance Planning and Scheduling |
| src-bdedf32b6706 | train | S1 | external / conversations / writings | What is Maintenance Planning & Scheduling? |
| src-05ab898998dc | train | S2 | external / writings | Best materials for passive maintenance: podcasts and books |
| src-4f91cf239b6e | train | P2 | writings / timeline / external | Maintenance Planning and Scheduling Handbook, 4th Edition |
| src-f8cb7a587230 | train | P2 | conversations / decisions / timeline | SIRF Webinar — Increase Your Workforce without Hiring |
| src-a3adc8859cf7 | holdout | P1 | writings / decisions / expression | Do you know the purpose and principles of maintenance planning and scheduling? |
| src-6c601e25c11b | holdout | P1 | writings / expression / decisions | Rethinking industrial quality: Why perfection isn’t the goal in manufacturing reliability |
| src-0927aa52592c | holdout | P2 | conversations / external / timeline | Fix Reactive Maintenance with Better Planning ft. Doc Palmer — Apple Podcasts mirror |

Primary/near-primary records use P1/P2. S1/S2 records are limited to adoption and contextual triangulation. Effect claims are not promoted merely because multiple secondary pages repeat the same Palmer-origin number.
