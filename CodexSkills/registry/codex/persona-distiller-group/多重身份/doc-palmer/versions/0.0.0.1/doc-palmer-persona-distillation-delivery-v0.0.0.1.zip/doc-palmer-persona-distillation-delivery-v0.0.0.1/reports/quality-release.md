# Persona Distiller quality report

- Target: `/mnt/data/doc-palmer-workspace/doc-palmer`
- Phase: `release`
- Profile: `standard`
- Generated: `2026-07-24T10:03:55Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 52,
  "ledger_counts": {
    "sources": 28,
    "claims": 41
  },
  "sources_total": 28,
  "sources_train": 25,
  "sources_usable_train": 25,
  "sources_holdout": 3,
  "primary_sources": 22,
  "primary_ratio": 0.88,
  "lane_source_counts": {
    "writings": 14,
    "conversations": 8,
    "expression": 11,
    "external": 16,
    "decisions": 14,
    "timeline": 10
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 41,
  "claims_active": 41,
  "mental_models": 5,
  "heuristics": 9,
  "claim_markers": 41,
  "eval_cases": 16,
  "eval_suite_counts": {
    "known": 1,
    "boundary": 1,
    "voice": 1,
    "trajectory": 1,
    "contrast": 1,
    "fact-preservation": 1,
    "style-decoy": 1,
    "task-completion": 1,
    "planning-fidelity": 1,
    "tool-use": 1,
    "capability-calibration": 1,
    "refusal-stop": 1,
    "long-horizon": 1,
    "identity-routing": 1,
    "anonymous-fidelity": 1,
    "token-efficiency": 1
  },
  "eval_results": 64,
  "candidate_overall": 0.9575,
  "baseline_overall": 0.6487,
  "candidate_baseline_delta": 0.3088,
  "suite_candidate_means": {
    "known": 0.96,
    "boundary": 0.98,
    "voice": 0.93,
    "trajectory": 0.94,
    "contrast": 0.95,
    "fact-preservation": 0.98,
    "style-decoy": 0.97,
    "task-completion": 0.95,
    "planning-fidelity": 0.96,
    "tool-use": 0.96,
    "capability-calibration": 0.97,
    "refusal-stop": 0.99,
    "long-horizon": 0.95,
    "identity-routing": 0.96,
    "anonymous-fidelity": 0.94,
    "token-efficiency": 0.93
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
