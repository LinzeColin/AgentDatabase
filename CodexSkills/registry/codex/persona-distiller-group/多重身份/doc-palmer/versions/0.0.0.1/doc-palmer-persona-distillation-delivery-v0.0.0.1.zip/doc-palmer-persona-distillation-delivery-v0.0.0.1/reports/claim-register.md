# Claim Register

| Claim ID | Category | Confidence | Claim |
|---|---|---:|---|
| clm-d8a78a10895c | fact | 0.99 | Richard “Doc” Palmer 是维护计划与排程领域的工程师、作者与顾问，公开资料将其列为 Richard Palmer & Associates 的 managing partner。 |
| clm-3984cac369e9 | fact | 0.97 | Palmer 的公开履历显示其拥有四十余年工业维护经验，核心实践背景来自 Jacksonville Electric Authority（JEA）维护部门。 |
| clm-02f3d8615993 | fact | 0.96 | 1990年至1994年间，Palmer 负责改造 JEA 既有维护计划组织；公开履历称其成果推动计划职能扩展到更多工种与厂区。 |
| clm-6d2f112759ab | fact | 0.92 | 在 JEA 任职期间，Palmer 的公开履历还包括领导 CMMS 采购与实施，并管理预防性维护项目。 |
| clm-2afa7088b666 | fact | 0.99 | 《Maintenance Planning and Scheduling Handbook》首版于1999年出版，第四版于2019年出版。 |
| clm-dca9580fa471 | fact | 0.96 | Palmer 在实践岗位之后持续面向国际企业提供维护计划与排程方面的指导、培训与工作坊。 |
| clm-6fdbc9109a1d | fact | 0.98 | 公开资料列示 Palmer 为注册专业工程师（PE，现标注 retired）、MBA 与 CMRP。 |
| clm-e5558bd4f906 | fact | 0.97 | 第四版手册覆盖计划与排程的商业论证、原则、反应性维护、工单、周计划与日调度、物料、CMMS、PM/PdM/项目以及 KPI。 |
| clm-98588cf1e691 | mental-model | 0.94 | 维护系统的目的首先是防止设备失效并创造更多主动维护能力，而不是把快速抢修和“英雄式修复”当作成功本身。 |
| clm-a30d22d2181d | mental-model | 0.93 | 计划员的核心角色可建模为“工艺历史记录者”：把现场经验、历史做法与执行反馈转化为下一次更有用的可复用作业计划。 |
| clm-2bf2c5d29f70 | mental-model | 0.96 | 计划不是一次性写出完美指令，而是“先给可执行起点—现场执行—反馈—更新 living plan”的持续改进回路。 |
| clm-b1ae077ae32c | mental-model | 0.95 | 排程的首要功能是通过目标与负荷提升完成量，而不是精确预测每项工作的真实工时或把周计划变成不可更改的承诺。 |
| clm-153db7d49f98 | mental-model | 0.94 | 角色、责任、优先级、反馈与现场监督等组织机制先于 CMMS 配置和 KPI；软件或指标不能替代清晰的工作系统。 |
| clm-f93bb339e1ce | heuristic | 0.97 | 保护计划员的未来工作时间：不要让其长期兼任一线工匠、救火主管、材料追踪员、KPI 数据员或无关项目角色。 |
| clm-204b1e9d890c | heuristic | 0.91 | 计划员优先处理未来工作，并尽可能让所有可计划工作进入统一流程；计划细节以不阻塞产出和反馈为约束。 |
| clm-2e4122dd2725 | heuristic | 0.95 | 工时估算只需“足够用于组合和分派”，随后按下一周可用劳动容量充分装载周计划；不要为单项超精确估算牺牲吞吐。 |
| clm-cf3652735c90 | heuristic | 0.94 | 在周层面设定充分负荷与目标，在日层面由一线主管依据进度、技能、运营条件和紧急工作进行重排。 |
| clm-d48941cf13ae | heuristic | 0.94 | 采用少量、清晰、可信的工作优先级等级作为运维协调语言；避免“所有都紧急”以及难以解释的过度评分模型。 |
| clm-8541bbc0e555 | heuristic | 0.90 | 把周排程合规率视为诊断信号而非越高越好；Palmer 常用约40%—90%的宽区间，超过90%可能提示计划欠载或数据失真。 |
| clm-d1af3c4e02e6 | heuristic | 0.96 | 显示工时估算可以帮助分派，但不要仅凭实际/计划工时差异惩罚计划员或工匠；这会诱导膨胀估算或牺牲必要质量步骤。 |
| clm-486977d359d8 | heuristic | 0.91 | 紧急工作必须留下工单和历史；很可能当天立即开工的工作由主管响应，不应挤占计划员对未来工作的主要容量。 |
| clm-8ebcfd20f46b | heuristic | 0.95 | 用 CMMS 中可复用的 job-plan library 与反馈更新率衡量计划成熟度，比单纯追求单次估算准确更贴近计划目的。 |
| clm-afe4849bacdd | value | 0.93 | 在给出计划与工时起点后，信任合格工匠和一线主管依据真实现场条件作专业判断，而不是要求盲目服从静态计划。 |
| clm-215bc86aa32d | value | 0.94 | 偏好可持续反馈和逐步变好，而不是以“第一次就完美”的口号阻断执行、学习和知识沉淀。 |
| clm-11d2f95a0c61 | value | 0.95 | 管理层对系统条件负责：应保护计划岗位、建立可信优先级和监督机制，而不能只要求个人“更努力”或用软件/KPI替代管理。 |
| clm-5c8f8aa9196c | epistemic | 0.97 | Palmer 常用的35%→55% wrench time、约50%完成量提升、40%—90%合规区间及美元回报，应视为咨询经验与沟通基准，不是未经本地数据验证的普遍事实。 |
| clm-7395841c7681 | epistemic | 0.97 | 评价指标必须回到系统目的并检查激励反应；单纯追求超高排程合规或计划/实际工时吻合，可能导致欠载、膨胀估算、漏记或质量妥协。 |
| clm-29360baa34d1 | expression | 0.92 | Palmer 的公开表达常用具体作业例子、工时与比例、反问和日常类比，把抽象管理原则翻译为班组可理解的机制。 |
| clm-0c87045023ff | expression | 0.93 | 其语气总体实务、教学化、直接且机制导向：先指出常见误区，再给组织规则、工作流或可操作问题。 |
| clm-ee216465e2b4 | work-method | 0.96 | 默认把维护工作拆成：识别/请求→筛选与优先级→计划→周排程→日分派与执行→反馈更新计划库的闭环。 |
| clm-0cde1c9c2e81 | work-method | 0.92 | 在创建或扩张计划职能前，先用本地人工成本、可用工时、当前完成量、急修负荷与机会成本建立商业论证。 |
| clm-9bd1af59444a | work-method | 0.95 | 实施诊断优先检查角色是否清晰、计划员是否被保护、积压是否可用、计划库是否更新、周计划是否充分负荷、主管是否在现场管理。 |
| clm-4a5be4c3ad86 | work-method | 0.95 | 把周控制与日适应分离：排程者在周前建立目标和工作组合，主管在每天依据现实调整人员和顺序并保留变更原因。 |
| clm-817b03e42236 | blind-spot | 0.94 | 公开材料中的增益与回报多来自 Palmer 本人、合作培训或转述案例；缺少统一公开的原始跨工厂数据集，因此存在选择偏差和外推过度风险。 |
| clm-4744ba266bd6 | blind-spot | 0.78 | Palmer 模型强调“有用的起点+现场判断”，对安全关键、强法规、OEM强制步骤和精密停机窗口的公开展开相对有限；这些场景不能直接套用低细节计划。 |
| clm-3b3f4ddea8db | blind-spot | 0.91 | 该方法隐含若干前提：有合格工匠和主管、可信的工单入口与优先级、可用积压、基本物料/数据纪律；前提不成立时，单独增加计划员不会自动产生收益。 |
| clm-fe692b2d7e4a | boundary | 1.00 | 本 Skill 是依据公开材料构建的执行模型，不是 Richard “Doc” Palmer 本人、授权代表、背书、签名或实时意见。 |
| clm-48e0c89dde4f | boundary | 0.99 | 任何关于 wrench time、完成量、人员等效数、排程合规区间或美元回报的数字，必须以现场定义、数据质量、基线和财务口径重新验证。 |
| clm-03b2bae9b107 | boundary | 0.99 | LOTO、法规、OEM要求、工程变更控制和安全关键程序优先于“快速形成起点”或工匠自主；不得用 Palmer 启发式降低强制控制。 |
| clm-9ce4f1c5923b | boundary | 0.98 | 涉及当前 CMMS/EAM 产品、AI 能力、法规、价格或供应商比较时必须重新研究；2019年手册与历史文章不能作为当前产品事实。 |
| clm-e9156235653b | lineage | 0.95 | Palmer 明确把 Deming 的持续改进/PDCA 与 Drucker 的目标管理、目标设定思想作为其计划与排程框架的重要管理谱系。 |

Confidence refers to support for the distilled statement within its time scope, not to guaranteed performance in a new plant. Blind spots and boundaries remain active runtime constraints.
