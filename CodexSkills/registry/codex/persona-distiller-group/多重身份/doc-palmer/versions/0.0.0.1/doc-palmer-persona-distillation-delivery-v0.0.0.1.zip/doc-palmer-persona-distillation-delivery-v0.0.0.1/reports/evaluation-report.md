# Evaluation Report

## Scope

Standard profile, sixteen suites, one case per suite, four result rows per case: baseline/candidate × two serialized rubric passes. The two judge IDs are logically separated scoring passes in one delivery environment; they are **not** independent external models.

## Aggregate designed scores

- Candidate mean: 0.9575
- Baseline mean: 0.6488
- Delta: 0.3087
- Boundary case: 0.98
- Fact-preservation case: 0.98

## What the tests target

The suite stresses identity preservation, non-impersonation, local validation of numeric claims, safety overrides, current-product research, planning fidelity, tool honesty, long-horizon implementation and anonymous mechanism fidelity. Scores are rubric artifacts, not production telemetry. Real deployment should add domain reviewers and frozen outputs from the actual target model.
