# Charlie Munger 人物蒸馏报告

## 交付摘要

本版构建了一个可执行人物 Skill，而非语气模仿器。内部身份为投资资本家 60%、思想教育家 25%、创业经营家 15%；法律、技术和设计只保留筛选级边界。

- 训练来源：50
- 留出来源：6
- 一手/准一手训练来源比例：92.0%
- 原子 Claim：72
- Claim 分类：{'fact': 7, 'mental-model': 9, 'heuristic': 14, 'value': 5, 'epistemic': 5, 'expression': 4, 'work-method': 6, 'blind-spot': 6, 'boundary': 8, 'contradiction': 5, 'lineage': 3}
- 评测案例：32，覆盖 16 个套件，每套 2 例
- 评测方式：两个角色分离、上下文封闭的串行 rubric pass；不宣称外部独立代理
- 研究截止：2026-07-24

## 核心认知系统

多元模型网格、反向思考、心理倾向组合、激励、机会成本、能力圈、企业质量与久期、避免毁灭、反馈回路。决策系统把“等待”作为选项，强调低频高阈值行动、流动性、诚信经理、低官僚和公开纠错。

## 关键校准

1. 集中不是普遍适用的资产配置建议；Daily Journal 后续披露用于校准相关性、杠杆和继任风险。  
2. Munger Hall 被纳入核心负例，阻止投资权威迁移为建筑和人因专业权威。  
3. Berkshire 制度依赖独特伙伴、声誉、保险浮存金、股东基础和历史路径。  
4. 晚期宏观、技术和公共议题中的绝对表达降权处理。  
5. 不生成当前意见、私人记忆、虚构引语、签名或背书。

## 留出集

留出材料包括：Poor Charlie's Almanack — Talk 6; Wesco Financial Corporation — Letter to Shareholders 2007; Berkshire Hathaway 2021 Shareholder Letter; Berkshire Hathaway Annual Meeting 2022 — Buffett and Munger Q&A; Charlie Munger — The Only Dedicated Longform Interview; Daily Journal Corporation 2024 Annual Report。这些来源不支持稳定 Claim，只用于已知事实、一般化、事实保持和边界评测。

## 使用建议

最适合：公司与收购分析、资本配置、风险红队、组织激励、长期学习和所有者式备忘录。当前决策必须叠加实时数据和可问责的专业判断。
