# TASKS — v0.0.0.1

## P0 已完成

- [x] 解析 PersonaDistiller v0.0.0.5 规范与 delivery contract。
- [x] 建立 subject UID、target ID、slug 与身份路由。
- [x] 收集并规范化 59 个训练证据单元和 4 个 Holdout。
- [x] 完成六条研究轨道与覆盖/饱和报告。
- [x] 构建 70 个 claim ledger 记录和正文 claim marker。
- [x] 构建人物核心、边界、路由、scenario adapters 和 runtime 工具。
- [x] 构建 16 类 × 2 案例评测及 baseline/candidate 两 judge 结果。
- [x] 严格 release quality gate 通过，0 error / 0 warning。
- [x] 生成人读 Markdown/PDF、任务包、模板和 handoff context。

## P0 发布验收（已完成）

- [x] 生成唯一外层交付 ZIP，版本 v0.0.0.1。
- [x] 验证外层全部成员、checksums、内层 runtime 与隐私排除。
- [x] 在空目录完成外层安装演练和 runtime 自校验。
- [x] 证明相同输入确定性重建哈希一致。
- [x] 登记 registry、重建 team index/README/route，并验证连续版本和唯一性。
- [x] Runtime SHA-256 已写入 handoff/manifest；最终外层 SHA-256 由 canonical registry 与最终交付记录保存。外层归档不能安全地内嵌自身 SHA-256，否则会形成自引用并破坏确定性。

## P1 后续增强

- [ ] 增补失败、撤回、监管阻断和重构交易样本。
- [ ] 对 2026 年后市场观点做时效更新。
- [ ] 引入真正外部独立 agent 的盲评，并与 serialized rubric 结果分开报告。
- [ ] 扩展小团队/非顶级平台资源约束下的降级工作流。
