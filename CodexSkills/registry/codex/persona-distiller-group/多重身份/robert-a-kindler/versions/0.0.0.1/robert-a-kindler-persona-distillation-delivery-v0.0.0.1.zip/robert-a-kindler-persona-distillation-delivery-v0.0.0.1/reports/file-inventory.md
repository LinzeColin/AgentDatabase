# File Inventory

## 外层交付预期结构

```text
robert-a-kindler-persona-distillation-delivery-v0.0.0.1/
├── README.md
├── handoff.md
├── install.py / install.sh / install.ps1
├── delivery-manifest.json
├── delivery-checksums.sha256
├── registration.json
├── team-card.json
├── runtime/
│   └── robert-a-kindler-persona-skill-v0.0.0.1.zip
├── audit/
│   ├── verification.json
│   ├── provenance.json
│   ├── source-coverage.json
│   ├── evaluation-summary.json
│   └── review-record.json
└── reports/
    ├── Robert-A-Kindler-Persona-Distillation-Report-v0.0.0.1.pdf
    ├── Robert-A-Kindler-Persona-Distillation-Report-v0.0.0.1.md
    ├── handoff-context.md
    ├── file-inventory.md
    ├── selected-evidence-index.md
    ├── codex-task-pack-v0.0.0.1/
    │   ├── PRD-v0.0.0.1.md
    │   ├── TASKS.md
    │   ├── ACCEPTANCE.md
    │   └── RUNBOOK.md
    └── templates/
        ├── board-decision-memo-template.md
        └── six-friction-red-team-template.md
```

## Runtime 内容类别

- 人物核心：SKILL、persona、cognitive OS、decision policy、strategy、capabilities、boundaries、work。
- 身份：identity catalog、multi-identity、political-legal、investor-capital-allocator 等 facet 文件。
- 路由：route manifest、scenario adapters、runtime router。
- 证据：sanitized source ledger、claim ledger、coverage/saturation/source universe。
- 评测：cases、results、说明。
- 安装与完整性：installers、PACKAGE_MANIFEST、checksums。
- 状态重置：runtime invocation、episodic memory 和 corrections 在发布时清空。

## 明确排除

raw 源正文、Holdout 正文、私密来源正文、凭据、缓存、symlink、历史调用、私人路径、未授权心理推断。

## 数量摘要

- 来源记录：63（train=59，holdout=4）
- 主张记录：70
- 测试案例：32
- 测试结果：128
- 研究轨：6
