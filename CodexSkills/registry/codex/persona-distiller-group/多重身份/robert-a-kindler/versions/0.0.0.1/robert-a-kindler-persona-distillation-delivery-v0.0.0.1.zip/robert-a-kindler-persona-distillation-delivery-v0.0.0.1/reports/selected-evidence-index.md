# Selected Evidence Index

| Source ID | Split | Tier | Published | Title | Locator | URL |
| --- | --- | --- | --- | --- | --- | --- |
| src-fd5e9e20d179 | train | P1 | 持续更新页面 | Robert A. Kindler profile — current role | Biography > current role | https://www.paulweiss.com/professionals/partners-and-counsel/robert-a-kindler |
| src-e7c57942ac80 | train | P1 | 持续更新页面 | Robert A. Kindler profile — Morgan Stanley leadership | Biography > former Morgan Stanley roles | https://www.paulweiss.com/professionals/partners-and-counsel/robert-a-kindler |
| src-8fecfc5526df | train | P1 | 持续更新页面 | Robert A. Kindler profile — four-decade dual profession | Biography > career duration and dual role | https://www.paulweiss.com/professionals/partners-and-counsel/robert-a-kindler |
| src-19845d8599b1 | train | P1 | 2006-04-06 | Morgan Stanley hiring release — vice chairman mandate | Opening announcement | https://www.morganstanley.com/press-releases/robert-a-kindler-joins-morgan-stanley-as-vice-chairman-of-investment-banking_3746 |
| src-5b7d0cf00ab2 | train | P1 | 2006-04-06 | Morgan Stanley hiring release — client focus and innovative thinking | Leadership endorsement | https://www.morganstanley.com/press-releases/robert-a-kindler-joins-morgan-stanley-as-vice-chairman-of-investment-banking_3746 |
| src-8555caaa1ddc | train | P2 | 2011-02-01 | A Chat with Robert Kindler — law and banking contrast | Q&A > differences between law and banking | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-d61815110873 | train | P2 | 2011-02-01 | A Chat with Robert Kindler — every word discipline | Q&A > Cravath document discipline | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-2cb9dceba1f2 | train | P2 | 2011-02-01 | A Chat with Robert Kindler — client and strategy interface | Q&A > banking work | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-96960f1a41aa | train | P2 | 2011-02-01 | A Chat with Robert Kindler — non-linear career | Q&A > career advice | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-325498f9f217 | train | P2 | 2011-02-01 | A Chat with Robert Kindler — strategic growth and market window | Q&A > M&A outlook | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-97c36310c275 | train | P2 | 2011-02-01 | A Chat with Robert Kindler — financial system fragility | Q&A > credit crisis lesson | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-2e6b3f8b0bac | train | P2 | 2011-02-01 | A Chat with Robert Kindler — Comcast public proposal | Q&A > favorite deal | https://magazine.law.nyu.edu/index.html%3Fp%3D4832.html |
| src-4ec959d44591 | train | P2 | 2023-09-22 | Bloomberg Law profile summary — lawyers receive the first call | Lawyers’ role in deals | https://www.paulweiss.com/insights/publications/rob-kindler-discusses-lawyers-pivotal-role-in-deals-and-move-to-paul-weiss-in-bloomberg-law-profile |
| src-ccc3cc311dd5 | train | P2 | 2023-09-22 | Bloomberg Law profile summary — regulatory and ESG friction | Regulatory and ESG context | https://www.paulweiss.com/insights/publications/rob-kindler-discusses-lawyers-pivotal-role-in-deals-and-move-to-paul-weiss-in-bloomberg-law-profile |
| src-0984ae70fb5d | train | P2 | 2025-02-01 | Drinks With The Deal — career connectivity | Career connectivity | https://www.thedeal.com/podcasts/drinks-with-the-deal-robert-kindler-of-paul-weiss-on-career-connectivity/ |
| src-aac221f45bf0 | train | P2 | 2025-02-01 | Drinks With The Deal — mentor Samuel Butler | Mentorship and formation | https://www.thedeal.com/podcasts/drinks-with-the-deal-robert-kindler-of-paul-weiss-on-career-connectivity/ |
| src-5950771a72b9 | train | P1 | 2015-10-12 | Dell and EMC announce approximately $67 billion transaction | Transaction announcement | https://www.dell.com/en-us/dt/corporate/newsroom/announcements/2015/10/20151012-02.htm |
| src-2d408887f798 | train | P1 | 2016-09-07 | Dell completes acquisition of EMC | Transaction completion | https://www.dell.com/en-us/dt/corporate/newsroom/announcements/2016/09/20160907-01.htm |
| src-327c19127cd4 | train | P1 | 2020-11-30 | S&P Global and IHS Markit announce $44 billion transaction | Transaction announcement | https://investor.spglobal.com/news-releases/news-details/2020/SP-Global-and-IHS-Markit-to-Merge-in-All-Stock-Transaction-Valuing-IHS-Markit-at-44-Billion-Powering-the-Markets-of-the-Future-2020-11-30/default.aspx |
| src-dc128da7b0d9 | train | P1 | 2021-11-12 | S&P Global and IHS Markit receive conditional DOJ clearance | U.S. antitrust clearance | https://investor.spglobal.com/news-releases/news-details/2021/SP-Global-and-IHS-Markit-Merger-Receives-Conditional-Clearance-from-the-U.S.-Department-of-Justice/default.aspx |
| src-b52c6fddb591 | train | P1 | 2022-02-28 | S&P Global completes merger with IHS Markit | Transaction completion | https://investor.spglobal.com/news-releases/news-details/2022/SP-Global-Completes-Merger-with-IHS-Markit-Creating-a-Global-Leader-to-Power-the-Markets-of-the-Future/ |
| src-fc5fcf989920 | train | S1 | 2023-06-06 | Veteran Morgan Stanley dealmaker Rob Kindler to join law firm | Career move report | https://www.reuters.com/business/finance/veteran-morgan-stanley-dealmaker-rob-kindler-join-law-firm-2023-06-06/ |
| src-3020a0244cea | train | S1 | 2023-06-07 | Meet the Morgan Stanley rainmaker tapped to chair Paul, Weiss M&A | Profile and career move | https://www.businessinsider.com/morgan-stanleys-robert-kindler-tapped-as-paul-weiss-ma-chair-2023-6 |

完整清单位于 runtime 的 `evidence/source-ledger.jsonl`；发布 runtime 不包含源正文。
