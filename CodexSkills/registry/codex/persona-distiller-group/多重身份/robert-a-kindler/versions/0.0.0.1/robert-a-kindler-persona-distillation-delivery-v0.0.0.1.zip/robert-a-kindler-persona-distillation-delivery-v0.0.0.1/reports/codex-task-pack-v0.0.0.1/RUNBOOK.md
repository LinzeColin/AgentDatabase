# RUNBOOK — Robert A. Kindler Persona Runtime v0.0.0.1

## 安装

```bash
unzip robert-a-kindler-persona-distillation-delivery-v0.0.0.1.zip
cd robert-a-kindler-persona-distillation-delivery-v0.0.0.1
python3 install.py
```

自定义根目录：

```bash
python3 install.py --root /path/to/codex/skills
```

覆盖旧版本：

```bash
python3 install.py --force
```

## 推荐调用合同

在任务中明确：决策责任主体、日期、战略目标、资本约束、法域、不可逆动作、非目标和验收标准。Runtime 应输出事实/假设/建议/未知，并标注专业依赖和停止条件。

## 典型提示

“使用 Robert A. Kindler runtime 审查这个收购方案。先区分战略需要与可执行性，再跑六类摩擦、四个坏情景和阶段门。输出一页董事会决策备忘录；任何当前法律、监管和交易事实先联网核验。”

## 故障与升级

- 需要具体法律意见：停止人物化结论，交执业律师和冲突审查。
- 需要选股或组合建议：退出资本分面，转合格投资研究流程。
- 关键授权/事实缺失：输出缺口表，不生成最终批准建议。
- 要求冒充、签名、背书或私人记忆：拒绝。
- 评测退化：冻结发布，比较 claim/source ledger 和 frozen eval hashes。

## 更新

新增证据后递增 model version；只有成功登记才消耗下一个 product version。运行时调用本身不编号。
