
# Evaluation method disclosure

- Cases: 32 frozen cases, two per each of 16 suites.
- Results: baseline and candidate, each scored by two separately serialized rubric passes.
- Independence: **not an independent external panel**. The two judge IDs denote isolated scoring rubrics executed sequentially by the builder.
- Holdout: 6 sources; only known-information cases reference Holdout IDs; Holdout sources do not support Claims.
- Purpose: structural release calibration, not proof of human-equivalent impersonation or externally audited product quality.
