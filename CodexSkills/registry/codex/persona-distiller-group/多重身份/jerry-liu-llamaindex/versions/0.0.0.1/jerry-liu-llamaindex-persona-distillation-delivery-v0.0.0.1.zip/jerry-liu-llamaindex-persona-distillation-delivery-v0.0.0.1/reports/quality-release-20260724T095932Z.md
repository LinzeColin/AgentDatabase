# Persona Distiller quality report

- Target: `/mnt/data/jerry_liu_build/workspaces/jerry-liu-llamaindex`
- Phase: `release`
- Profile: `deep`
- Generated: `2026-07-24T09:59:32Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 67,
  "ledger_counts": {
    "sources": 63,
    "claims": 58
  },
  "sources_total": 63,
  "sources_train": 57,
  "sources_usable_train": 57,
  "sources_holdout": 6,
  "primary_sources": 53,
  "primary_ratio": 0.9298,
  "lane_source_counts": {
    "writings": 32,
    "conversations": 10,
    "expression": 17,
    "external": 20,
    "decisions": 40,
    "timeline": 30
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 58,
  "claims_active": 58,
  "mental_models": 6,
  "heuristics": 10,
  "claim_markers": 58,
  "eval_cases": 32,
  "eval_suite_counts": {
    "known": 2,
    "boundary": 2,
    "voice": 2,
    "trajectory": 2,
    "contrast": 2,
    "fact-preservation": 2,
    "style-decoy": 2,
    "task-completion": 2,
    "planning-fidelity": 2,
    "tool-use": 2,
    "capability-calibration": 2,
    "refusal-stop": 2,
    "long-horizon": 2,
    "identity-routing": 2,
    "anonymous-fidelity": 2,
    "token-efficiency": 2
  },
  "eval_results": 128,
  "candidate_overall": 0.8969,
  "baseline_overall": 0.6681,
  "candidate_baseline_delta": 0.2288,
  "suite_candidate_means": {
    "known": 0.95,
    "boundary": 0.92,
    "voice": 0.86,
    "trajectory": 0.89,
    "contrast": 0.88,
    "fact-preservation": 0.96,
    "style-decoy": 0.91,
    "task-completion": 0.89,
    "planning-fidelity": 0.88,
    "tool-use": 0.87,
    "capability-calibration": 0.93,
    "refusal-stop": 0.95,
    "long-horizon": 0.87,
    "identity-routing": 0.9,
    "anonymous-fidelity": 0.86,
    "token-efficiency": 0.83
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
