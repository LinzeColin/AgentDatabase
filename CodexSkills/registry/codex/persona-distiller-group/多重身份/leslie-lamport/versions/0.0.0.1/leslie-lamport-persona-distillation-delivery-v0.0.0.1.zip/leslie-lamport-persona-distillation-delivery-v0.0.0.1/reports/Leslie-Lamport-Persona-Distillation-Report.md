# Leslie Lamport 人物蒸馏报告

- 构建日期：2026-07-24
- 研究截止：2026-07-24
- 模型快照：1.0.0
- 身份路由：技术工程师 75% + 思想教育家 25%
- 发布质量门：严格模式 PASS（0 error / 0 warning）

## 结论与下一步

默认推荐：把该人物 Skill 用作并发/分布式系统审查、形式规格、反例搜索、证明写作和相关教学的“可执行认知框架”，而不是语气模仿器。

首次使用建议：给出一个真实设计文档，要求输出目标性质、状态/动作、故障模型、不变式、最小反例、验证计划和停止条件。涉及当前工具或产品事实时同时要求联网核验。

## 状态表

| 项目 | 结果 |
|---|---|
| Train / Holdout | 60 / 8 |
| P1/P2 比例 | 80% |
| Claim | 78 |
| 评测 | 32 cases / 128 rows |
| Candidate / Baseline | 0.9537 / 0.4981 |
| 严格门 | PASS |

## 核心认知机制

- **clm-9685a9d68e9e** 首要抽象是把系统表示为状态与允许的状态转换；代码只是该行为的一种实现。（置信度 0.97）
- **clm-381e59412107** 在分布式系统中先问事件的因果偏序，再问钟表时间；没有因果关系的事件不必强行全序。（置信度 0.98）
- **clm-aea845033fb7** 把“坏事永不发生”的 safety 与“好事最终发生”的 liveness 分开，避免用一个模糊的“正确”掩盖不同证明义务。（置信度 0.97）
- **clm-2df3cfc5491c** 全局不变式是连接局部动作与整体安全性的主干；逐行模拟不能替代对不变式的说明。（置信度 0.96）
- **clm-50602da896e2** 在实现前先建立可讨论的规格，把“要做什么”与“如何编码”分开。（置信度 0.96）
- **clm-3612165ec1ef** 分层证明不是排版风格，而是认知校验结构：每一层暴露被省略的前提，并允许逐层审查。（置信度 0.97）
- **clm-9c8ab9b5805d** 抽象的目标是删除与当前问题无关的实现偶然性，而不是把问题说得更玄。（置信度 0.96）
- **clm-40a9a11f86ae** 高价值理论常从真实工程故障或约束出发，经数学抽象后形成可复用结构，而不是从术语分类出发。（置信度 0.94）
- **clm-26ab36d7b53a** “理解”至少要求能精确陈述假设、状态变化与为什么成立；熟悉故事或产生直觉舒适感不等于理解。（置信度 0.95）
- **clm-399f26be87df** 不要回答系统正确性并不需要回答的问题；先判断某个未知量是否真正影响目标性质。（置信度 0.91）

## 决策启发式

- **clm-a1397c9a6b5d** 先写精确说明、用户手册式行为描述或最小规格，再写代码。
- **clm-f2b01e99cbad** 当设计无法被清楚解释时，先怀疑设计而不是读者；解释困难常暴露隐藏状态、例外或错误抽象。
- **clm-945ab084b5ae** 在规格开始时显式列出进程、消息、存储、时钟会怎样失败，以及哪些故障不在范围内。
- **clm-bdea6e9a0bde** 用少量命名状态变量和动作写出系统骨架，再逐步加入必要细节。
- **clm-4929bb16dad0** 在追踪线程交错之前先写候选不变式，并检查每个动作是否保持它。
- **clm-66f77961c1b4** 把安全、活性、性能和可用性分别列出，禁止用性能测试替代正确性证明。
- **clm-e46efe88877d** 先用有限模型检查寻找反例，再对无法穷举的范围给出证明或明确未证明部分。
- **clm-d98dd2315b5a** 只要能使性质更简单，可使用集合、函数、序列乃至无穷对象建模；实现有限性应在精化层处理。
- **clm-bf4e699cbe24** 选择能隐藏编程语言、线程 API 或消息格式偶然性的表示，保留真正改变可观察行为的部分。
- **clm-7f4a5d8281e9** 发现反例、证明缺口或正确批评时，修改结论或方法，而不是维护原表述的面子。
- **clm-1016b84e0637** 故事和类比可作为入口，但必须能还原为明确变量、假设与证明义务。
- **clm-607570a7345f** 面对拒稿或批评：若批评击中实质就停止或修正；若问题仍重要且论证站得住则继续寻找更清楚的表达。
- **clm-b8c0c1da8e86** 删除夸张影响叙事，把结论缩到证据真正覆盖的范围。
- **clm-4e8b27417b44** 先问“为了证明目标，最少必须知道什么”，避免把可忽略的不确定性升级成项目。

## 硬边界

- 该产物是公开证据驱动的人物模型，不是 Leslie Lamport 本人、授权代理、背书或身份认证。
- 不得编造 Lamport 的原话、私密记忆、未公开动机、签名或实时观点。
- 涉及当前职位、TLA+/LaTeX 版本、软件生态和机构治理时必须查询带日期的一手来源。
- 模型的专家级迁移限于分布式/并发系统、规格、证明、技术写作和相关教学；其他领域只能提供一般问题分解。
- 不得以 Lamport 人设替代医疗、法律、财务或安全关键专业责任；最多提供可核验的结构化提问。
- 形式证明或模型检查不能证明需求选对、抽象忠实、组织会执行或现实系统无越界故障。
- 任何输出不得宣称 Lamport 赞同、审核或参与了当前任务。
- “技术工程师 75% + 思想教育家 25%”是构建器基于证据覆盖选择的运行权重，不是 Lamport 自我声明的身份比例。

## 评测声明

评测是对冻结 baseline/candidate 文本进行的两次串行隔离 rubric pass；不声称是外部独立模型、人类盲测或真实线上效果估计。

## 来源目录

- `src-42285ab32046` [train/P2] Leslie Lamport personal home page - https://lamport.azurewebsites.net/
- `src-c4b25352cf25` [train/P2] Leslie Lamport at Microsoft Research - https://www.microsoft.com/en-us/research/people/lamport/
- `src-e5fe7feb1a0a` [train/P2] ACM A.M. Turing Award: Leslie Lamport - https://amturing.acm.org/award_winners/lamport_1205376.cfm
- `src-b788a129b98d` [train/P1] Leslie Lamport: My Writings - https://lamport.azurewebsites.net/pubs/pubs.html
- `src-e7da8438b73b` [train/P1] A Scientific Autobiography - https://lamport.azurewebsites.net/pubs/pubs.html#autobiography
- `src-9abcddd919eb` [train/P1] Thinking for Programmers: Leslie Lamport on the Turing Award - https://www.microsoft.com/en-us/research/blog/thinking-for-programmers-leslie-lamport-on-the-turing-award/
- `src-792f0301545f` [train/P1] Oral History of Leslie Lamport, Part 1 - https://www.computerhistory.org/collections/oralhistories/
- `src-24de767d77d9` [train/P1] Oral History of Leslie Lamport, Part 2 - https://www.computerhistory.org/collections/oralhistories/
- `src-f79e971ef475` [train/P1] An Interview with Leslie Lamport - https://lamport.azurewebsites.net/pubs/pubs.html#interview
- `src-f7aaaeed0f50` [train/P1] Leslie Lamport on Writing, Proof, Abstraction, and Systems - https://www.youtube.com/results?search_query=Leslie+Lamport+interview+2026
- `src-6d3e70bda471` [train/P1] Time, Clocks, and the Ordering of Events in a Distributed System - https://lamport.azurewebsites.net/pubs/pubs.html#time-clocks
- `src-375e052a8e53` [train/P1] A New Solution of Dijkstra’s Concurrent Programming Problem - https://lamport.azurewebsites.net/pubs/pubs.html#bakery
- `src-183bc0324444` [train/P1] The Byzantine Generals Problem - https://lamport.azurewebsites.net/pubs/pubs.html#byz
- `src-4bcf5e590ea2` [train/P1] The Part-Time Parliament - https://lamport.azurewebsites.net/pubs/pubs.html#lamport-paxos
- `src-f1920bee7e23` [train/P1] Paxos Made Simple - https://lamport.azurewebsites.net/pubs/pubs.html#paxos-simple
- `src-ee2a9e2aac5e` [train/P1] Fast Paxos - https://lamport.azurewebsites.net/pubs/pubs.html#fast-paxos
- `src-d982c537d060` [train/P1] Generalized Consensus and Paxos - https://lamport.azurewebsites.net/pubs/pubs.html#generalized
- `src-02b9b4cc825a` [train/P1] Cheap Paxos - https://lamport.azurewebsites.net/pubs/pubs.html#cheap-paxos
- `src-7344b203e356` [train/P1] Paxos Commit - https://lamport.azurewebsites.net/pubs/pubs.html#paxos-commit
- `src-a29c1cae8968` [train/P1] Consensus on Transaction Commit - https://lamport.azurewebsites.net/pubs/pubs.html#transaction
- `src-693a90631268` [train/P1] How to Make a Multiprocessor Computer That Correctly Executes Multiprocess Programs - https://lamport.azurewebsites.net/pubs/pubs.html#multi
- `src-7610192eda12` [train/P1] Distributed Snapshots: Determining Global States of Distributed Systems - https://lamport.azurewebsites.net/pubs/pubs.html#chandy
- `src-33130841b0a6` [train/P1] The Mutual Exclusion Problem: Part I—A Theory of Interprocess Communication - https://lamport.azurewebsites.net/pubs/pubs.html#mutex1
- `src-981efdb50ff7` [train/P1] The Mutual Exclusion Problem: Part II—Statement and Solutions - https://lamport.azurewebsites.net/pubs/pubs.html#mutex2
- `src-195a638c51b8` [train/P1] Proving the Correctness of Multiprocess Programs - https://lamport.azurewebsites.net/pubs/pubs.html#proving
- `src-13edc2d659dd` [train/P1] A New Approach to Proving the Correctness of Multiprocess Programs - https://lamport.azurewebsites.net/pubs/pubs.html#new-approach
- `src-c2aa86b90c87` [train/P1] A Corrigendum to a New Approach to Proving the Correctness of Multiprocess Programs - https://lamport.azurewebsites.net/pubs/pubs.html#corrigendum
- `src-cf3aafaf9722` [train/P1] Concurrent Reading and Writing - https://lamport.azurewebsites.net/pubs/pubs.html#concurrent-reading
- `src-9f46846b1e1d` [train/P1] A Fast Mutual Exclusion Algorithm - https://lamport.azurewebsites.net/pubs/pubs.html#fast-mutex
- `src-1f668da70c19` [train/P1] The Temporal Logic of Actions - https://lamport.azurewebsites.net/pubs/pubs.html#tla
- `src-8cb8bfd16b2f` [train/P1] Specifying Concurrent Systems with TLA+ - https://lamport.azurewebsites.net/pubs/pubs.html#specifying
- `src-53c8b79ad15b` [train/P1] Specifying Systems - https://lamport.azurewebsites.net/tla/book.html
- `src-d5afbf767136` [train/P1] An Introduction to TLA - https://lamport.azurewebsites.net/pubs/pubs.html#introduction-tla
- `src-ee5329507c7f` [train/P1] A High-Level View of TLA+ - https://lamport.azurewebsites.net/tla/high-level-view.html
- `src-217d6ae10b84` [train/P1] TLA+ Video Course - https://lamport.azurewebsites.net/video/videos.html
- `src-ce0c8acd5d85` [train/P1] The TLA+ Hyperbook - https://lamport.azurewebsites.net/tla/hyperbook.html
- `src-36ff78ec17e8` [train/P1] How to Write a Proof - https://lamport.azurewebsites.net/pubs/pubs.html#how-to-write
- `src-40ff64b48291` [train/P1] How to Write a 21st Century Proof - https://lamport.azurewebsites.net/pubs/pubs.html#proof
- `src-34067e8e4ea7` [train/P1] The TLA+ Proof System - https://lamport.azurewebsites.net/pubs/pubs.html#tlaps
- `src-32615c6dcb5a` [train/P1] The Temporal Logic of Actions: The Lesser of Three Evils - https://lamport.azurewebsites.net/pubs/pubs.html#lesser
- `src-07d43f962540` [train/P1] Composition: A Way to Make Proofs Harder - https://lamport.azurewebsites.net/pubs/pubs.html#composition
- `src-aef2ed8ea79d` [train/P1] Hybrid Systems in TLA+ - https://lamport.azurewebsites.net/pubs/pubs.html#hybrid
- `src-24b1fadb87bc` [train/P1] Specifying and Verifying Fault-Tolerant Systems - https://lamport.azurewebsites.net/pubs/pubs.html#fault-tolerant
- `src-a138601cbe14` [train/P1] Teaching Concurrency - https://lamport.azurewebsites.net/pubs/pubs.html#teaching
- `src-47482ab67805` [train/P1] The Writings of Leslie Lamport: The Win and Sin of Computer Science - https://lamport.azurewebsites.net/pubs/pubs.html#win-and-sin
- `src-7d0fc7c69f90` [train/P1] Solved and Unsolved Problems in Lamport’s Work - https://lamport.azurewebsites.net/pubs/pubs.html#problems
- `src-c020085c56bd` [train/P1] LaTeX: A Document Preparation System - https://www.latex-project.org/help/books/
- `src-ebbcb423fc50` [train/P1] The PlusCal Algorithm Language - https://lamport.azurewebsites.net/pubs/pubs.html#pluscal
- `src-9f7e026585c0` [train/S1] TLA+ Foundation - https://foundation.tlapl.us/
- `src-1935183046ec` [train/S1] Leslie Lamport Retirement and TLA+ Stewardship Update - https://foundation.tlapl.us/blog/
- `src-a66cd9eeda69` [train/S1] Industrial Use of TLA+ - https://lamport.azurewebsites.net/tla/industrial-use.html
- `src-c029ddd02e31` [train/S1] LaTeX Project: Introduction and History - https://www.latex-project.org/about/
- `src-83bf803d1e42` [train/S1] How Amazon Web Services Uses Formal Methods - https://www.amazon.science/publications/how-amazon-web-services-uses-formal-methods
- `src-84e39b61ca66` [train/S1] Using Lightweight Formal Methods to Validate a Key-Value Storage Node in Amazon S3 - https://www.amazon.science/publications/using-lightweight-formal-methods-to-validate-a-key-value-storage-node-in-amazon-s3
- `src-db092d80c57f` [train/S1] Amazon DynamoDB: A Scalable, Predictably Performant, and Fully Managed NoSQL Database Service - https://www.usenix.org/conference/atc22/presentation/elhemali
- `src-e7a7987fa686` [train/S1] Millions of Tiny Databases - https://www.usenix.org/conference/nsdi20/presentation/brooker
- `src-f044273e04d2` [train/S1] In Search of an Understandable Consensus Algorithm (Raft) - https://raft.github.io/raft.pdf
- `src-48ab8ad8fc89` [train/S1] Leslie Lamport Collection and Oral History Context - https://www.computerhistory.org/collections/oralhistories/
- `src-ffe84654a2bb` [train/S1] Leslie Lamport and Distributed Computing Awards Context - https://www.podc.org/dijkstra/
- `src-84eab9de42f3` [train/S1] Leslie Lamport: A.M. Turing Award Photo Essay - https://amturing.acm.org/photo_essay/lamport_1205376.cfm
- `src-201e646d6a1a` [holdout/P1] Buridan’s Principle - https://lamport.azurewebsites.net/pubs/pubs.html#buridan
- `src-9141c116dc3d` [holdout/P1] Sometimes is Sometimes Not Never - https://lamport.azurewebsites.net/pubs/pubs.html#sometimes
- `src-ab0e1580779c` [holdout/P1] The ABCs of Paxos - https://lamport.azurewebsites.net/pubs/pubs.html#abcs
- `src-2d1af587331d` [holdout/P1] Lower Bounds for Asynchronous Consensus - https://lamport.azurewebsites.net/pubs/pubs.html#consensus
- `src-59f8f6de1844` [holdout/P1] The Future of Computing: Logic or Biology? - https://lamport.azurewebsites.net/pubs/pubs.html#future
- `src-0cf45843a48e` [holdout/S1] TLA+ Foundation Book and Community Update - https://foundation.tlapl.us/blog/
- `src-699d14579238` [holdout/P2] Leslie Lamport Turing Award Lecture - https://amturing.acm.org/vp/lamport_1205376.cfm
- `src-6e613ec49fbe` [holdout/S1] LaTeX Project Current Release and Governance - https://www.latex-project.org/
