# handoff.md - Leslie Lamport Persona Distillation

## 1. 交付状态

- 目标人物：Leslie Lamport
- 构建器：Persona Distiller v0.0.0.5
- 交付版本：v0.0.0.1
- 模型快照：1.0.0
- 构建与研究截止：2026-07-24
- 运行身份权重：technical-engineer 0.75 + thinker-educator 0.25
- 严格发布门：PASS，0 error，0 warning
- 来源：60 train + 8 holdout；train 中 P1/P2 占 80%
- 证据通道：writings / conversations / expression / external / decisions / timeline 全覆盖
- Claim：78 active；78 个 claim marker 全部渲染到核心模型文件
- 认知模型 / 启发式：10 / 14
- Evaluation：32 cases / 128 results；16 suites 各 2 cases
- Candidate / Baseline / Delta：0.9537 / 0.4981 / 0.4556

## 2. 默认用途

适用于并发与分布式架构审查、TLA+/状态机规格、故障模型、不变式与反例、形式证明结构、技术写作和相关教学。核心执行链：

`目标性质 -> 状态与动作 -> 故障边界 -> safety/liveness -> 候选不变式 -> 最小反例 -> 模型检查/证明 -> 实现精化与现实核验`

不要把该产物当成“Lamport 语气模仿器”。其主要价值是可迁移的认知结构、决策规则、工作方法和明确边界。

## 3. 核心机制

1. 以状态机而非代码行作为系统的第一表示。
2. 先建立事件因果偏序，再决定是否需要物理时间或全序。
3. 把 safety、liveness、性能与可用性拆成不同证明义务。
4. 以全局不变式连接局部动作和整体性质。
5. 规格先于实现，并把实现偶然性留到精化层。
6. 用分层证明暴露隐藏前提和推理跳步。
7. 只回答证明目标真正需要回答的问题，主动删除无关复杂度。

## 4. 不可变边界

- 该产物不是 Leslie Lamport 本人、授权代理、背书、签名或身份认证。
- 不得伪造其原话、私密记忆、未公开动机或实时观点。
- 当前职位、TLA+/LaTeX 版本、软件生态和机构治理必须按日期查询一手来源。
- 专家级迁移范围限于分布式/并发系统、规格、证明、技术写作和相关教学；其他领域只能进行一般结构化分析。
- 不得用人物模型替代医疗、法律、财务或安全关键专业责任。
- 形式证明或模型检查不能证明需求选对、抽象忠实、组织会执行或现实故障均已覆盖。
- “75% + 25%”是构建器基于公开证据覆盖作出的运行权重，不是 Lamport 的自我身份声明。

## 5. 评测解释

两位 judge ID 是同一构建流程内对冻结文本执行的串行隔离 rubric roles。它们用于结构回归、边界压测和发布门，不构成外部独立模型、人类盲测、线上 A/B 或科学性能估计。任何对真实工作效果的判断仍需用用户自己的协议文档做域内验收。

## 6. 交付结构

外层 ZIP 根目录应包含：

- `README.md`：交付说明与安装入口
- `handoff.md`：打包器生成的交接摘要
- `reports/Leslie-Lamport-Persona-Distillation-Report.pdf`：18 页正式报告
- `reports/Leslie-Lamport-Persona-Distillation-Report.md`：可检索报告源文
- `reports/handoff-full.md`：本完整交接文件
- `reports/quality-release-strict.json`：严格质量门原始结果
- `runtime/*.zip`：可安装人物 Skill 运行包
- `delivery-manifest.json`、`delivery-checksums.sha256`：文件清单与校验值
- `audit/`：证据、来源、评测和构建审计摘要

## 7. 已执行验证

- 严格 release gate：PASS，0 error / 0 warning。
- PDF inspect：18 页 A4，可打开、未加密、非扫描件。
- PDF preflight：0 warning；无 XFA；中文字体已嵌入。
- PDF render：18/18 页成功渲染并抽查，无裁切、重叠、乱码或黑块。
- 路由 smoke：任务“审查一个基于租约和物理时钟的分布式锁设计，验证双持有与时钟跳变下的正确性”加载 `red-team-risk` 与 `research-problem-solving`，并把 technical-engineer 权重提升到 0.90。
- 教学路由 smoke：新人并发教程任务加载 `research-problem-solving` 与 `teaching-learning`；thinker-educator 以 0.25 辅助权重被保留。
- 最终外层 ZIP 仍需以 `delivery/SHA256SUMS` 和外部 SHA-256 为准；不要从文件名推断完整性。

## 8. 已知缺口与失败记录

- 私信、未发表草稿、内部失败案例、完整非英语接受史和退休后的实时观点不可用。
- “研究饱和”仅针对已定义的公开来源宇宙，不宣称遍历整个互联网。
- GitHub 预检已通过网页访问 LinzeColin 账户显示的 7 个仓库入口。容器尝试递归 clone 全部仓库与 submodules 时 DNS 无法解析 `github.com`，因此未能完整核验所有嵌套子项目；该失败没有被伪装为完成，也不影响 Lamport 证据集本身。

## 9. 安装与验收

解压外层 ZIP 后，在交付根目录运行：

```bash
python3 install.py --root /path/to/skills
```

首个域内验收任务建议使用真实协议设计文档，并要求输出：目标性质、状态变量、动作、故障模型、safety/liveness、不变式、最小反例、验证方式、当前事实核验、未证明部分与停止条件。验收标准是结构与证据可追溯，而不是“听起来像 Lamport”。

## 10. 下一轮维护规则

- 新增当前事实前先检索一手来源并记录访问日期。
- 新增强 Claim 必须满足多来源、多上下文、可证伪和时间范围要求。
- 不得把 holdout 证据回灌到训练模型后仍宣称原有 holdout 隔离有效。
- 修改核心文件后必须重跑严格 release gate、PDF/报告一致性检查、外层 ZIP 校验、全新目录安装和路由 smoke。
