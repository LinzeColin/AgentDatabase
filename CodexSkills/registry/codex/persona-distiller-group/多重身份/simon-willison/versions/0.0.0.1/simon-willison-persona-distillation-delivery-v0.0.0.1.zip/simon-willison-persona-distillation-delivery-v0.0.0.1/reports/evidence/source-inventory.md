# Simon Willison Source Inventory

研究截止：2026-07-24。正文不再分发；本清单只保留元数据、摘要与审计定位。

- 来源总数：60
- Train：54
- Holdout：6
- Tier：P1=46, P2=9, S1=5

| Source ID | Tier | Split | Date | Title | URL |
|---|---:|---:|---|---|---|
| `src-99f266c01dde` | P1 | train | n.d. | About Simon Willison | https://simonwillison.net/about/ |
| `src-61d170783e7a` | P1 | train | n.d. | Simon Willison GitHub profile | https://github.com/simonw |
| `src-18329324cad5` | P1 | train | n.d. | simonw/datasette | https://github.com/simonw/datasette |
| `src-ef1ef80ff7d8` | P2 | train | n.d. | Datasette project site | https://datasette.io/ |
| `src-72893923ffe6` | P2 | train | n.d. | Datasette documentation | https://docs.datasette.io/ |
| `src-cb1d6305b23b` | P1 | train | n.d. | simonw/llm | https://github.com/simonw/llm |
| `src-b51c6efcf112` | P2 | train | n.d. | LLM documentation | https://llm.datasette.io/ |
| `src-59b537080884` | P1 | train | n.d. | simonw/sqlite-utils | https://github.com/simonw/sqlite-utils |
| `src-f2d96d4a6bfb` | P1 | train | n.d. | simonw/til | https://github.com/simonw/til |
| `src-531448add956` | P1 | train | n.d. | simonw/simonwillisonblog | https://github.com/simonw/simonwillisonblog |
| `src-a293c526510b` | P2 | train | n.d. | Simon Willison PyPI profile | https://pypi.org/user/simonw/ |
| `src-8995c3c9b69e` | P1 | train | 2025-07-13 | Happy 20th birthday Django! Here’s my talk on Django Origins from Django’s 10th | https://simonwillison.net/2025/Jul/13/django-birthday/ |
| `src-04b3348e95a2` | P2 | train | n.d. | Django project website | https://www.djangoproject.com/ |
| `src-1a6aa4d6f9ac` | P2 | train | n.d. | django/django | https://github.com/django/django |
| `src-b222d373b60f` | P2 | train | 2013-09-03 | Eventbrite acquires Lanyrd and Eventioz | https://www.eventbrite.com/blog/press/press-releases/eventbrite-acquires-london-based-lanyrd-and-latin-american-events-company-eventioz/ |
| `src-d0f1f9943a58` | P2 | train | n.d. | Lanyrd — Y Combinator company profile | https://www.ycombinator.com/companies/lanyrd |
| `src-61a64feb0c12` | P2 | train | 2024-05-01 | Simon Willison — PyCon US 2024 speaker biography | https://us.pycon.org/2024/speaker/profile/67/ |
| `src-a3bf9408e551` | P1 | train | n.d. | Series: My open source process | https://simonwillison.net/series/open-source-process/ |
| `src-9c2c64898d16` | P1 | train | 2018-07-28 | Documentation unit tests | https://simonwillison.net/2018/Jul/28/documentation-unit-tests/ |
| `src-51e28d2de70a` | P1 | train | 2021-02-19 | Open source projects: consider running office hours | https://simonwillison.net/2021/Feb/19/office-hours/ |
| `src-8b82039876b1` | P1 | train | 2021-11-04 | How to build, test and publish an open source Python library | https://simonwillison.net/2021/Nov/4/publish-open-source-python-library/ |
| `src-804187dc3ddd` | P1 | train | 2022-01-12 | How I build a feature | https://simonwillison.net/2022/Jan/12/how-i-build-a-feature/ |
| `src-06bbab3e53fe` | P1 | train | 2022-01-31 | Writing better release notes | https://simonwillison.net/2022/Jan/31/release-notes/ |
| `src-e7684f6206a6` | P1 | train | 2022-10-01 | Software engineering practices | https://simonwillison.net/2022/Oct/1/software-engineering-practices/ |
| `src-5b03422dcb6e` | P1 | train | 2022-10-29 | The Perfect Commit | https://simonwillison.net/2022/Oct/29/the-perfect-commit/ |
| `src-1867dbecae87` | P1 | train | 2022-11-26 | Coping strategies for the serial project hoarder | https://simonwillison.net/2022/Nov/26/productivity/ |
| `src-c7e8ca89e86c` | P1 | train | 2023-11-10 | Financial sustainability for open source projects at GitHub Universe | https://simonwillison.net/2023/Nov/10/universe/ |
| `src-37f9e043eebc` | P1 | train | 2023-08-06 | How I make annotated presentations | https://simonwillison.net/2023/Aug/6/annotated-presentations/ |
| `src-e2abb330a80b` | P1 | train | 2020-07-10 | Building a self-updating profile README for GitHub | https://simonwillison.net/2020/Jul/10/self-updating-profile-readme/ |
| `src-43113d5bfd4c` | P1 | train | 2023-12-31 | Stuff we figured out about AI in 2023 | https://simonwillison.net/2023/Dec/31/ai-in-2023/ |
| `src-ca63bf010417` | P1 | train | 2023-10-23 | Embeddings: What they are and why they matter | https://simonwillison.net/2023/Oct/23/embeddings/ |
| `src-9b944f71fb8c` | P1 | train | 2023-10-17 | Open questions for AI engineering | https://simonwillison.net/2023/Oct/17/open-questions/ |
| `src-1b4e08e2d1a2` | P1 | train | 2025-03-11 | Here’s how I use LLMs to help me write code | https://simonwillison.net/2025/Mar/11/using-llms-for-code/ |
| `src-99f1fbf204cd` | P1 | train | 2025-10-07 | Vibe engineering | https://simonwillison.net/2025/Oct/7/vibe-engineering/ |
| `src-f63c45e2340f` | P1 | train | 2025-10-25 | Setting up a codebase for working with coding agents | https://simonwillison.net/2025/Oct/25/coding-agent-tips/ |
| `src-3e30f503c310` | P1 | train | 2026-02-23 | Writing about Agentic Engineering Patterns | https://simonwillison.net/2026/Feb/23/agentic-engineering-patterns/ |
| `src-4ca53aebc1e9` | P1 | train | 2026-02-10 | Introducing Showboat and Rodney, so agents can demo what they have built | https://simonwillison.net/2026/Feb/10/showboat-and-rodney/ |
| `src-bbbe99b44830` | P1 | train | n.d. | Simon Willison on testing | https://simonwillison.net/tags/testing/ |
| `src-1025c18f627b` | P1 | train | n.d. | Simon Willison on projects | https://simonwillison.net/tags/projects/ |
| `src-adc443cc7785` | P1 | train | 2026-07-02 | Release: llm-coding-agent 0.1a0 | https://simonwillison.net/2026/jul/2/llm-coding-agent/ |
| `src-01cc57b5543e` | P1 | train | 2026-03-14 | My fireside chat about agentic engineering at the Pragmatic Summit | https://simonwillison.net/2026/Mar/14/pragmatic-summit/ |
| `src-f031d84d7b27` | P1 | train | 2025-06-16 | The lethal trifecta for AI agents: private data, untrusted content, and external communication | https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/ |
| `src-cb528177b47e` | P1 | train | n.d. | Series: Prompt injection | https://simonwillison.net/series/prompt-injection/ |
| `src-587283b625c7` | P1 | train | 2025-08-09 | My Lethal Trifecta talk at the Bay Area AI Security Meetup | https://simonwillison.net/2025/Aug/9/bay-area-ai/ |
| `src-2988853df331` | P1 | train | 2025-09-26 | How to stop AI’s “lethal trifecta” | https://simonwillison.net/2025/Sep/26/how-to-stop-ais-lethal-trifecta/ |
| `src-3654442e318d` | P1 | train | 2025-08-11 | AI for data engineers with Simon Willison | https://simonwillison.net/2025/Aug/11/ai-for-data-engineers/ |
| `src-e7b93d5d58ac` | S1 | train | 2025-05-01 | Simon Willison on AI-assisted programming without the hype | https://newsletter.pragmaticengineer.com/p/simon-willison |
| `src-42b8bde2fb2a` | S1 | train | n.d. | Notes on Simon Willison’s Software Misadventures interview | https://mtlynch.io/notes/simon-willison/ |
| `src-7f9e2e216430` | S1 | train | 2025-08-01 | AI for data engineers with Simon Willison — Talking Postgres | https://talkingpostgres.com/episodes/ai-for-data-engineers-with-simon-willison |
| `src-78eca1896354` | S1 | train | 2025-09-01 | AI’s Security Crisis with Simon Willison | https://www.lastweekinaws.com/podcast/screaming-in-the-cloud/ais-security-crisis-with-simon-willison/ |
| `src-b5e1f1a473aa` | P1 | train | n.d. | Simon Willison on documentation | https://simonwillison.net/tags/documentation/ |
| `src-54513304c8fa` | P1 | train | n.d. | Simon Willison on GitHub: issues as a notebook | https://simonwillison.net/tags/github/?page=2 |
| `src-d219a1d4c117` | P1 | train | n.d. | Simon Willison on annotated release notes | https://simonwillison.net/tags/annotated-release-notes/ |
| `src-33bf86fe2c9c` | P1 | train | 2026-07-07 | sqlite-utils 4.0, now with database schema migrations | https://simonwillison.net/2026/Jul/7/sqlite-utils-4/ |
| `src-99d7b5b7bf18` | P1 | holdout | 2026-04-02 | Highlights from my conversation about agentic engineering on Lenny’s Podcast | https://simonwillison.net/2026/Apr/2/lennys-podcast/ |
| `src-876aaff9edb0` | P1 | holdout | 2026-07-21 | A Fireside Chat with Cat and Thariq from the Claude Code team | https://simonwillison.net/2026/Jul/21/cat-and-thariq/ |
| `src-5c93892c8c24` | P1 | holdout | 2026-07-22 | OpenAI’s accidental cyberattack against Hugging Face is science fiction that happened | https://simonwillison.net/2026/Jul/22/openai-cyberattack/ |
| `src-c49773cfd521` | S1 | holdout | 2025-08-01 | The Real Python Podcast: Simon Willison on Datasette and LLM tools | https://realpython.com/podcasts/rpp/249/ |
| `src-61231546d70e` | P1 | holdout | 2026-07-16 | Kimi K3, and what we can still learn from the pelican benchmark | https://simonwillison.net/2026/Jul/16/kimi-k3/ |
| `src-c745bfaf7415` | P1 | holdout | 2026-07-23 | The first known runaway AI agent — or a very bad marketing stunt | https://simonwillison.net/2026/Jul/23/the-first-known-runaway-ai-agent/ |
