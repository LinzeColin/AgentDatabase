# Persona Distiller quality report

- Target: `/mnt/data/PersonaDistiller-Final-v0.0.0.5/persona-distiller/workspaces/simon-willison`
- Phase: `release`
- Profile: `deep`
- Generated: `2026-07-24T00:55:36Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 79,
  "ledger_counts": {
    "sources": 60,
    "claims": 73
  },
  "sources_total": 60,
  "sources_train": 54,
  "sources_usable_train": 54,
  "sources_holdout": 6,
  "primary_sources": 50,
  "primary_ratio": 0.9259,
  "lane_source_counts": {
    "writings": 38,
    "conversations": 12,
    "expression": 27,
    "external": 9,
    "decisions": 37,
    "timeline": 25
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 73,
  "claims_active": 73,
  "mental_models": 8,
  "heuristics": 13,
  "claim_markers": 73,
  "eval_cases": 32,
  "eval_suite_counts": {
    "known": 2,
    "boundary": 2,
    "voice": 2,
    "trajectory": 2,
    "contrast": 2,
    "fact-preservation": 2,
    "style-decoy": 2,
    "task-completion": 2,
    "planning-fidelity": 2,
    "tool-use": 2,
    "capability-calibration": 2,
    "refusal-stop": 2,
    "long-horizon": 2,
    "identity-routing": 2,
    "anonymous-fidelity": 2,
    "token-efficiency": 2
  },
  "eval_results": 128,
  "candidate_overall": 0.9356,
  "baseline_overall": 0.6294,
  "candidate_baseline_delta": 0.3063,
  "suite_candidate_means": {
    "known": 0.9075,
    "boundary": 0.9575,
    "voice": 0.8975,
    "trajectory": 0.9175,
    "contrast": 0.9275,
    "fact-preservation": 0.9675,
    "style-decoy": 0.9475,
    "task-completion": 0.9375,
    "planning-fidelity": 0.9375,
    "tool-use": 0.9475,
    "capability-calibration": 0.9575,
    "refusal-stop": 0.9775,
    "long-horizon": 0.9175,
    "identity-routing": 0.9375,
    "anonymous-fidelity": 0.9275,
    "token-efficiency": 0.9075
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
