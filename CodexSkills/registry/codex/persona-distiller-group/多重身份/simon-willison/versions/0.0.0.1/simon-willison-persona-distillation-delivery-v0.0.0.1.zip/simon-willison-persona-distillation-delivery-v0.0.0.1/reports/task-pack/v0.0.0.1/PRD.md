# PRD v0.0.0.1 — Simon Willison Persona Skill Release and Maintenance

## 1. Objective

Deliver a deterministic, installable, evidence-grounded persona Skill that reproduces Simon Willison's documented engineering, teaching, open-source product and AI-safety decision patterns without impersonation or unsupported capability transfer.

## 2. Users

- Engineers reviewing code, architecture and coding-agent workflows.
- Researchers and educators explaining LLM engineering with executable examples.
- Open-source maintainers planning releases, documentation and feedback loops.
- Security teams threat-modeling prompt injection and high-permission agents.

## 3. In Scope

- Multi-identity routing across technical-engineer, thinker-educator, developer-designer and bounded entrepreneur-operator facets.
- Evidence ledger, Claim graph, six research lanes, Holdout evaluation and strict quality gate.
- Runtime router, unnumbered audit recorder, installers, boundaries and scenario adapters.
- Local canonical registration in `多重身份`.

## 4. Non-Goals

- Voice cloning, identity authentication, endorsements or private-memory simulation.
- Current opinions after 2026-07-24 without fresh verification.
- Investment-manager, legal, political, medical or certified security expert substitution.
- Claiming independent external evaluation where only static rubric audits exist.

## 5. Functional Requirements

FR-1: Route tasks automatically; never require user identity selection.  
FR-2: Load only the minimum identity and scenario files.  
FR-3: Engineering tasks must prioritize executable evidence: issue/spec, red/green TDD, full test, manual path, diff, docs/release.  
FR-4: High-permission agent tasks must evaluate private data + untrusted content + external communication and break at least one path.  
FR-5: Unverified code must be labeled unverified.  
FR-6: Investment and political/legal requests must route to general analysis only and disclose unavailable expertise.  
FR-7: Every active fact/model/heuristic/value/epistemic/expression/work-method/boundary Claim must render in a core artifact.  
FR-8: Packaging must produce exactly one outer release ZIP with checksums, reports, installers, registration metadata and handoff.

## 6. Quality and Safety Requirements

- Deep profile minimums: >=45 usable train sources, >=65% P1/P2, all six lanes, >=4 mental models, >=6 heuristics.
- 16 suites × >=2 cases, candidate >=0.80, delta >=0.07, boundary >=0.85, fact-preservation >=0.93.
- Strict release gate: zero errors and zero warnings.
- No source bodies, private material, secret patterns or Holdout leakage into train Claims.
- Product version `0.0.0.N` consumed only by successful registration.

## 7. Success Metrics

- 60 source records; 54 usable train, 6 Holdout; 92.59% primary ratio.
- 73 active Claims and 73 core markers.
- Candidate static audit 0.9356 vs baseline 0.6294; delta 0.3063.
- Clean install and router smoke in a fresh temporary root.
- Unique registration under `多重身份/simon-willison`.

## 8. Known Risks

- Public-writing selection bias.
- Static evaluation inflation because judges are serialized rubric audits, not independent blind models.
- Over-transfer of personal SQLite/CLI/open-source practices into regulated or large distributed organizations.
- Cognitive debt from fast AI-generated code.
- Staleness after the research cutoff.
