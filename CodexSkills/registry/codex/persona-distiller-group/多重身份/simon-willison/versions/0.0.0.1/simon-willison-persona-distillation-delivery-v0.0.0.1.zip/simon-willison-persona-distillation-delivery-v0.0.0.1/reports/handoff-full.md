# Handoff — Simon Willison Persona Distillation

## 当前状态

- 目标：将 Simon Willison 的公开工作模式蒸馏为证据约束、可自动路由、可安装的人物执行 Skill。
- 模型快照：1.0.0；预期产品发布：v0.0.0.1。
- 研究截止：2026-07-24。
- 状态：release-ready；严格质量门与 ledger strict validate 均通过。
- 注册目标：`persona-distiller-group/多重身份/simon-willison/`，只做本地 canonical registration；未推送远端仓库。

## 已完成

- 60 个来源：54 train + 6 Holdout；元数据与摘要策略，不再分发正文。
- 六路研究：writings / conversations / expression / external / decisions / timeline。
- 73 个 active Claim；73 个核心文档机器可读锚点。
- 四分面：技术工程师 ready、思想教育家 ready、开发设计家 ready、创业经营家 provisional。
- 两个 unavailable 分面：投资资本配置、政治法律。
- 16 套件 × 2 case = 32 case，128 条串行 rubric 审计记录。
- 工程、教学/安全、投资边界三类 runtime router smoke。
- PDF 主报告、证据索引、任务包、验证矩阵与目录清单。
- 18 页报告逐页视觉 QA、外层 checksum、全新安装与安装后 router 验证均通过。
- 隔离 registry 中完成 v0.0.0.1 注册、唯一性校验与 group validation；canonical 本地登记按最终封包 SHA 后置执行。

## 关键决策

1. 不做“口吻模仿”；模型优先编码注意分配、证据阈值、工作闭环、风险停止规则。
2. 采用多重身份，防止将创业经历、技术写作和安全分析压成单一工程师标签。
3. 以公开工作作为外部认知系统：issue、测试、文档、release notes、TIL、博客和演讲共同构成完成定义。
4. 对 AI 采取高采用 + 高警惕：执行交给 agent，责任与验收留给人；lethal trifecta 触发结构隔离。
5. 不启用心理/存在性假设；公开材料不足以支持私密动机或心理诊断。

## 未完成 / 明确限制

- 未运行真正独立、外部模型、盲化 judges；现有分数是两次串行静态 rubric 审计。
- 未获得 Simon Willison 本人授权或私域资料；本 Skill 不代表本人或实时观点。
- 未将任何本地登记推送到远程仓库；交付包也不声称远程发布。
- canonical registry receipt 不嵌入交付 ZIP：登记必须引用已封存 outer SHA，嵌回包内会造成自引用并改变该 SHA。
- 公开材料存在选择偏差；SQLite/CLI/个人开源模式迁移到强监管、大型组织或分布式系统时必须补治理层。
- 截止日后的事实、项目状态和观点需联网更新。

## 下一维护周期

1. 添加截止日后的第一方来源到 source universe，先决定 train/holdout，再更新 Claim。
2. 对受影响 Claim 做反证检查、时间范围更新和回归评测。
3. 引入至少两个相互独立、看不到评分基线的模型 judges；记录 prompt、版本和原始输出。
4. 对真实工程任务运行端到端工具执行评测，而不只验证路由计划。
5. 只有质量门、报告、安装 smoke 与注册验证全部通过后才发布 v0.0.0.2。

## 常用命令

```bash
python3 scripts/quality_check.py workspaces/simon-willison --phase release --strict --write-report
python3 scripts/ledger.py validate workspaces/simon-willison --strict
python3 workspaces/simon-willison/scripts/runtime_router.py plan --task "<task>"
python3 scripts/package_target.py workspaces/simon-willison --product-version 0.0.0.1 ...
python3 scripts/register_persona.py <delivery.zip>
python3 scripts/validate_persona_registry.py
```
