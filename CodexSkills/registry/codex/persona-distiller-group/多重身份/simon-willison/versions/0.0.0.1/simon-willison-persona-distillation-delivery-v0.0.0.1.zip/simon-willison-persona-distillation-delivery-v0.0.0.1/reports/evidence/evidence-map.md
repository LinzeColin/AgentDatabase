# Evidence Map

来源到 Claim 的反向索引，便于审计与更新影响分析。

## `src-99f266c01dde` — About Simon Willison

- Tier / split：P1 / train
- URL：https://simonwillison.net/about/
- Claim：clm-2838ec1b550a, clm-5a145db674ee, clm-bb608b034148, clm-cdacc6c2e1fe, clm-7404d7b4cff6, clm-179dc79eadcb, clm-97783b737444, clm-978a19489501, clm-a968682887bd, clm-b73c0fece70f, clm-4276aa2aeb94

## `src-61d170783e7a` — Simon Willison GitHub profile

- Tier / split：P1 / train
- URL：https://github.com/simonw
- Claim：clm-97783b737444

## `src-18329324cad5` — simonw/datasette

- Tier / split：P1 / train
- URL：https://github.com/simonw/datasette
- Claim：clm-2838ec1b550a, clm-5b5f611fc5a4, clm-53045b336fdb, clm-49298a064bc9

## `src-ef1ef80ff7d8` — Datasette project site

- Tier / split：P2 / train
- URL：https://datasette.io/
- Claim：Holdout / no train Claim linkage

## `src-72893923ffe6` — Datasette documentation

- Tier / split：P2 / train
- URL：https://docs.datasette.io/
- Claim：Holdout / no train Claim linkage

## `src-cb1d6305b23b` — simonw/llm

- Tier / split：P1 / train
- URL：https://github.com/simonw/llm
- Claim：clm-830e747b59a6, clm-963da9309ccb, clm-53045b336fdb, clm-3624c3e7114f, clm-8868ea96100a, clm-191e7e04d036, clm-81dd7add8934

## `src-b51c6efcf112` — LLM documentation

- Tier / split：P2 / train
- URL：https://llm.datasette.io/
- Claim：clm-830e747b59a6

## `src-59b537080884` — simonw/sqlite-utils

- Tier / split：P1 / train
- URL：https://github.com/simonw/sqlite-utils
- Claim：clm-710136fcf9f1, clm-963da9309ccb, clm-53045b336fdb, clm-8762f8c1870b, clm-88310d220ddd, clm-81dd7add8934

## `src-f2d96d4a6bfb` — simonw/til

- Tier / split：P1 / train
- URL：https://github.com/simonw/til
- Claim：clm-710136fcf9f1, clm-55177b1c1124, clm-e56fc489bbf0

## `src-531448add956` — simonw/simonwillisonblog

- Tier / split：P1 / train
- URL：https://github.com/simonw/simonwillisonblog
- Claim：clm-710136fcf9f1, clm-cf359ee33e8d

## `src-a293c526510b` — Simon Willison PyPI profile

- Tier / split：P2 / train
- URL：https://pypi.org/user/simonw/
- Claim：clm-cf359ee33e8d

## `src-8995c3c9b69e` — Happy 20th birthday Django! Here’s my talk on Django Origins from Django’s 10th

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Jul/13/django-birthday/
- Claim：clm-5a145db674ee, clm-e26a80ff452a, clm-5b5f611fc5a4

## `src-04b3348e95a2` — Django project website

- Tier / split：P2 / train
- URL：https://www.djangoproject.com/
- Claim：Holdout / no train Claim linkage

## `src-1a6aa4d6f9ac` — django/django

- Tier / split：P2 / train
- URL：https://github.com/django/django
- Claim：Holdout / no train Claim linkage

## `src-b222d373b60f` — Eventbrite acquires Lanyrd and Eventioz

- Tier / split：P2 / train
- URL：https://www.eventbrite.com/blog/press/press-releases/eventbrite-acquires-london-based-lanyrd-and-latin-american-events-company-eventioz/
- Claim：clm-bb608b034148, clm-b73c0fece70f

## `src-d0f1f9943a58` — Lanyrd — Y Combinator company profile

- Tier / split：P2 / train
- URL：https://www.ycombinator.com/companies/lanyrd
- Claim：clm-bb608b034148

## `src-61a64feb0c12` — Simon Willison — PyCon US 2024 speaker biography

- Tier / split：P2 / train
- URL：https://us.pycon.org/2024/speaker/profile/67/
- Claim：clm-7404d7b4cff6, clm-a968682887bd

## `src-a3bf9408e551` — Series: My open source process

- Tier / split：P1 / train
- URL：https://simonwillison.net/series/open-source-process/
- Claim：clm-7d2cc03288dc, clm-4276aa2aeb94

## `src-9c2c64898d16` — Documentation unit tests

- Tier / split：P1 / train
- URL：https://simonwillison.net/2018/Jul/28/documentation-unit-tests/
- Claim：Holdout / no train Claim linkage

## `src-51e28d2de70a` — Open source projects: consider running office hours

- Tier / split：P1 / train
- URL：https://simonwillison.net/2021/Feb/19/office-hours/
- Claim：clm-5b5f611fc5a4, clm-49298a064bc9

## `src-8b82039876b1` — How to build, test and publish an open source Python library

- Tier / split：P1 / train
- URL：https://simonwillison.net/2021/Nov/4/publish-open-source-python-library/
- Claim：clm-50af71253d1a, clm-8762f8c1870b, clm-191e7e04d036

## `src-804187dc3ddd` — How I build a feature

- Tier / split：P1 / train
- URL：https://simonwillison.net/2022/Jan/12/how-i-build-a-feature/
- Claim：clm-7d2cc03288dc, clm-cfd0892c28b4, clm-27029a645767, clm-71cdabc237d2, clm-55177b1c1124, clm-3624c3e7114f, clm-f7d17c320352, clm-1914fe345b34, clm-84259d58a6b1, clm-179dc79eadcb, clm-5f8b3c25f596, clm-1d76b103c2b6, clm-49298a064bc9

## `src-06bbab3e53fe` — Writing better release notes

- Tier / split：P1 / train
- URL：https://simonwillison.net/2022/Jan/31/release-notes/
- Claim：clm-cfd0892c28b4, clm-632325d5b940, clm-824083a701ea, clm-4bece286a497, clm-1d76b103c2b6, clm-aa5eaa61eaac

## `src-e7684f6206a6` — Software engineering practices

- Tier / split：P1 / train
- URL：https://simonwillison.net/2022/Oct/1/software-engineering-practices/
- Claim：clm-f6527cebddec, clm-03f154f72b7f, clm-88310d220ddd

## `src-5b03422dcb6e` — The Perfect Commit

- Tier / split：P1 / train
- URL：https://simonwillison.net/2022/Oct/29/the-perfect-commit/
- Claim：clm-4cb397b79d64, clm-71cdabc237d2, clm-f6527cebddec, clm-03f154f72b7f, clm-aa5eaa61eaac

## `src-1867dbecae87` — Coping strategies for the serial project hoarder

- Tier / split：P1 / train
- URL：https://simonwillison.net/2022/Nov/26/productivity/
- Claim：clm-4cb397b79d64, clm-50af71253d1a, clm-824083a701ea, clm-03f154f72b7f, clm-08000cca4717, clm-04a56b6791b7, clm-88310d220ddd

## `src-c7e8ca89e86c` — Financial sustainability for open source projects at GitHub Universe

- Tier / split：P1 / train
- URL：https://simonwillison.net/2023/Nov/10/universe/
- Claim：clm-085eb8b50132, clm-4d17462859aa, clm-1914fe345b34, clm-179dc79eadcb, clm-978a19489501

## `src-37f9e043eebc` — How I make annotated presentations

- Tier / split：P1 / train
- URL：https://simonwillison.net/2023/Aug/6/annotated-presentations/
- Claim：clm-cfd0892c28b4, clm-824083a701ea, clm-e56fc489bbf0, clm-ebc94b8e27b3, clm-b0fefdc8cb39

## `src-e2abb330a80b` — Building a self-updating profile README for GitHub

- Tier / split：P1 / train
- URL：https://simonwillison.net/2020/Jul/10/self-updating-profile-readme/
- Claim：clm-50af71253d1a, clm-e56fc489bbf0, clm-cf359ee33e8d

## `src-43113d5bfd4c` — Stuff we figured out about AI in 2023

- Tier / split：P1 / train
- URL：https://simonwillison.net/2023/Dec/31/ai-in-2023/
- Claim：clm-919793a95970, clm-8868ea96100a, clm-35df69cae038

## `src-ca63bf010417` — Embeddings: What they are and why they matter

- Tier / split：P1 / train
- URL：https://simonwillison.net/2023/Oct/23/embeddings/
- Claim：clm-ebc94b8e27b3

## `src-9b944f71fb8c` — Open questions for AI engineering

- Tier / split：P1 / train
- URL：https://simonwillison.net/2023/Oct/17/open-questions/
- Claim：clm-42c9e1f2d4c6, clm-963da9309ccb, clm-4bb95e849285, clm-919793a95970, clm-5f1e9b302cb8, clm-0813b84e4ef8, clm-08000cca4717, clm-35df69cae038, clm-84259d58a6b1, clm-3b04659c1221

## `src-1b4e08e2d1a2` — Here’s how I use LLMs to help me write code

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Mar/11/using-llms-for-code/
- Claim：clm-42c9e1f2d4c6, clm-ae4b141f7208, clm-34429170fb9c, clm-919793a95970, clm-5f1e9b302cb8, clm-f7d17c320352, clm-1914fe345b34, clm-22d437a55215, clm-76f603bb248e, clm-68534f1c3db4

## `src-99f1fbf204cd` — Vibe engineering

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Oct/7/vibe-engineering/
- Claim：clm-ae4b141f7208, clm-04dec1a4d602, clm-22d437a55215, clm-76f603bb248e, clm-68534f1c3db4, clm-5ad875505c00

## `src-f63c45e2340f` — Setting up a codebase for working with coding agents

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Oct/25/coding-agent-tips/
- Claim：clm-04dec1a4d602, clm-6f5ed1f8f57e, clm-5f8b3c25f596, clm-8762f8c1870b, clm-76f603bb248e, clm-04a56b6791b7, clm-5ad875505c00

## `src-3e30f503c310` — Writing about Agentic Engineering Patterns

- Tier / split：P1 / train
- URL：https://simonwillison.net/2026/Feb/23/agentic-engineering-patterns/
- Claim：clm-d8cab19ee846, clm-cdacc6c2e1fe

## `src-4ca53aebc1e9` — Introducing Showboat and Rodney, so agents can demo what they have built

- Tier / split：P1 / train
- URL：https://simonwillison.net/2026/Feb/10/showboat-and-rodney/
- Claim：clm-ae4b141f7208, clm-294e4384f004, clm-6f5ed1f8f57e, clm-3624c3e7114f, clm-e0f1d52f8a49, clm-191e7e04d036, clm-5ad875505c00

## `src-bbbe99b44830` — Simon Willison on testing

- Tier / split：P1 / train
- URL：https://simonwillison.net/tags/testing/
- Claim：clm-d8cab19ee846, clm-294e4384f004, clm-e0f1d52f8a49

## `src-1025c18f627b` — Simon Willison on projects

- Tier / split：P1 / train
- URL：https://simonwillison.net/tags/projects/
- Claim：clm-8868ea96100a

## `src-adc443cc7785` — Release: llm-coding-agent 0.1a0

- Tier / split：P1 / train
- URL：https://simonwillison.net/2026/jul/2/llm-coding-agent/
- Claim：clm-d8cab19ee846, clm-294e4384f004, clm-e0f1d52f8a49

## `src-01cc57b5543e` — My fireside chat about agentic engineering at the Pragmatic Summit

- Tier / split：P1 / train
- URL：https://simonwillison.net/2026/Mar/14/pragmatic-summit/
- Claim：clm-b0fefdc8cb39

## `src-f031d84d7b27` — The lethal trifecta for AI agents: private data, untrusted content, and external communication

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/
- Claim：clm-cef19f21d198, clm-84d05aa0e9c3, clm-36920b8a9709, clm-070af56101b2, clm-3b04659c1221, clm-68534f1c3db4

## `src-cb528177b47e` — Series: Prompt injection

- Tier / split：P1 / train
- URL：https://simonwillison.net/series/prompt-injection/
- Claim：clm-cef19f21d198, clm-0813b84e4ef8, clm-db52e742ee81

## `src-587283b625c7` — My Lethal Trifecta talk at the Bay Area AI Security Meetup

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Aug/9/bay-area-ai/
- Claim：clm-84d05aa0e9c3, clm-ebc94b8e27b3, clm-b0fefdc8cb39, clm-08000cca4717

## `src-2988853df331` — How to stop AI’s “lethal trifecta”

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Sep/26/how-to-stop-ais-lethal-trifecta/
- Claim：clm-84d05aa0e9c3, clm-36920b8a9709, clm-4bb95e849285, clm-070af56101b2, clm-db52e742ee81

## `src-3654442e318d` — AI for data engineers with Simon Willison

- Tier / split：P1 / train
- URL：https://simonwillison.net/2025/Aug/11/ai-for-data-engineers/
- Claim：Holdout / no train Claim linkage

## `src-e7b93d5d58ac` — Simon Willison on AI-assisted programming without the hype

- Tier / split：S1 / train
- URL：https://newsletter.pragmaticengineer.com/p/simon-willison
- Claim：clm-34429170fb9c, clm-22d437a55215

## `src-42b8bde2fb2a` — Notes on Simon Willison’s Software Misadventures interview

- Tier / split：S1 / train
- URL：https://mtlynch.io/notes/simon-willison/
- Claim：clm-4d17462859aa, clm-81dd7add8934

## `src-7f9e2e216430` — AI for data engineers with Simon Willison — Talking Postgres

- Tier / split：S1 / train
- URL：https://talkingpostgres.com/episodes/ai-for-data-engineers-with-simon-willison
- Claim：Holdout / no train Claim linkage

## `src-78eca1896354` — AI’s Security Crisis with Simon Willison

- Tier / split：S1 / train
- URL：https://www.lastweekinaws.com/podcast/screaming-in-the-cloud/ais-security-crisis-with-simon-willison/
- Claim：clm-070af56101b2

## `src-b5e1f1a473aa` — Simon Willison on documentation

- Tier / split：P1 / train
- URL：https://simonwillison.net/tags/documentation/
- Claim：clm-04a56b6791b7

## `src-54513304c8fa` — Simon Willison on GitHub: issues as a notebook

- Tier / split：P1 / train
- URL：https://simonwillison.net/tags/github/?page=2
- Claim：clm-4cb397b79d64, clm-27029a645767, clm-aa5eaa61eaac

## `src-d219a1d4c117` — Simon Willison on annotated release notes

- Tier / split：P1 / train
- URL：https://simonwillison.net/tags/annotated-release-notes/
- Claim：clm-7d2cc03288dc, clm-632325d5b940, clm-6f5ed1f8f57e, clm-4bece286a497, clm-1d76b103c2b6

## `src-33bf86fe2c9c` — sqlite-utils 4.0, now with database schema migrations

- Tier / split：P1 / train
- URL：https://simonwillison.net/2026/Jul/7/sqlite-utils-4/
- Claim：Holdout / no train Claim linkage

## `src-99d7b5b7bf18` — Highlights from my conversation about agentic engineering on Lenny’s Podcast

- Tier / split：P1 / holdout
- URL：https://simonwillison.net/2026/Apr/2/lennys-podcast/
- Claim：Holdout / no train Claim linkage

## `src-876aaff9edb0` — A Fireside Chat with Cat and Thariq from the Claude Code team

- Tier / split：P1 / holdout
- URL：https://simonwillison.net/2026/Jul/21/cat-and-thariq/
- Claim：Holdout / no train Claim linkage

## `src-5c93892c8c24` — OpenAI’s accidental cyberattack against Hugging Face is science fiction that happened

- Tier / split：P1 / holdout
- URL：https://simonwillison.net/2026/Jul/22/openai-cyberattack/
- Claim：Holdout / no train Claim linkage

## `src-c49773cfd521` — The Real Python Podcast: Simon Willison on Datasette and LLM tools

- Tier / split：S1 / holdout
- URL：https://realpython.com/podcasts/rpp/249/
- Claim：Holdout / no train Claim linkage

## `src-61231546d70e` — Kimi K3, and what we can still learn from the pelican benchmark

- Tier / split：P1 / holdout
- URL：https://simonwillison.net/2026/Jul/16/kimi-k3/
- Claim：Holdout / no train Claim linkage

## `src-c745bfaf7415` — The first known runaway AI agent — or a very bad marketing stunt

- Tier / split：P1 / holdout
- URL：https://simonwillison.net/2026/Jul/23/the-first-known-runaway-ai-agent/
- Claim：Holdout / no train Claim linkage
