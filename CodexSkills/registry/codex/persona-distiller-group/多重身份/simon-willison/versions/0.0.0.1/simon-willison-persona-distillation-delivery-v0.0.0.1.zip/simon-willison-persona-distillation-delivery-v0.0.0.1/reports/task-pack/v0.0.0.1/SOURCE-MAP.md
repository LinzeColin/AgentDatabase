# SOURCE-MAP v0.0.0.1

## Evidence Priorities

1. First-party official bio, weblog, project repositories, documentation and release artifacts.
2. Institutional records for career/company facts (Django, YC, Eventbrite, conference bios).
3. External interviews only for cross-context pressure testing.
4. Six reserved Holdout sources excluded from Claim synthesis.

## Core Mechanism Source Clusters

- Engineering loop: `How I build a feature`, `The Perfect Commit`, `Writing better release notes`, `Software engineering practices`, open-source process series.
- External memory and public work: project-hoarder essay, TIL repository, annotated presentations, documentation and releases.
- Concrete-pressure abstraction: Django Origins, Datasette repositories/documentation, user office hours.
- LLM coding: 2025 LLM coding guide, vibe engineering, coding-agent setup, 2026 Agentic Engineering Patterns, Showboat/Rodney.
- AI safety: prompt-injection series, lethal trifecta, mitigation essay, talks and interviews.
- Career facts: official about page, Django project, YC Lanyrd page and Eventbrite acquisition record.

## Holdout Isolation

Holdout IDs: `src-99d7b5b7bf18`, `src-876aaff9edb0`, `src-5c93892c8c24`, `src-c49773cfd521`, `src-61231546d70e`, `src-c745bfaf7415`.
These sources are referenced only by evaluation fixtures, not train Claims.
