# TASKS v0.0.0.1

## Release Tasks

- [x] Initialize deep public-subject workspace with multi-identity weights.
- [x] Build source universe and classify P1/P2/S1, train/Holdout and six lanes.
- [x] Synthesize facts, mental models, heuristics, values, epistemics, expression, work methods, boundaries and blind spots.
- [x] Add source independence, contexts, falsifiers and time scope to pattern Claims.
- [x] Render all 73 active Claims into core artifacts with machine-readable markers.
- [x] Populate identity facets, scenario adapters, route manifest and team card.
- [x] Create 32 cases across all 16 suites and 128 serialized rubric audit records.
- [x] Pass strict release gate and strict ledger validation.
- [x] Run runtime router smoke for engineering, teaching/security and investment boundary.
- [x] Build and verify the single-archive release candidate; record outer/runtime SHA-256.
- [x] Rebuild from identical inputs and verify deterministic byte identity.
- [x] Run fresh-install smoke from the packaged runtime and verify post-install routing.
- [x] Register in an isolated registry copy and validate category/version uniqueness plus idempotent re-registration.
- [x] Freeze the canonical sequence: seal final outer SHA first, then register that exact artifact locally; keep the receipt outside the archive to avoid a self-referential hash.

## v0.0.0.2 Maintenance Backlog

- [ ] Add sources after 2026-07-24 with explicit freshness and split decisions.
- [ ] Run two or more independent external blind judges and preserve raw outputs.
- [ ] Add end-to-end task execution fixtures with real repositories and tool transcripts.
- [ ] Add adversarial tests for false current-opinion claims, imitation pressure and hidden high-risk transfer.
- [ ] Test migration guidance for regulated, distributed and multi-team contexts.
- [ ] Add calibration plots and bootstrap uncertainty for evaluation scores.
