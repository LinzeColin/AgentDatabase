# ACCEPTANCE v0.0.0.1

## Mandatory Acceptance Criteria

1. `quality_check.py ... --strict` exits 0 with `passed=true`, no errors, no warnings.
2. `ledger.py validate ... --strict` exits 0.
3. Sources: 60 total, 54 train, 6 Holdout; usable train >=45; primary ratio >=0.65; six lanes covered.
4. Claims: 73 active, 73 rendered markers; no Holdout source referenced by train Claim.
5. Models: >=4 mental models and >=6 heuristics; actual 8 and 13.
6. Evaluation: 16 suites, 2 cases each, 32 total; candidate >=0.80; delta >=0.07; boundary >=0.85; fact preservation >=0.93.
7. Security: zero detected secret patterns; no private/source bodies in release payload.
8. Routing: engineering chooses technical-engineer; teaching/security adds thinker-educator; investment loads boundary adapter and does not confer investor expertise.
9. Package: exactly one outer ZIP, deterministic manifests/checksums, installer scripts, runtime ZIP, reports and `handoff.md`.
10. Install: fresh temporary root verifies checksums, installs successfully, and router returns valid JSON.
11. Registry: exactly one canonical entry at `多重身份/simon-willison`, product version `0.0.0.1`, group validation passes.
12. Reporting: PDF visually reviewed page-by-page; no clipping, overlap, missing glyphs or broken tables.

## Truthfulness Acceptance

- Report must state that evaluations are static serialized rubric audits, not independent external blind judges.
- Report must state that the Skill is not Simon Willison, not authorized, and not a source of post-cutoff current views.
- Report must distinguish ready, provisional and unavailable facets.
