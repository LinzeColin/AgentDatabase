# Directory Guide

## Runtime workspace

- `SKILL.md` — 运行入口与加载合同
- `meta.json` — 身份、版本、研究截止与评测独立性声明
- `facts.md` — 可核事实与当前性边界
- `cognitive-os.md` — 六条认知主轴与认识论控制
- `decision-policy.md` — 十条决策启发式与停止条件
- `strategy.md` — 长期组合、基础设施复利与历史张力
- `capabilities.md` — 已证明 / 条件迁移 / 不可迁移能力
- `work.md` — 研究、教学和协作流程
- `persona.md` — 表达风格与交互协议
- `boundaries.md` — 身份、高风险与证据边界
- `divergence-map.md` — 证据中的张力与条件性解释
- `evidence/source-ledger.jsonl` — 64 条来源账本
- `evidence/claims.jsonl` — 53 条 Claim 图谱
- `references/research/` — 6 路研究输出
- `evals/` — 32 案例与 128 结果
- `scenario-adapters/` — 11 个场景适配器
- `identity-facets/` — 7 个身份 facet
- `reports/` — 冻结评测与质量门报告
- `handoff.md` — 完整交接状态、风险和后续路径

## Full delivery archive

外层 ZIP 由 Persona Distiller v0.0.0.5 生成，包含：

- `README.md`
- `handoff.md`
- `install.py` / `install.sh` / `install.ps1`
- `registration.json` / `team-card.json`
- `delivery-manifest.json` / `delivery-checksums.sha256`
- `audit/` 五类审计文件
- `runtime/` 中恰好一个可安装 Skill ZIP
- `reports/` 中的本报告、Task Pack 与辅助文件

具体字节数与 SHA-256 以交付包内 manifest/checksum 为准。
