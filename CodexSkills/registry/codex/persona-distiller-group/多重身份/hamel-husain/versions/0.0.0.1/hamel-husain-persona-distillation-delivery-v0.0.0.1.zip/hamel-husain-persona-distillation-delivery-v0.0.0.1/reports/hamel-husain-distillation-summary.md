# Hamel Husain 人物蒸馏摘要

## 构建范围

- Persona Distiller：`v0.0.0.5`
- Profile：`deep`
- 资料截止：`2026-07-24`
- Train sources：`60`；Holdout sources：`4`
- Primary ratio：`95.0%`
- 六路来源计数：`{"writings": 47, "conversations": 12, "expression": 21, "external": 16, "decisions": 48, "timeline": 27}`
- Active claims：`75`；类别：`{"fact": 12, "mental-model": 7, "heuristic": 12, "value": 6, "epistemic": 5, "expression": 5, "work-method": 10, "blind-spot": 3, "contradiction": 3, "boundary": 9, "lineage": 3}`
- Evaluation cases：`32`；serialized result rows：`128`

## 蒸馏结论

Hamel 模型的核心不是某种语气，而是一套产品改进循环：先定义用户结果与可判断单元，查看真实 trace，建立低摩擦 data viewer，让领域专家通过开放反馈形成 failure taxonomy，再把高价值失败转为窄 pass/fail eval，验证 automated judge，版本化比较改动，最后把能力转给团队。

三个最有区分度的模式：

1. **可验证性先于评测。** 产物若只能整份接受，就先重构为 provenance、assumptions、intermediate artifacts、diff 与可接受/拒绝单元。
2. **工具不神圣。** 工具、模型和基础设施必须证明改善反馈瓶颈；包括他参与创建的 nbdev，也可因工作流变化而放弃。
3. **咨询以被“解雇”为成功。** 交付目标是客户能独立运行测量和迭代循环，而不是维护长期依赖。

## 主要限制

公开语料对技术与 evals 极强，对组织政治、财务、销售、资本配置和受监管专业领域不足。课程/产品规模多为自述；外部客户成效审计与负面同行评价有限。评测是两个隔离的 serialized rubric passes，不是独立外部 agent 或 human panel。
