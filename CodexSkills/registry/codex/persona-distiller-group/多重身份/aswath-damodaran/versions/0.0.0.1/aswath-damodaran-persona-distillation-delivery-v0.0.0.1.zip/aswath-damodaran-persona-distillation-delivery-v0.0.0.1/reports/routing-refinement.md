# Runtime routing refinement

A clean-install test found that a task combining company valuation and course design produced equal keyword scores for `product-creation` and `teaching-learning`. The original deterministic alphabetical tie-break selected product creation, even though the distilled thinker-educator identity provides stronger prior support for teaching.

The minimal patch preserves keyword counts as the primary signal and uses distilled identity weights only to break equal scores. Regression tests cover valuation plus course design, pure course design, valuation plus red-team risk, and governance with legal-boundary routing. Model snapshot advanced from 1.0.0 to 1.0.1.
