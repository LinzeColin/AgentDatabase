# Persona Distiller quality report

- Target: `/mnt/data/aswath_damodaran_build/aswath-damodaran`
- Phase: `release`
- Profile: `deep`
- Generated: `2026-07-23T21:39:10Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 67,
  "ledger_counts": {
    "sources": 74,
    "claims": 64
  },
  "sources_total": 74,
  "sources_train": 66,
  "sources_usable_train": 66,
  "sources_holdout": 8,
  "primary_sources": 59,
  "primary_ratio": 0.8939,
  "lane_source_counts": {
    "writings": 49,
    "conversations": 6,
    "expression": 28,
    "external": 12,
    "decisions": 44,
    "timeline": 20
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 64,
  "claims_active": 64,
  "mental_models": 9,
  "heuristics": 15,
  "claim_markers": 64,
  "eval_cases": 32,
  "eval_suite_counts": {
    "known": 2,
    "boundary": 2,
    "voice": 2,
    "trajectory": 2,
    "contrast": 2,
    "fact-preservation": 2,
    "style-decoy": 2,
    "task-completion": 2,
    "planning-fidelity": 2,
    "tool-use": 2,
    "capability-calibration": 2,
    "refusal-stop": 2,
    "long-horizon": 2,
    "identity-routing": 2,
    "anonymous-fidelity": 2,
    "token-efficiency": 2
  },
  "eval_results": 128,
  "candidate_overall": 0.9575,
  "baseline_overall": 0.725,
  "candidate_baseline_delta": 0.2325,
  "suite_candidate_means": {
    "known": 0.94,
    "boundary": 0.985,
    "voice": 0.93,
    "trajectory": 0.95,
    "contrast": 0.95,
    "fact-preservation": 0.985,
    "style-decoy": 0.98,
    "task-completion": 0.95,
    "planning-fidelity": 0.95,
    "tool-use": 0.97,
    "capability-calibration": 0.985,
    "refusal-stop": 0.985,
    "long-horizon": 0.93,
    "identity-routing": 0.97,
    "anonymous-fidelity": 0.94,
    "token-efficiency": 0.92
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
