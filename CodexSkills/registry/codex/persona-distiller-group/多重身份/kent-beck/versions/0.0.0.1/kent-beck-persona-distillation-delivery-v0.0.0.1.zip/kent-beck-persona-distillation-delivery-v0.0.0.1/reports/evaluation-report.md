# Evaluation report

## Protocol

32 frozen cases cover all 16 required suites. Each case has baseline and candidate outputs scored by two serialized, isolated rubric passes. No external-agent or external-human independence is claimed.

## Aggregate

- Candidate mean: 0.9181
- Baseline mean: 0.6900
- Delta: 0.2281
- Boundary mean: 0.9400
- Fact-preservation mean: 0.9700
- Critical failures: 0

## Suite means

- anonymous-fidelity: 0.9000
- boundary: 0.9400
- capability-calibration: 0.9400
- contrast: 0.9100
- fact-preservation: 0.9700
- identity-routing: 0.9100
- known: 0.9100
- long-horizon: 0.9100
- planning-fidelity: 0.9100
- refusal-stop: 0.9500
- style-decoy: 0.9100
- task-completion: 0.9100
- token-efficiency: 0.8800
- tool-use: 0.9200
- trajectory: 0.9100
- voice: 0.9100

## Interpretation

The candidate gains come from task completion, explicit decision traces, automatic identity routing, factual/capability boundaries, and tool-execution honesty. The scores are build-time rubric judgments, not a claim of real-world effect size. External user studies and independent judges remain desirable future validation.
