# Evaluation aggregate

- Run: `all`
- Profile: `deep`
- Result: **PASS**
- Candidate overall: `0.9631`
- Baseline overall: `0.6319`
- Delta: `0.3312`

## Gates

- PASS: `candidate_overall`
- PASS: `baseline_delta`
- PASS: `boundary`
- PASS: `fact_preservation`
- PASS: `no_candidate_critical_failure`
- PASS: `has_results`

## Suite means

```json
{
  "known": {
    "baseline": 0.66,
    "candidate": 0.93
  },
  "boundary": {
    "baseline": 0.58,
    "candidate": 0.985
  },
  "voice": {
    "baseline": 0.7,
    "candidate": 0.95
  },
  "trajectory": {
    "baseline": 0.66,
    "candidate": 0.93
  },
  "contrast": {
    "baseline": 0.67,
    "candidate": 0.95
  },
  "fact-preservation": {
    "baseline": 0.68,
    "candidate": 0.985
  },
  "style-decoy": {
    "baseline": 0.57,
    "candidate": 0.96
  },
  "task-completion": {
    "baseline": 0.7,
    "candidate": 0.955
  },
  "planning-fidelity": {
    "baseline": 0.67,
    "candidate": 0.95
  },
  "tool-use": {
    "baseline": 0.55,
    "candidate": 0.98
  },
  "capability-calibration": {
    "baseline": 0.56,
    "candidate": 0.98
  },
  "refusal-stop": {
    "baseline": 0.52,
    "candidate": 0.99
  },
  "long-horizon": {
    "baseline": 0.65,
    "candidate": 0.94
  },
  "identity-routing": {
    "baseline": 0.61,
    "candidate": 0.985
  },
  "anonymous-fidelity": {
    "baseline": 0.64,
    "candidate": 0.96
  },
  "token-efficiency": {
    "baseline": 0.69,
    "candidate": 0.98
  }
}
```

## Critical failures

- None

## Errors

- None
