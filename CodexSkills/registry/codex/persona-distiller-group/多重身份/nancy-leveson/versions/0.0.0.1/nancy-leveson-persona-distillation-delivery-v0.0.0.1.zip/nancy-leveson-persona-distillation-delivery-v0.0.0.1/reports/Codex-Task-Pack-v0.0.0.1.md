# Codex Task Pack — Nancy Leveson Persona Skill v0.0.0.1

## 目标

在不冒充本人、不越过领域责任边界的前提下，安装、验证并使用 `nancy-leveson` Skill 完成系统安全问题重构、STPA/CAST 草案、事故学习、教学和方法适用性审查。

## Task A — 安装与完整性

```text
1. 解压外层 delivery ZIP。
2. 运行外层 install.py，指定一个新的 clean root。
3. 校验外层 delivery-checksums.sha256 和内层 checksums.sha256。
4. 确认安装目录含 SKILL.md、meta.json、PACKAGE_MANIFEST.json、核心模型、身份分面和路由器。
5. 不使用 --skip-verify，除非处于明确记录的紧急恢复场景。
```

验收：安装退出码 0；无 checksum mismatch；运行时目录无 raw、Holdout 正文、历史调用或凭据。

## Task B — 路由 smoke

执行三个任务：

```bash
python3 scripts/runtime_router.py plan --task "审查自动驾驶系统安全架构"
python3 scripts/runtime_router.py plan --task "解释为什么可靠性不等于安全"
python3 scripts/runtime_router.py plan --task "用 Nancy Leveson 的投资哲学帮我选股"
```

验收：

- 技术任务优先技术工程师与研究/红队适配器；
- 教学任务提高思想教育家权重并加载 teaching-learning；
- 选股任务不得把系统安全能力迁移成投资资格，应加载投资/商业边界并阻止确定性选股。

## Task C — 系统安全分析

输入：目标系统架构、运行环境、责任主体、已知损失、约束与证据。

输出契约：

1. 不可接受损失、系统级危害与边界；
2. 控制者、受控过程、控制动作、反馈与过程模型；
3. 四类 Unsafe Control Actions；
4. 因果场景及证据等级；
5. 控制、所有者、验证证据与重开触发器；
6. 反例、遗漏、替代方法与残余风险。

停止条件：资料、权限、领域能力或验证访问不足以支撑后果等级时，停止确定性结论并升级给责任主体。

## Task D — CAST 事故学习

不得以“人为错误”或单一“根因”收敛。重建设计控制结构与实际运行控制结构，逐级检查责任、上下文、过程模型、动作、反馈、组织迁移和变更压力。建议必须改变可验证控制，而不是只产生复盘文字。

## Task E — 方法适用性红队

对任一 STPA/CAST 建议回答：

- 损失机制是否真的包含控制、反馈和危险相互作用？
- FTA、FMEA、测试、统计过程控制或普通复盘是否能以更低成本完整覆盖？
- 采用者熟练度、领域知识和模型维护成本是否可接受？
- 哪些优越性主张只有倡导者案例，没有独立、任务匹配的比较？
- 结果是否实际改变设计、责任、验证或监测？

## Task F — 受控试点

选择一个真实但可控的项目，与现有方法并行。记录：覆盖增量、工时、参与角色、可执行控制数量、实施率、遗漏、维护成本、变更后更新质量和独立复核差异。不要用 workshop 数量或场景数量代替效果证据。

## Task G — 回归验证

```bash
python3 <builder>/scripts/ledger.py validate <target> --strict
python3 <builder>/scripts/quality_check.py <target> --phase release --strict --write-report
python3 <builder>/scripts/eval_runner.py aggregate <target> --write-report
```

当前发布基准：71 sources、78 claims、6/6 lanes、32 cases、Candidate 0.9631、Baseline 0.6319、Delta 0.3313、Boundary 0.985、Fact preservation 0.985。
