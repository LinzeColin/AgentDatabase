# Persona Distiller quality report

- Target: `/mnt/data/nancy-leveson-build/nancy-leveson`
- Phase: `release`
- Profile: `deep`
- Generated: `2026-07-24T08:03:49Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 72,
  "ledger_counts": {
    "sources": 71,
    "claims": 78
  },
  "sources_total": 71,
  "sources_train": 65,
  "sources_usable_train": 65,
  "sources_holdout": 6,
  "primary_sources": 58,
  "primary_ratio": 0.8923,
  "lane_source_counts": {
    "writings": 50,
    "conversations": 7,
    "expression": 21,
    "external": 22,
    "decisions": 48,
    "timeline": 19
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 78,
  "claims_active": 78,
  "mental_models": 10,
  "heuristics": 15,
  "claim_markers": 78,
  "eval_cases": 32,
  "eval_suite_counts": {
    "known": 2,
    "boundary": 2,
    "voice": 2,
    "trajectory": 2,
    "contrast": 2,
    "fact-preservation": 2,
    "style-decoy": 2,
    "task-completion": 2,
    "planning-fidelity": 2,
    "tool-use": 2,
    "capability-calibration": 2,
    "refusal-stop": 2,
    "long-horizon": 2,
    "identity-routing": 2,
    "anonymous-fidelity": 2,
    "token-efficiency": 2
  },
  "eval_results": 128,
  "candidate_overall": 0.9631,
  "baseline_overall": 0.6319,
  "candidate_baseline_delta": 0.3313,
  "suite_candidate_means": {
    "known": 0.93,
    "boundary": 0.985,
    "voice": 0.95,
    "trajectory": 0.93,
    "contrast": 0.95,
    "fact-preservation": 0.985,
    "style-decoy": 0.96,
    "task-completion": 0.955,
    "planning-fidelity": 0.95,
    "tool-use": 0.98,
    "capability-calibration": 0.98,
    "refusal-stop": 0.99,
    "long-horizon": 0.94,
    "identity-routing": 0.985,
    "anonymous-fidelity": 0.96,
    "token-efficiency": 0.98
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
