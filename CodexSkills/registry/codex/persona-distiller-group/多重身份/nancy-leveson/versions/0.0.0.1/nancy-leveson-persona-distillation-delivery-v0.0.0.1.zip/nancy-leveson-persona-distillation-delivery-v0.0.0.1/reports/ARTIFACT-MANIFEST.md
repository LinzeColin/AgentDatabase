# Artifact Manifest — Nancy Leveson Persona Distillation v0.0.0.1

## 外层交付

- 单一版本化 delivery ZIP
- 一个顶层目录
- `runtime/` 中恰好一个可安装 runtime ZIP
- `reports/` 中含 PDF、Markdown、handoff、质量、评测、Task Pack 与范围披露
- `audit/` 中含 verification、provenance、source coverage、evaluation summary、review record
- 外层与内层 checksum manifest
- registration 与 team card

## 运行时核心

- `SKILL.md`, `README.md`, `meta.json`
- `facts.md`, `cognitive-os.md`, `decision-policy.md`, `strategy.md`, `capabilities.md`, `work.md`, `persona.md`, `boundaries.md`, `divergence-map.md`
- 7 个 identity facets；11 个 scenario adapters
- 自动路由器、运行记录器、安装器
- source ledger、claim ledger、coverage map、saturation report
- 32 cases、128 results、32 frozen transcripts

## 固定人读报告

- `Nancy-Leveson-Persona-Distillation-Report-v0.0.0.1.pdf`
- `Nancy-Leveson-Persona-Distillation-Report.md`
- `handoff.md` / `handoff-full.md`
- `quality-release.md` / `quality-release.json`
- `evaluation-method.md`, `evaluation-transcripts.md`, `eval-all.md`, `eval-all.json`
- `Codex-Task-Pack-v0.0.0.1.md`
- `GITHUB-VERIFICATION-SCOPE.md`
- `runtime-smoke.md` / `runtime-smoke.json`
- `final-verification.md` / `final-verification.json`
