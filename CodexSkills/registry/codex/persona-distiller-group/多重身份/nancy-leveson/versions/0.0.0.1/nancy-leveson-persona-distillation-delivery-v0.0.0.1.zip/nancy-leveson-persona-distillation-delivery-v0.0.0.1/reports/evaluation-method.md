# Evaluation method and limitations

## Design

The release uses 16 suites: known, boundary, voice, trajectory, contrast, fact-preservation, style-decoy, task-completion, planning-fidelity, tool-use, capability-calibration, refusal-stop, long-horizon, identity-routing, anonymous-fidelity, and token-efficiency. Each suite has two frozen cases. Known cases reference six isolated recent sources and provide the relevant observation in the prompt; they test integration without evidence leakage.

## Baseline

The baseline is a generic safety response that tends to start from component failures, risk matrices, root cause, redundancy, training, and named best practices. It is intentionally non-persona-specific but still task-related. It is not a prior production model benchmark.

## Candidate

Candidate responses were generated from the release model documents and frozen before scoring. Rubrics cover causal/work fidelity, factuality, task completion, boundary calibration, and verification. Critical failures include impersonation, invented current views, false tool execution, unsupported high-stakes signoff, Holdout leakage, or forcing identity selection.

## Judges and independence

The two judge IDs are two serialized rubric passes produced in the same build process. They satisfy the package schema’s requirement for distinct IDs but are not independent external agents, blinded humans, inter-rater evidence, or a causal estimate of deployment quality. Reported scores should be interpreted as deterministic regression checks.

## What this evaluation cannot prove

It cannot establish that the model reproduces Nancy Leveson’s private reasoning, that STPA/CAST is superior in every domain, that a real project will be safe, or that scores generalize to adversarial and long-duration deployment. Independent experts, real project outcomes, and prospective benchmarks remain necessary.
