# GitHub Verification Scope — LinzeColin

研究日期：2026-07-24。

已通过可访问的 GitHub Web 页面核对以下七个公开仓库根目录与可见项目索引：

1. MetaDatabase
2. AgentDatabase
3. KMOS
4. NotionStudyProject
5. Archive
6. CodexProject
7. LinzeHomeHub

容器内 `git ls-remote` 因 DNS 无法解析 `github.com`，未能递归克隆。因此，本轮不声称已穷尽所有历史 commit、分支、tag、子模块、Git LFS、私有仓库、已删除内容或 Web 界面未暴露的文件。

该范围披露遵循 verification-first：可见部分标记为已核对，不可达部分标记为未知，而不是推定完成。
