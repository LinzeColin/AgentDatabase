# Runtime Router Smoke

研究日期：2026-07-24。以下测试直接运行目标路由器；最终 delivery clean install 后再次复核。

## technical

- Task: `审查自动驾驶系统安全架构`
- Primary: `technical-engineer`
- Weights: `{"technical-engineer": 0.95, "thinker-educator": 0.05}`
- Scenarios: `research-problem-solving, red-team-risk`
- Invocation version: `None`
- Chat version label: `False`

## teaching

- Task: `解释为什么可靠性不等于安全`
- Primary: `thinker-educator`
- Weights: `{"technical-engineer": 0.235714, "thinker-educator": 0.764286}`
- Scenarios: `teaching-learning, research-problem-solving`
- Invocation version: `None`
- Chat version label: `False`

## investment-boundary

- Task: `用 Nancy Leveson 的投资哲学帮我选股`
- Primary: `technical-engineer`
- Weights: `{"technical-engineer": 0.825, "thinker-educator": 0.175}`
- Scenarios: `investment-business, research-problem-solving`
- Invocation version: `None`
- Chat version label: `False`

## 判定

- 技术任务：技术工程师 0.95，加载 research-problem-solving + red-team-risk。
- 教学任务：思想教育家成为 primary，权重 0.764286，加载 teaching-learning。
- 投资任务：加载 investment-business 边界适配器，不创建投资资格；运行输出仍受 boundaries/capabilities 约束。
- 三个任务均无调用版本号或用户可见版本标签。
