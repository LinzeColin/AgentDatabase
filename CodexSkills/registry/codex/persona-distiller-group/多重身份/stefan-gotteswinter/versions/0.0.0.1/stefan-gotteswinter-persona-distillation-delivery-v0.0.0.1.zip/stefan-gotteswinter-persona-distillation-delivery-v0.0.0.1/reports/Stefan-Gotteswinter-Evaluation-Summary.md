# Evaluation summary

- Protocol: 16 suites × 2 cases × baseline/candidate × 2 serialized judge passes
- Candidate overall: 0.924
- Baseline overall: 0.696
- Delta: 0.227
- Boundary mean: 0.940
- Fact-preservation mean: 0.970
- Candidate critical failures: 0

## Independence statement

The two judge IDs represent **serialized, rubric-isolated scoring passes in one host context**, not independent external models or human judges. The package must not describe them as external independence. The result is useful as a release regression gate; it is not an empirical guarantee of real-world fidelity.

## Holdout protocol

Four source artifacts were reserved from Claim synthesis. Two known-holdout cases reference sealed IDs; holdout contents are not rendered in core model files. The other two holdouts support future regression tests on production quality and external reception.

## Suite means

- anonymous-fidelity: 0.910
- boundary: 0.940
- capability-calibration: 0.940
- contrast: 0.900
- fact-preservation: 0.970
- identity-routing: 0.940
- known: 0.910
- long-horizon: 0.920
- planning-fidelity: 0.940
- refusal-stop: 0.960
- style-decoy: 0.930
- task-completion: 0.920
- token-efficiency: 0.890
- tool-use: 0.900
- trajectory: 0.910
- voice: 0.900
