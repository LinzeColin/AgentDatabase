# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `rich-hickey`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.2`
- 内层运行时 SHA-256：`971518fdca76f7007930b0b0380aa8820bedff34c30cae25928529be25fc89de`
- 运行时调用版本：无
- 唯一登记身份：`多重身份`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-serialized-isolation`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
