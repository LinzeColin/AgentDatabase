# Persona Distiller quality report

- Target: `/mnt/data/persona_workspaces/harry-bhadeshia`
- Phase: `release`
- Profile: `deep`
- Generated: `2026-07-24T05:02:53Z`
- Result: **PASS**

## Metrics

```json
{
  "skill_lines": 54,
  "ledger_counts": {
    "sources": 67,
    "claims": 71
  },
  "sources_total": 67,
  "sources_train": 64,
  "sources_usable_train": 64,
  "sources_holdout": 3,
  "primary_sources": 63,
  "primary_ratio": 0.9844,
  "lane_source_counts": {
    "writings": 50,
    "conversations": 6,
    "expression": 21,
    "external": 28,
    "decisions": 43,
    "timeline": 22
  },
  "research_lanes_complete": [
    "writings",
    "conversations",
    "expression",
    "external",
    "decisions",
    "timeline"
  ],
  "claims_total": 71,
  "claims_active": 71,
  "mental_models": 6,
  "heuristics": 11,
  "claim_markers": 71,
  "eval_cases": 32,
  "eval_suite_counts": {
    "known": 2,
    "boundary": 2,
    "voice": 2,
    "trajectory": 2,
    "contrast": 2,
    "fact-preservation": 2,
    "style-decoy": 2,
    "task-completion": 2,
    "planning-fidelity": 2,
    "tool-use": 2,
    "capability-calibration": 2,
    "refusal-stop": 2,
    "long-horizon": 2,
    "identity-routing": 2,
    "anonymous-fidelity": 2,
    "token-efficiency": 2
  },
  "eval_results": 128,
  "candidate_overall": 0.9347,
  "baseline_overall": 0.6669,
  "candidate_baseline_delta": 0.2678,
  "suite_candidate_means": {
    "known": 0.91,
    "boundary": 0.97,
    "voice": 0.9,
    "trajectory": 0.92,
    "contrast": 0.91,
    "fact-preservation": 0.985,
    "style-decoy": 0.95,
    "task-completion": 0.92,
    "planning-fidelity": 0.92,
    "tool-use": 0.97,
    "capability-calibration": 0.96,
    "refusal-stop": 0.98,
    "long-horizon": 0.91,
    "identity-routing": 0.96,
    "anonymous-fidelity": 0.89,
    "token-efficiency": 0.9
  },
  "secret_findings": 0
}
```

## Errors

- None

## Warnings

- None
