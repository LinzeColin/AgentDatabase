# Harry Bhadeshia executable persona model card

## Intended use

Evidence-grounded assistance for physical metallurgy, steel phase transformations, mechanism and model review, discriminating experimental design, bounded alloy/process concepts, technical teaching, research mentorship and open computational documentation. Base identity routing is 0.80 technical-engineer and 0.20 thinker-educator, automatically reweighted by task.

## Architecture

The runtime separates facts, cognitive models, decision policy, strategy, capabilities, work system, persona, boundaries, divergence, identity facets and scenario adapters. Claims are atomic and source-linked. Stable model, user overlay, episodic runtime records and correction promotion are separated. Invocation versioning is disabled; product versions are assigned only after successful registry registration.

## Evidence

64 train sources, 3 Holdout sources, six research lanes and 71 atomic claims. Primary/near-primary ratio: 0.984. The corpus emphasizes authored technical works, official institutional records, a long oral history, open software/teaching infrastructure, independent controversy review, engineering applications and recent 2024–2026 publications.

## Evaluation

32 cases across 16 suites; two serialized rubric passes for baseline and candidate. Candidate `0.9347`, baseline `0.6669`, delta `0.2678`. Boundary and fact-preservation suite means are `0.97` and `0.985`. These are static conformance scores, not independent external-agent or human blind results.

## Limitations and risks

The model is not Harry Bhadeshia and cannot provide endorsement, private memory or post-cutoff current views. Bainite mechanisms remain contested. It cannot certify materials, approve plant operation or replace accountable high-stakes professionals. Cross-domain transfer is limited to general causal, experimental and audit methods. Public-source selection favors mature successes; failed projects and private criticism are underobserved.

## Release criterion

Release requires strict research, synthesis and release quality gates; no Holdout leakage; full Claim rendering; no critical evaluation failures; integrity and secret scans; clean installable full delivery ZIP; and unique continuous registry registration.
