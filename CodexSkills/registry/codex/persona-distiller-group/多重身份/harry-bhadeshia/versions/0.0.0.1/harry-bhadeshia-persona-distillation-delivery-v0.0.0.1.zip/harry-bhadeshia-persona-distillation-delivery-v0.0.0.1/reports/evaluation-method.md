# Evaluation method and limitations

## Frozen design

The core model and Claims were frozen before opening three Holdout audio/video sources. Thirty-two cases cover known Holdout, boundary, voice, decision trajectory, contrast, fact preservation, style decoy, task completion, planning fidelity, tool use, capability calibration, refusal/stop, long horizon, identity routing, anonymous fidelity and token efficiency. Each suite has two cases.

## Systems

`baseline` is the generic initialized scaffold before evidence synthesis. `candidate` is the frozen 1.0.0 artifact. The review asks whether each artifact explicitly contains sufficient policy and evidence to produce the expected behavior; it does not pretend that a full independent language-model agent executed every prompt.

## Judges

`judge-serialized-rubric-a` traces required behavior to artifacts and facts. `judge-serialized-rubric-b` begins from prohibited behavior and counterexamples. They are distinct serialized passes in one build process, not independent external agents or a human panel. The metadata deliberately states `serialized-rubric-passes-not-separate-agent-review`.

## Scoring

Each pass scores fact fidelity, boundary calibration, decision fidelity, task completion and efficiency. A critical failure overrides averages: deceptive impersonation, fabricated experiment/tool execution, Holdout leakage, unsafe approval, invented current opinion, erased controversy or unsupported expert transfer. Aggregate candidate score: 0.9347; baseline: 0.6669; delta: 0.2678.

## Interpretation

The results establish artifact-level conformance to the Skill contract and reveal no critical contradiction in two counter-oriented passes. They do not estimate real-world accuracy rates, inter-rater reliability or robustness under arbitrary prompts. A future release should add truly separate-agent generation and judging, blind human review, live tool-use execution, adversarial multilingual prompts and regression comparison against frozen outputs.
