# Evaluation Report — Shreya Shankar Persona Model

## Scope and integrity

- Evaluation date: 2026-07-24
- Pre-holdout model freeze: `reports/model-freeze-pre-holdout.json`
- Holdout contamination review: `reports/holdout-contamination-review.json`
- Cases: **32** across **16** suites, two cases per suite
- Results: **128** (`baseline` and `candidate`, two rubric passes each)
- Evaluation independence: **serialized rubric passes on one host; not independent external agents**
- Critical failures: **0**

The two `known` cases reference only sources that were declared as holdout before the model freeze. Holdout observations were read after freezing, and no runtime claim or core model file was patched afterward. One declared holdout title could not be resolved to stable full text; it was retained as metadata-only and excluded from substantive scored findings.

## Aggregate metrics

| Metric | Score |
|---|---:|
| Candidate overall | 0.928 |
| Baseline overall | 0.705 |
| Candidate − baseline | 0.223 |
| Boundary suite | 0.965 |
| Fact-preservation suite | 0.976 |
| Known/holdout suite | 0.923 |

## Candidate scores by suite

| Suite | Cases | Candidate mean |
|---|---:|---:|
| anonymous-fidelity | 2 | 0.917 |
| boundary | 2 | 0.965 |
| capability-calibration | 2 | 0.955 |
| contrast | 2 | 0.895 |
| fact-preservation | 2 | 0.976 |
| identity-routing | 2 | 0.935 |
| known | 2 | 0.923 |
| long-horizon | 2 | 0.903 |
| planning-fidelity | 2 | 0.907 |
| refusal-stop | 2 | 0.976 |
| style-decoy | 2 | 0.919 |
| task-completion | 2 | 0.915 |
| token-efficiency | 2 | 0.893 |
| tool-use | 2 | 0.923 |
| trajectory | 2 | 0.939 |
| voice | 2 | 0.907 |

## Interpretation

The candidate's largest gains over the generic baseline occur where the frozen model supplies distinctive procedures: beginning with real user tasks and actual failure data; decomposing systems rather than selecting models in isolation; calibrating evaluation rigor to stakes; preserving provenance and reproducibility; and turning human feedback into a monitored regression loop. Boundary and fact-preservation cases also verify that the package does not authorize first-person impersonation, invented endorsement, private-belief inference, or unsupported current facts.

These scores are release-gate evidence, not a claim of independent human validation. A future version should repeat the same case set with separately hosted blind judges and real generated transcripts.
