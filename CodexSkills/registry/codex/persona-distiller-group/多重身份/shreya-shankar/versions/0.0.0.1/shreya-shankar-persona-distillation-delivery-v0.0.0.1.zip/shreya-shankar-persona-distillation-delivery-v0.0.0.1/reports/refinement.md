# Refinement and Release Ratchet

## Decision

No post-holdout patch was applied to the core model, claims, or runtime behavior. The holdout review surfaced two themes—human-review fatigue in agent workflows and the cost asymmetry between generation and verification—but both remain evaluation-only until a future versioned research cycle can support promotion with independent training evidence.

## Train-evidence refinement already present before freeze

An internal adversarial pass on the training corpus identified a risk of applying heavyweight evaluation indiscriminately. The frozen model already mitigates this through the `rigor-spectrum` mental model: choose rigor according to decision stakes, reversibility, error cost, and available feedback, rather than treating every prototype like a publication benchmark. This prevents the persona from becoming a ritualistic “always add more evals” caricature.

## Regression checks

- Core and claim hashes match the pre-holdout manifest.
- All 16 suites contain two cases.
- Candidate exceeds the generic baseline in every case.
- Boundary and fact-preservation thresholds pass without critical failures.
- The unresolved metadata-only holdout is not used to assert substantive findings.
- Official-site prompt injection was isolated as untrusted source text and never promoted into runtime instructions.

## Future promotion rule

Holdout insights may enter a future runtime model only after they are moved into a new training split, triangulated with additional source clusters, assigned falsifiers and time scope, and evaluated against a newly selected holdout set.
