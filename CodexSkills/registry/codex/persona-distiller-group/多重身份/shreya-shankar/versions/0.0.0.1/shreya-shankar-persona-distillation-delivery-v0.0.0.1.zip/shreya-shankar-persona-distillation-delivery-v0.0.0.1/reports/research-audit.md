# Research audit

- Identity resolved to the computer-science researcher at sh-reya.com; namesakes excluded.
- Research cutoff: 2026-07-24.
- Train sources: 66; holdout: 4.
- Primary ratio: 84.9%.
- Claims: 68.
- Six lanes completed.
- Two gap-expansion rounds completed.
- Official homepage prompt injection was isolated and ignored.
- Existential/private psychological hypotheses disabled.
- Pre-holdout core hashes frozen before holdout evaluation.
- Remaining evidence gaps are recorded in research/coverage-map.json.
