# R. Keith Mobley 人物蒸馏报告

- 研究截止：2026-07-24
- 配置：deep
- 训练来源：47；Holdout：6
- 原子主张：63
- 评测案例：32；量表结果：128
- 评测独立性：序列化隔离量表复核，不声称外部独立代理或现场验证。

## 蒸馏结论

该模型将 Mobley 的公开方法压缩为一条工程执行链：以全生命周期企业价值定义维护使命；用正常工况、失效模式和 forcing functions 建立因果诊断；把过程和数据基础置于技术放大之前；用关键度、根因、明确 PM、自下而上预算和五十二周计划实现；再将结果翻译为风险、产能、质量、现金和资产寿命。

## 证据质量

主要证据来自 2025 年长访谈、作者/出版社书目、行业文章和机构资料。职业年限、项目金额和书籍总数中的自述/口径差异被保留；没有私密客户材料、完整项目财务或当前实时意见。

## 最佳使用场景

- 可靠性与维护战略诊断
- 预测性维护与状态监测方案
- 根因失效分析与重复故障复盘
- PM 任务优化、年度计划和预算
- 维护组织、技能、激励和数字化转型

## 不适用

- 无现场数据的确定设备诊断或剩余寿命
- 安全复机、法规/OEM/持证签字替代
- 证券投资、医学、法律或其他跨域专家意见
- 本人身份、背书、签名或当前观点模拟

## 主要模型 Claim

- `clm-82634e35eb83` 维护不是孤立成本中心，而是从设计、采购、安装、调试、运行到退役的全生命周期资产价值系统；局部维修决策必须按总拥有成本、风险和生产价值评估。
- `clm-a83f322205df` 设备故障往往是运行动态偏离正常状态的结果：负荷、速度、温度、压力、材料、安装与操作等 forcing functions 通过失效模式形成可观测症状；不能把症状本身当根因。
- `clm-bd0fe3a3c24a` 技术价值服从“过程清晰—数据可信—正常状态已知—失效模式可解释—工具匹配”的基础链；传感器、CMMS、预测分析或数字孪生不能补偿混乱流程和劣质数据。
- `clm-4ac8399d532e` 维护活动必须通过风险、产能、质量、安全、现金、资产寿命和盈利形成可追踪的经济线索；没有价值连线的任务、指标或预算容易沦为活动量管理。
- `clm-c0848422cb34` 同一故障、堵塞或修复重复出现时，默认把它升级为根因问题，而不是继续把每次事件当独立工单。
- `clm-125198d0dbb5` 把法定、预防、预测、停机和改造工作放进滚动五十二周负荷图，按技能、材料、窗口和预算平衡，而不是只优化未来两周。
- `clm-6db65729fac6` 每个 PM 任务至少写明对象、变量、方法、限值、频率和越界动作；“检查、观察、确认正常”不是可审计任务。
- `clm-b0e59d213f5f` RCA 采用跨职能小组和证据链：定义问题与后果、保全事实、审查设计与实际状态、列出失效模式和 forcing functions、验证原因、配置控制、检查复发。

## 来源索引

- `src-ee8168c3ad0b` Podcast Part 1 — career and publishing record — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-cdb19f0f1a44` Podcast Part 1 — formative maintenance experience — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-4ae632505370` Podcast Part 1 — mission of maintenance — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-29e97f263d56` Podcast Part 1 — cycle of reactivity — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-74b42e0e5d5b` Podcast Part 1 — life-cycle asset management — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-359223023379` Podcast Part 1 — arbitrary budgets and deferral — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-c5067a532bb8` Podcast Part 1 — preventive-maintenance task quality — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-4e9ec07e9b26` Podcast Part 1 — repeated failure and root cause — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-e33ecc4dc600` Podcast Part 1 — span of control — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-9ee197f30b85` Podcast Part 1 — planning horizon — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-3f1e4c2d49ea` Podcast Part 1 — teaching and expression markers — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-da640ed8b59a` Podcast Part 2 — LCAM as operating philosophy — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-b6068e516a0a` Podcast Part 2 — executive language — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-25beb347cd5b` Podcast Part 2 — bottom-up budget — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-9fe10cb95c72` Podcast Part 2 — explicit run-to-failure choices — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-7854bb1abff9` Podcast Part 2 — decision quality and information — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-021a3ba4bd18` Podcast Part 2 — process before technology — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-185065ed4dcb` Podcast Part 2 — predictive analytics and digital twins — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-24d2b4a3b95e` Podcast Part 2 — consultant duty — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-f9cbc01c6d34` Podcast Part 2 — culture and system inconsistency — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-e9344b007a2d` Podcast Part 2 — fifty-two-week load levelling — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-4df57691ff69` Podcast Part 2 — leadership stance — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-46eea9ab0429` Reflections on Excellence — overview — https://www.lce.com/resources/reflections-on-excellence-a-r-keith-mobley-book/
- `src-8bd459b67a7a` Uptime Elements Root Cause Analysis — team and scope — https://reliabilityweb.com/en/articles/uptime-elements-root-cause-analysis
- `src-57426f204581` Uptime Elements Root Cause Analysis — evidence method — https://reliabilityweb.com/en/articles/uptime-elements-root-cause-analysis
- `src-6cd8127d3864` Developing an Effective Workforce — system design — https://reliabilityweb.com/articles/entry/developing_an_effective_workforce
- `src-17a2dab1dcb6` Developing an Effective Workforce — incentives — https://reliabilityweb.com/articles/entry/developing_an_effective_workforce
- `src-59cf87295ca1` Reliabilityweb biographical profile — https://reliabilityweb.com/news/article/life_cycle_engineering_introduces_r._keith_mobleys_reflections_on_excellenc
- `src-13d9fb10eef9` Reliabilityweb profile — diagnose before prescribing — https://reliabilityweb.com/news/article/life_cycle_engineering_introduces_r._keith_mobleys_reflections_on_excellenc
- `src-a22cd9a7ad1e` Total Plant Performance Management — https://shop.elsevier.com/books/total-plant-performance-management/mobley/978-0-88415-877-6
- `src-ee938b1e2bba` Fluid Power Dynamics — https://shop.elsevier.com/books/fluid-power-dynamics/mobley/978-0-7506-7174-3
- `src-0af829dfa763` Maintenance Fundamentals — https://shop.elsevier.com/books/maintenance-fundamentals/mobley/978-0-08-051065-1
- `src-1c8bcc62ceff` An Introduction to Predictive Maintenance, Second Edition — https://shop.elsevier.com/books/an-introduction-to-predictive-maintenance/mobley/978-0-7506-7531-4
- `src-1aaa7a2733ea` Root Cause Failure Analysis — https://shop.elsevier.com/books/root-cause-failure-analysis/mobley/978-0-7506-7158-3
- `src-7f289ba66444` Vibration Fundamentals — https://shop.elsevier.com/books/vibration-fundamentals/mobley/978-0-7506-7150-7
- `src-71ff42ab3d48` Plant Engineer’s Handbook — https://shop.elsevier.com/books/plant-engineers-handbook/mobley/978-0-7506-7328-0
- `src-8d05bf675d44` Industrial Machinery Repair — https://shop.elsevier.com/books/industrial-machinery-repair/smith/978-0-7506-7621-2
- `src-47ef33e59a72` Rules of Thumb for Maintenance and Reliability Engineers — https://shop.elsevier.com/books/rules-of-thumb-for-maintenance-and-reliability-engineers/smith/978-0-7506-7862-9
- `src-ba3d3002ca60` Maintenance Engineering Handbook, Eighth Edition — https://books.google.com/books/about/Maintenance_Engineering_Handbook_Eighth.html?id=usPbAgAAQBAJ
- `src-b6d7e4ad1530` Maintenance Engineering Handbook, Ninth Edition — https://books.google.com/books/about/Maintenance_Engineering_Handbook_Ninth_E.html?id=9uQ80QEACAAJ
- `src-09ff727caf0f` University of Alabama maintenance course profile — https://training.ua.edu/factoryandprocess/
- `src-b359553c81bd` Podcast Part 1 — legacy degradation tracking — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-1ea59173aef4` Podcast Part 1 — finite-life intervention economics — https://www.lce.com/resources/part-1-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-bf9e670f13e7` Podcast Part 2 — CMMS discipline — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-84bdd7ae2b55` Podcast Part 2 — normal state and causal model — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-4fc2bd8edb2b` Podcast Part 2 — consulting scale and plant economics — https://www.lce.com/resources/part-2-of-maintenance-management-re-envisioned-from-cost-center-to-strategic-advantage-2/
- `src-b678d89f4c8c` Maintenance Engineering Handbook, Ninth Edition — updated feature set — https://books.google.com/books/about/Maintenance_Engineering_Handbook_Ninth_E.html?id=9uQ80QEACAAJ
- `src-67510e16123e` Holdout — predictive maintenance table of contents — https://www.sciencedirect.com/book/9780750675314/an-introduction-to-predictive-maintenance
- `src-c2fc8e2a6884` Holdout — vibration frequency is only one evidence dimension — https://www.sciencedirect.com/topics/engineering/vibration-frequency
- `src-55a37d625ed0` Holdout — vibration measurement procedure — https://www.sciencedirect.com/topics/engineering/vibration-measurement
- `src-aaf61ce0994d` Holdout — public bibliography — https://www.goodreads.com/author/list/539317.R_Keith_Mobley
- `src-8ddf31f3c313` Holdout — RCFA bibliographic record — https://search.worldcat.org/title/41565038
- `src-ad4a3a914d4a` Holdout — predictive maintenance techniques chapter — https://www.researchgate.net/publication/299918574_Predictive_Maintenance_Techniques
