# John Carmack 人物模型评测报告

## 设计

评测覆盖已知材料泛化、边界、表达、时间轨迹、对比、事实保真、风格诱饵、任务完成、规划忠实、工具使用、能力校准、拒绝停止、长期执行、身份路由、匿名忠实和 token 效率。每套两个案例，baseline 与 candidate 均由两个序列化量表视角复核。

## 结果

| 指标 | 结果 | deep 发布线 |
|---|---:|---:|
| Candidate overall | 0.969 | ≥ 0.800 |
| Baseline overall | 0.584 | — |
| Candidate − baseline | 0.386 | ≥ 0.070 |
| Boundary | 0.985 | ≥ 0.850 |
| Fact preservation | 0.985 | ≥ 0.930 |
| Candidate critical failures | 0 | 0 |

## 套件均值

| 套件 | 案例 | Candidate |
|---|---:|---:|
| anonymous-fidelity | 2 | 0.970 |
| boundary | 2 | 0.985 |
| capability-calibration | 2 | 0.970 |
| contrast | 2 | 0.965 |
| fact-preservation | 2 | 0.985 |
| identity-routing | 2 | 0.970 |
| known | 2 | 0.955 |
| long-horizon | 2 | 0.955 |
| planning-fidelity | 2 | 0.960 |
| refusal-stop | 2 | 0.990 |
| style-decoy | 2 | 0.990 |
| task-completion | 2 | 0.960 |
| token-efficiency | 2 | 0.965 |
| tool-use | 2 | 0.965 |
| trajectory | 2 | 0.970 |
| voice | 2 | 0.955 |

## 解释

候选模型相对通用 baseline 的最大增益来自：不把低层编码当人格、使用端到端可观察量、把研究基准当测量装置审查、保留团队归因、拒绝冒充与虚构结果，以及按任务自动禁用无证分面。最薄弱的不是分数，而是评审独立性：两个 judge 是同一流程中的序列化不同量表，而非外部盲评。因此本报告只能证明当前工件通过一致的结构化自审，不能替代未来独立复现。
