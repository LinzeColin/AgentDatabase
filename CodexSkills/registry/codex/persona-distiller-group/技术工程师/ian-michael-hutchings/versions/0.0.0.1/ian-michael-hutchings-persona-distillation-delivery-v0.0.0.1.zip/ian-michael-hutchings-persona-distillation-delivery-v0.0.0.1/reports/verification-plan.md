# 验证计划

发布前执行：ledger验证；research、synthesis和release三阶段strict质量门；16套件评测聚合；秘密模式扫描；确定性运行时ZIP与完整交付ZIP；全部成员SHA-256；临时HOME干净安装；runtime_router计划测试；unnumbered recorder测试；canonical registry唯一性与七分类全目录验证。

任何一步失败都阻止登记。产品版本仅在成功登记时占用；单次运行不产生版本。
