# Handoff

## 安装与调用

运行 `python3 install.py` 安装 `barbara-liskov`。安装后直接调用人物 Skill 并给出任务；不需要选择身份、编号或权重。

## 不可变边界

- 产品版本：`0.0.0.1`
- 内层运行时 SHA-256：`7371eba257381e878dabb7f77b2286333f6222d956a3b4afbfc2c55581d0a25f`
- 运行时调用版本：无
- 唯一登记身份：`技术工程师`

## 审计可用性

- `verification.json`: `passed`
- `provenance.json`: `passed`
- `source-coverage.json`: `passed`
- `evaluation-summary.json`: `passed`
- `review-record.json`: `passed-with-serialized-isolation`

`not-available-in-source-artifact` 表示历史来源包没有该证据，不表示已通过，也不得据此补造。
