#!/usr/bin/env python3
"""Safely verify and optionally full-test a Verifier v0.0.2.2 release ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Optional

DELIVERY_NAME = "verifier-skill-v0.0.2.2"
SKILL_VERSION = "0.0.2.2"
MANIFEST_NAME = "DELIVERY_MANIFEST.json"
CHECKSUMS_NAME = "SHA256SUMS.txt"
MAX_ARCHIVE_BYTES = 256 * 1024 * 1024
MAX_MEMBERS = 10_000
MAX_MEMBER_BYTES = 256 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED = 2 * 1024 * 1024 * 1024
MAX_COMPRESSION_RATIO = 1000
CACHE_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
CACHE_SUFFIXES = {".pyc", ".pyo"}
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
EXPECTED_ZIP_TIME = (2026, 7, 25, 0, 0, 0)
WINDOWS_RESERVED = {
    "con", "prn", "aux", "nul",
    *(f"com{index}" for index in range(1, 10)),
    *(f"lpt{index}" for index in range(1, 10)),
}
WINDOWS_FORBIDDEN_CHARS = set('<>:"|?*')
MAX_PATH_COMPONENT_BYTES = 255
MAX_RELATIVE_PATH_BYTES = 1024


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def portable_path_key(name: str, label: str) -> str:
    if len(name.encode("utf-8")) > MAX_RELATIVE_PATH_BYTES:
        raise ValueError(f"{label} exceeds portable path length: {name!r}")
    path = PurePosixPath(name)
    for part in path.parts:
        if unicodedata.normalize("NFC", part) != part:
            raise ValueError(f"non-NFC {label}: {name!r}")
        if len(part.encode("utf-8")) > MAX_PATH_COMPONENT_BYTES:
            raise ValueError(f"{label} component exceeds portable length: {part!r}")
        if part.endswith((" ", ".")):
            raise ValueError(f"non-portable trailing space/dot in {label}: {name!r}")
        if any(ord(ch) < 32 or ch in WINDOWS_FORBIDDEN_CHARS for ch in part):
            raise ValueError(f"Windows-incompatible character in {label}: {name!r}")
        if part.split(".", 1)[0].casefold() in WINDOWS_RESERVED:
            raise ValueError(f"Windows-reserved component in {label}: {name!r}")
    return unicodedata.normalize("NFC", name).casefold()


def safe_member_name(name: str) -> PurePosixPath:
    if not name or "\x00" in name or "\\" in name or name.startswith("/"):
        raise ValueError(f"unsafe ZIP member name: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"unsafe ZIP member path: {name!r}")
    if not path.parts or path.parts[0] != DELIVERY_NAME:
        raise ValueError(f"ZIP member is outside exact root {DELIVERY_NAME}: {name}")
    if len(path.parts) < 2:
        raise ValueError("ZIP cannot contain a root-only file entry")
    portable_path_key(path.as_posix(), "ZIP member path")
    return path


def inspect_archive(archive_path: Path) -> dict[str, Any]:
    raw_archive = Path(os.path.abspath(os.fspath(archive_path.expanduser())))
    if raw_archive.is_symlink():
        raise ValueError("release archive must not be a symlink")
    archive_path = raw_archive.resolve(strict=True)
    if not archive_path.is_file():
        raise ValueError("release archive must be a regular file")
    if archive_path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("release archive exceeds size limit")
    seen: set[str] = set()
    folded: dict[str, str] = {}
    total = 0
    file_count = 0
    with zipfile.ZipFile(archive_path) as archive:
        infos = archive.infolist()
        if len(infos) > MAX_MEMBERS:
            raise ValueError("ZIP has too many members")
        for info in infos:
            path = safe_member_name(info.filename)
            normalized = path.as_posix()
            if normalized in seen:
                raise ValueError(f"duplicate ZIP member: {normalized}")
            seen.add(normalized)
            key = portable_path_key(normalized, "ZIP member path")
            if key in folded and folded[key] != normalized:
                raise ValueError(f"case-colliding ZIP members: {folded[key]} / {normalized}")
            folded[key] = normalized
            unix_mode = (info.external_attr >> 16) & 0xFFFF
            file_type = stat.S_IFMT(unix_mode)
            if file_type == stat.S_IFLNK:
                raise ValueError(f"symlink forbidden in ZIP: {normalized}")
            if file_type not in {0, stat.S_IFREG, stat.S_IFDIR}:
                raise ValueError(f"special file forbidden in ZIP: {normalized}")
            if info.flag_bits & 0x1:
                raise ValueError(f"encrypted ZIP member forbidden: {normalized}")
            if info.is_dir():
                raise ValueError(f"directory entries forbidden in deterministic ZIP: {normalized}")
            file_count += 1
            if info.file_size > MAX_MEMBER_BYTES:
                raise ValueError(f"ZIP member exceeds size limit: {normalized}")
            total += info.file_size
            if total > MAX_TOTAL_UNCOMPRESSED:
                raise ValueError("ZIP uncompressed total exceeds limit")
            if info.file_size > 0 and info.compress_size == 0:
                raise ValueError(f"invalid compression metadata: {normalized}")
            if info.compress_size > 0 and info.file_size / info.compress_size > MAX_COMPRESSION_RATIO:
                raise ValueError(f"ZIP compression ratio exceeds limit: {normalized}")
            permissions = unix_mode & 0o777
            if info.create_system != 3 or permissions not in {0o644, 0o755}:
                raise ValueError(f"non-canonical ZIP mode metadata: {normalized}")
            if info.date_time != EXPECTED_ZIP_TIME:
                raise ValueError(f"non-canonical ZIP timestamp: {normalized}")
            if info.compress_type != zipfile.ZIP_DEFLATED:
                raise ValueError(f"non-canonical ZIP compression method: {normalized}")
        required = {
            f"{DELIVERY_NAME}/{MANIFEST_NAME}",
            f"{DELIVERY_NAME}/{CHECKSUMS_NAME}",
            f"{DELIVERY_NAME}/README_FIRST.md",
            f"{DELIVERY_NAME}/install.py",
            f"{DELIVERY_NAME}/verifier/SKILL.md",
            f"{DELIVERY_NAME}/verifier/VERSION",
        }
        missing = sorted(required - seen)
        if missing:
            raise ValueError(f"ZIP missing required members: {missing}")
    return {"ok": True, "archive": str(archive_path), "sha256": sha256_file(archive_path), "members": file_count, "uncompressed_bytes": total}


def safe_extract(archive_path: Path, destination: Path) -> Path:
    inspection = inspect_archive(archive_path)
    destination.mkdir(parents=True, exist_ok=True)
    destination_resolved = destination.resolve(strict=True)
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            path = safe_member_name(info.filename)
            target = destination_resolved.joinpath(*path.parts)
            target_parent = target.parent
            target_parent.mkdir(parents=True, exist_ok=True)
            resolved_parent = target_parent.resolve(strict=True)
            try:
                resolved_parent.relative_to(destination_resolved)
            except ValueError as error:
                raise ValueError(f"extraction path escapes destination: {info.filename}") from error
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            with archive.open(info, "r") as source, target.open("xb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
            mode = (info.external_attr >> 16) & 0o777
            target.chmod(mode or 0o644)
    root = destination_resolved / DELIVERY_NAME
    if not root.is_dir() or root.is_symlink():
        raise ValueError("extracted release root missing or unsafe")
    inspection["extracted_root"] = str(root)
    return root


def _safe_rel(raw: Any, label: str) -> str:
    if not isinstance(raw, str) or not raw or "\x00" in raw or "\\" in raw:
        raise ValueError(f"unsafe {label}: {raw!r}")
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"unsafe {label}: {raw!r}")
    rel = path.as_posix()
    portable_path_key(rel, label)
    return rel


def collect_tree(root: Path, excludes: set[str]) -> dict[str, tuple[int, str]]:
    result: dict[str, tuple[int, str]] = {}
    folded: dict[str, str] = {}
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix().casefold()):
        relative = path.relative_to(root)
        rel = relative.as_posix()
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise ValueError(f"symlink forbidden in extracted release: {rel}")
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode):
            raise ValueError(f"non-regular entry forbidden in extracted release: {rel}")
        if bool(set(relative.parts) & CACHE_DIRS) or relative.suffix in CACHE_SUFFIXES:
            raise ValueError(f"runtime cache forbidden in extracted release: {rel}")
        if rel in excludes:
            continue
        _safe_rel(rel, "release path")
        key = portable_path_key(rel, "release path")
        if key in folded and folded[key] != rel:
            raise ValueError(f"case-colliding release paths: {folded[key]} / {rel}")
        folded[key] = rel
        result[rel] = (path.stat().st_size, sha256_file(path))
    return result


def parse_checksums(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    folded: dict[str, str] = {}
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line or "  " not in line:
            raise ValueError(f"{CHECKSUMS_NAME}:{number}: invalid format")
        digest, raw = line.split("  ", 1)
        if not SHA_RE.fullmatch(digest):
            raise ValueError(f"{CHECKSUMS_NAME}:{number}: invalid digest")
        rel = _safe_rel(raw, f"{CHECKSUMS_NAME}:{number}")
        if rel in result:
            raise ValueError(f"{CHECKSUMS_NAME}:{number}: duplicate path")
        key = portable_path_key(rel, f"{CHECKSUMS_NAME}:{number}")
        if key in folded and folded[key] != rel:
            raise ValueError(f"{CHECKSUMS_NAME} case collision")
        folded[key] = rel
        result[rel] = digest
    return result


def verify_tree(root: Path) -> dict[str, Any]:
    raw_root = Path(os.path.abspath(os.fspath(root.expanduser())))
    if raw_root.is_symlink():
        raise ValueError("delivery root must not be a symlink")
    root = raw_root.resolve(strict=True)
    if root.name != DELIVERY_NAME:
        raise ValueError("wrong or unsafe delivery root")
    manifest_path = root / MANIFEST_NAME
    sums_path = root / CHECKSUMS_NAME
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"), object_pairs_hook=no_duplicate_keys)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as error:
        raise ValueError(f"invalid {MANIFEST_NAME}: {error}") from error
    if not isinstance(manifest, dict):
        raise ValueError(f"{MANIFEST_NAME} root must be object")
    if manifest.get("schema_version") != "1.0" or manifest.get("delivery_name") != DELIVERY_NAME or manifest.get("skill_version") != SKILL_VERSION:
        raise ValueError("delivery identity mismatch")
    entries = manifest.get("entries")
    if not isinstance(entries, list):
        raise ValueError("delivery manifest entries must be an array")
    expected: dict[str, tuple[int, str]] = {}
    folded: dict[str, str] = {}
    for index, item in enumerate(entries):
        if not isinstance(item, dict):
            raise ValueError(f"manifest entries[{index}] must be object")
        rel = _safe_rel(item.get("path"), f"manifest entries[{index}].path")
        size, digest = item.get("size"), item.get("sha256")
        if isinstance(size, bool) or not isinstance(size, int) or size < 0 or not isinstance(digest, str) or not SHA_RE.fullmatch(digest):
            raise ValueError(f"manifest entries[{index}] invalid size/hash")
        if rel in expected:
            raise ValueError(f"duplicate delivery manifest path: {rel}")
        key = portable_path_key(rel, f"manifest entries[{index}].path")
        if key in folded and folded[key] != rel:
            raise ValueError(f"delivery manifest case collision: {folded[key]} / {rel}")
        folded[key] = rel
        expected[rel] = (size, digest)
    actual = collect_tree(root, {MANIFEST_NAME, CHECKSUMS_NAME})
    if expected != actual:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        changed = sorted(rel for rel in set(expected) & set(actual) if expected[rel] != actual[rel])
        raise ValueError(f"delivery manifest mismatch: missing={missing[:5]} extra={extra[:5]} changed={changed[:5]}")
    sums = parse_checksums(sums_path)
    actual_sums = {rel: digest for rel, (_size, digest) in collect_tree(root, {CHECKSUMS_NAME}).items()}
    if sums != actual_sums:
        missing = sorted(set(sums) - set(actual_sums))
        extra = sorted(set(actual_sums) - set(sums))
        changed = sorted(rel for rel in set(sums) & set(actual_sums) if sums[rel] != actual_sums[rel])
        raise ValueError(f"delivery checksum mismatch: missing={missing[:5]} extra={extra[:5]} changed={changed[:5]}")
    if (root / "verifier/VERSION").read_text(encoding="utf-8").strip() != SKILL_VERSION:
        raise ValueError("inner VERSION mismatch")
    return {"ok": True, "root": str(root), "manifest_entries": len(expected), "checksum_entries": len(sums)}


def run_command(argv: list[str], cwd: Path, env: dict[str, str], timeout: int = 360) -> dict[str, Any]:
    try:
        proc = subprocess.run(
            argv,
            cwd=cwd,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"argv": argv, "ok": False, "returncode": None, "error": str(error)}
    return {"argv": argv, "ok": proc.returncode == 0, "returncode": proc.returncode, "stdout_tail": proc.stdout[-4000:], "stderr_tail": proc.stderr[-4000:]}


def full_validate(root: Path) -> dict[str, Any]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = "0"
    steps: list[dict[str, Any]] = []
    commands = [
        ([sys.executable, "-B", "scripts/validate_pack.py", ".", "--mode", "distribution", "--json"], root / "verifier"),
        ([sys.executable, "-B", "scripts/verify_distribution.py", "verify", ".", "--mode", "distribution", "--json"], root / "verifier"),
        ([sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-v"], root / "verifier"),
        ([sys.executable, "-B", "-m", "unittest", "discover", "-s", "delivery_tests", "-p", "test_installer.py", "-v"], root),
        ([sys.executable, "-B", "-m", "unittest", "discover", "-s", "delivery_tests", "-p", "test_release_wrapper.py", "-v"], root),
        ([sys.executable, "-B", "install.py", "inspect", "--surface", "codex"], root),
        ([sys.executable, "-B", "install.py", "inspect", "--surface", "codex", "--json"], root),
    ]
    for argv, cwd in commands:
        steps.append(run_command(argv, cwd, env))
    with tempfile.TemporaryDirectory(prefix="verifier-release-install-") as temporary:
        temp = Path(temporary)
        flow_env = dict(env)
        flow_env["CODEX_HOME"] = str(temp / "codex-home")
        flow_commands = [
            [sys.executable, "-B", "install.py", "inspect", "--surface", "codex"],
            [sys.executable, "-B", "install.py", "install", "--surface", "codex"],
            [sys.executable, "-B", "install.py", "verify", "--surface", "codex", "--selftest"],
            [sys.executable, "-B", "install.py", "install", "--surface", "codex", "--no-selftest"],
            [sys.executable, "-B", "install.py", "uninstall", "--surface", "codex"],
            [sys.executable, "-B", "install.py", "rollback", "--surface", "codex"],
            [sys.executable, "-B", "install.py", "verify", "--surface", "codex", "--selftest"],
        ]
        for argv in flow_commands:
            steps.append(run_command(argv, root, flow_env, timeout=420))
    return {"ok": all(step.get("ok") for step in steps), "steps": steps}


def verify_release(archive_path: Path, full: bool = False) -> dict[str, Any]:
    inspection = inspect_archive(archive_path)
    with tempfile.TemporaryDirectory(prefix="verifier-release-verify-") as temporary:
        root = safe_extract(archive_path, Path(temporary))
        tree = verify_tree(root)
        seal_before = {
            MANIFEST_NAME: sha256_file(root / MANIFEST_NAME),
            CHECKSUMS_NAME: sha256_file(root / CHECKSUMS_NAME),
        }
        result: dict[str, Any] = {"ok": True, "archive": inspection, "tree": tree}
        if full:
            validation = full_validate(root)
            post_tree = verify_tree(root)
            seal_after = {
                MANIFEST_NAME: sha256_file(root / MANIFEST_NAME),
                CHECKSUMS_NAME: sha256_file(root / CHECKSUMS_NAME),
            }
            seal_unchanged = seal_before == seal_after
            validation["release_tree_seal_unchanged"] = seal_unchanged
            validation["ok"] = bool(validation["ok"] and seal_unchanged)
            result["full_validation"] = validation
            result["post_validation_tree"] = post_tree
            result["ok"] = validation["ok"]
        return result


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    try:
        result = verify_release(args.archive, full=args.full)
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as error:
        result = {"ok": False, "error": str(error)}
    if args.json or not result.get("ok"):
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stdout if result.get("ok") else sys.stderr)
    else:
        print(f"RELEASE VERIFIED: {result['archive']['archive']} sha256={result['archive']['sha256']}")
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
