# handoff.md - Verifier v0.0.2.2 Final Delivery

## 1. 交接结论

- 目标：面向 AI 软件开发的独立验收、复审与放行 Skill。
- 输入基线：`verifier-v2.2.0-final-installable(1).zip`，SHA-256 `44ea129aa8c55f65fb49ba7b7445af22259102760a3bf60a3286badf8e12a468`。
- 最终 Skill：`verifier/`，release `0.0.2.2`，evidence schema compatibility `2.1`。
- 交付裁决：`INSTALL_READY / PASS_WITH_DISCLOSED_LIMITATIONS`。
- 交付形态：唯一 ZIP；解压根目录固定为 `verifier-skill-v0.0.2.2`。

## 2. 产品定位

Verifier 是 fail-closed **decision kernel**，不是重复造一套扫描器、测试平台或 rollout 系统。它负责：

```text
冻结授权契约 → 锁定精确 Subject → 风险/命令计划 →
消费无裁决权 Adapter 结果 → 验证真实用户结果/world state →
Release/AI/隐私/证据门 → 两轮六视角复审 → 机械裁决与封存
```

成熟竞品继续作为执行器；只有 Verifier 负责跨域统一 verdict。

## 3. 本轮完成内容

1. 研究 84 项直接同类、成熟软件、开源框架、商业平台和权威标准，形成 Markdown/CSV 对比矩阵与来源登记。
2. 完成十轮实质性完善，覆盖版本身份、契约、风险规划、命令安全、证据、测试有效性、Adapter、Release/AI、独立复审和发布包安全。
3. 修复旧包 `install.py inspect` 文本模式 `KeyError`，统一全树版本为 `0.0.2.2`。
4. 增加六类机器强制 Adapter 契约：`static_analysis`、`test_execution`、`release_observation`、`ai_evaluation`、`supply_chain`、`human_manual`。
5. 增加确定性单根 ZIP builder 和解压前安全 verifier；拒绝 Zip Slip、绝对路径、反斜杠、重复/大小写冲突、symlink、特殊/加密成员、压缩炸弹和篡改。
6. 完成两轮 × 六视角对抗复审；Round 1 的六项实现缺陷全部关闭，Round 2 保留六项已披露边界，0 blocker。
7. 完成 75 项 Skill tests、14 项 installer tests、16 项 release-wrapper tests（合计 105），以及临时 `CODEX_HOME` 中的真实安装、幂等、卸载和回滚流程。
8. 最终硬化 installer/release：切换后失败清理或恢复旧版本、`--replace` 修复同 manifest 篡改安装、所有操作拒绝 symlink target root、NFC/Windows 路径门、builder 禁止输出到自身树、canonical ZIP 元数据、测试后 tree-seal 不变。

## 4. 竞品融合结论

- 单点明显更成熟的能力继续借用：AI PR review、SAST/AppSec、浏览器/API/契约测试、mutation/property/performance、渐进发布/混沌、AI eval/red-team、SBOM/provenance/signing。
- 吸收的机制包括 quality gate、changed-scope routing、isolated real execution、contract tests、test discrimination、canary/abort/bake、per-slice AI trials、SLSA/Sigstore/in-toto 风格身份与证明。
- 修复竞品的共同弱点：单域绿灯不能冒充整体放行、builder 自评不能当证据、模糊 branch/tag 不能当 Subject、warning/skipped 不得洗绿、外部工具不能直接写 verdict。
- 未发现有公开证据证明某个单体产品覆盖本 Skill 的完整端到端裁决链；这不是“全球缺陷召回率第一”的实验性证明。真正可验证目标是：覆盖面、fail-closed、证据绑定、可复跑、负向防御和低歧义安装。

## 5. 复审独立性

用户要求两轮各六个 SubAgent。当前运行环境没有独立 SubAgent dispatcher，因此实际执行的是 12 个固定角色的隔离式 `role_separated_same_model` 复审：

- `true_subagent_count = 0`
- 不声称 `six independent agents`
- critical 正向结论仍需真实不同模型/上下文/人工 reviewer 在同一不可变 Subject 上独立复核

机器记录位于 `reports/internal_review/`。

## 6. 已知边界

- SHA-256 证明 bytes 一致，不证明发布者身份；高保证环境应接 Sigstore/SLSA 或可信 builder provenance。
- 命令日志不能证明操作系统层没有绕过；critical 环境需要 sandbox/audit/EDR Adapter。
- 通用 Skill 不内置每个平台的真实 production access；web/API/Kubernetes/desktop/AI 项目仍需授权 Adapter。
- secret/PII 检测是启发式；高敏项目应使用 DLP 和私有 evidence root。
- 75 项工具测试证明机器规则与负向防御，不等于真实项目缺陷召回率；下一基准应是 golden defective projects + mutation corpus。

## 7. Codex 唯一职责

Codex 不开发、不修改本包。只需：

1. 先用最终交付消息中的 SHA-256 核对唯一 ZIP，再原样解压/落库；
2. 执行 `inspect → install → verify --selftest`；
3. commit、push、PR/merge 和备份；
4. 异常时只回报事实、日志、路径和链接，不自行修复。

## 8. 文件导航

- 安装：`README_FIRST.md`, `install.py`
- Skill：`verifier/`
- 竞品：`reports/COMPETITOR_MATRIX.md`, `reports/COMPETITOR_MATRIX.csv`
- 来源：`reports/SOURCE_REGISTRY.md`
- 十轮完善：`reports/TEN_ROUND_CHANGELOG.md`
- 两轮复审：`reports/SIX_LENS_REVIEW_ROUND_1.md`, `reports/SIX_LENS_REVIEW_ROUND_2.md`, `reports/internal_review/`
- 验证：`reports/VALIDATION_REPORT.md`, `reports/validation_logs/`
- 盲点：`reports/BLIND_SPOTS_AND_SURPRISE.md`
- PDF：`reports/Verifier_v0.0.2.2_Research_and_Validation.pdf`
- Codex 落库任务：`Codex_Task_Pack_v0.0.0.1/`
