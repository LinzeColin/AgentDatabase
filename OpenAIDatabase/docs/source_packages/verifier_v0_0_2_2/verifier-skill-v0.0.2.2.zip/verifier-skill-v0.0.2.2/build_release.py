#!/usr/bin/env python3
"""Build a deterministic, single-root Verifier v0.0.2.2 release ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import unicodedata
import zipfile
from pathlib import Path
from typing import Any, Optional

DELIVERY_NAME = "verifier-skill-v0.0.2.2"
SKILL_VERSION = "0.0.2.2"
MANIFEST_NAME = "DELIVERY_MANIFEST.json"
CHECKSUMS_NAME = "SHA256SUMS.txt"
FIXED_ZIP_TIME = (2026, 7, 25, 0, 0, 0)
CACHE_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
CACHE_SUFFIXES = {".pyc", ".pyo"}
FORBIDDEN_NAMES = {".DS_Store", "Thumbs.db"}
MAX_FILES = 10_000
MAX_TOTAL_BYTES = 1024 * 1024 * 1024
WINDOWS_RESERVED = {
    "con", "prn", "aux", "nul",
    *(f"com{index}" for index in range(1, 10)),
    *(f"lpt{index}" for index in range(1, 10)),
}
WINDOWS_FORBIDDEN_CHARS = set('<>:"|?*')
MAX_PATH_COMPONENT_BYTES = 255
MAX_RELATIVE_PATH_BYTES = 1024


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _cache_path(relative: Path) -> bool:
    return bool(set(relative.parts) & CACHE_DIRS) or relative.suffix in CACHE_SUFFIXES or relative.name in FORBIDDEN_NAMES


def _portable_key(rel: str) -> str:
    if len(rel.encode("utf-8")) > MAX_RELATIVE_PATH_BYTES:
        raise ValueError(f"release path exceeds portable length: {rel!r}")
    path = Path(rel)
    for part in path.parts:
        if unicodedata.normalize("NFC", part) != part:
            raise ValueError(f"release path must be NFC-normalized: {rel!r}")
        if len(part.encode("utf-8")) > MAX_PATH_COMPONENT_BYTES:
            raise ValueError(f"release path component exceeds portable length: {part!r}")
        if part.endswith((" ", ".")):
            raise ValueError(f"release path has trailing space/dot: {rel!r}")
        if any(ord(ch) < 32 or ch in WINDOWS_FORBIDDEN_CHARS for ch in part):
            raise ValueError(f"release path is Windows-incompatible: {rel!r}")
        if part.split(".", 1)[0].casefold() in WINDOWS_RESERVED:
            raise ValueError(f"release path uses Windows-reserved component: {rel!r}")
    return unicodedata.normalize("NFC", rel).casefold()


def _safe_relative(relative: Path) -> str:
    rel = relative.as_posix()
    if relative.is_absolute() or not relative.parts or any(part in {"", ".", ".."} for part in relative.parts):
        raise ValueError(f"unsafe release path: {rel!r}")
    if "\\" in rel or "\x00" in rel:
        raise ValueError(f"non-portable release path: {rel!r}")
    _portable_key(rel)
    return rel


def collect_files(root: Path, excludes: set[str] | None = None) -> list[Path]:
    excludes = excludes or set()
    if root.name != DELIVERY_NAME:
        raise ValueError(f"release root must be named {DELIVERY_NAME}: {root}")
    if root.is_symlink() or not root.is_dir():
        raise ValueError("release root must be a real directory")
    files: list[Path] = []
    folded: dict[str, str] = {}
    total = 0
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix().casefold()):
        relative = path.relative_to(root)
        rel = _safe_relative(relative)
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise ValueError(f"symlink forbidden in release: {rel}")
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode):
            raise ValueError(f"non-regular entry forbidden in release: {rel}")
        if _cache_path(relative):
            raise ValueError(f"cache/platform artifact forbidden in release: {rel}")
        if rel in excludes:
            continue
        key = _portable_key(rel)
        if key in folded and folded[key] != rel:
            raise ValueError(f"case-colliding release paths: {folded[key]} / {rel}")
        folded[key] = rel
        total += path.stat().st_size
        files.append(path)
        if len(files) > MAX_FILES or total > MAX_TOTAL_BYTES:
            raise ValueError("release exceeds safety limits")
    return files


def run_inner_manifest_build(root: Path) -> None:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = "0"
    proc = subprocess.run(
        [sys.executable, "-B", "scripts/verify_distribution.py", "build", ".", "--json"],
        cwd=root / "verifier",
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
        timeout=180,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"inner skill manifest build failed: {proc.stderr or proc.stdout}")


def write_outer_integrity(root: Path) -> dict[str, Any]:
    entries = []
    for path in collect_files(root, {MANIFEST_NAME, CHECKSUMS_NAME}):
        entries.append({
            "path": path.relative_to(root).as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        })
    manifest = {
        "schema_version": "1.0",
        "delivery_name": DELIVERY_NAME,
        "skill_name": "verifier",
        "skill_version": SKILL_VERSION,
        "generated_at": "deterministic-build",
        "hash_algorithm": "sha256",
        "excludes": [MANIFEST_NAME, CHECKSUMS_NAME],
        "entries": entries,
    }
    (root / MANIFEST_NAME).write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    checksum_files = collect_files(root, {CHECKSUMS_NAME})
    lines = [f"{sha256_file(path)}  {path.relative_to(root).as_posix()}" for path in checksum_files]
    (root / CHECKSUMS_NAME).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"manifest_entries": len(entries), "checksum_entries": len(lines)}


def _zip_mode(path: Path) -> int:
    try:
        executable = bool(path.stat().st_mode & stat.S_IXUSR)
    except OSError:
        executable = False
    if path.suffix == ".py" and path.read_bytes().startswith(b"#!"):
        executable = True
    return 0o755 if executable else 0o644


def write_deterministic_zip(root: Path, output: Path) -> dict[str, Any]:
    output = output.expanduser().absolute()
    output.parent.mkdir(parents=True, exist_ok=True)
    files = collect_files(root)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent)
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as archive:
            for path in files:
                rel = path.relative_to(root).as_posix()
                member = f"{DELIVERY_NAME}/{rel}"
                info = zipfile.ZipInfo(member, date_time=FIXED_ZIP_TIME)
                info.create_system = 3
                info.flag_bits = 0x800
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = (_zip_mode(path) & 0xFFFF) << 16
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return {
        "ok": True,
        "output": str(output),
        "sha256": sha256_file(output),
        "size": output.stat().st_size,
        "members": len(files),
        "root": DELIVERY_NAME,
    }


def build(root: Path, output: Path) -> dict[str, Any]:
    raw_root = Path(os.path.abspath(os.fspath(root.expanduser())))
    if raw_root.is_symlink():
        raise ValueError("release root must not be a symlink")
    root = raw_root.resolve(strict=True)
    output_absolute = Path(os.path.abspath(os.fspath(output.expanduser())))
    try:
        output_absolute.relative_to(root)
    except ValueError:
        pass
    else:
        raise ValueError("release output must be outside the release root")
    run_inner_manifest_build(root)
    integrity = write_outer_integrity(root)
    result = write_deterministic_zip(root, output_absolute)
    result.update(integrity)
    return result


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    try:
        result = build(args.root, args.output)
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as error:
        result = {"ok": False, "error": str(error)}
    if args.json or not result.get("ok"):
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stdout if result.get("ok") else sys.stderr)
    else:
        print(f"RELEASE BUILT: {result['output']} sha256={result['sha256']}")
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
