#!/usr/bin/env python3
"""Atomic installer, verifier, uninstaller and rollback utility for Verifier v0.0.2.2."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import unicodedata
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

SKILL_NAME = "verifier"
SKILL_VERSION = "0.0.2.2"
BACKUP_DIR_NAME = ".verifier-backups"
CACHE_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
CACHE_SUFFIXES = {".pyc", ".pyo"}
MAX_MANIFEST_BYTES = 10 * 1024 * 1024
MAX_SKILL_FILES = 10_000
MAX_SKILL_BYTES = 1024 * 1024 * 1024
WINDOWS_RESERVED = {
    "con", "prn", "aux", "nul",
    *(f"com{index}" for index in range(1, 10)),
    *(f"lpt{index}" for index in range(1, 10)),
}
WINDOWS_FORBIDDEN_CHARS = set('<>:"|?*')
MAX_PATH_COMPONENT_BYTES = 255
MAX_RELATIVE_PATH_BYTES = 1024


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def absolute_no_resolve(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(path.expanduser())))


def package_root() -> Path:
    return absolute_no_resolve(Path(__file__)).parent


def source_skill() -> Path:
    return package_root() / SKILL_NAME


def resolve_target_root(
    surface: str,
    target_root: Optional[Path] = None,
    project_root: Optional[Path] = None,
) -> Path:
    if target_root is not None and project_root is not None:
        raise ValueError("use either --target-root or --project-root, not both")
    if target_root is not None:
        return absolute_no_resolve(target_root)
    if project_root is not None:
        project = absolute_no_resolve(project_root)
        assert_directory_not_symlink(project, "project root")
        if not project.is_dir():
            raise ValueError(f"project root is not a directory: {project}")
        return project / (".codex/skills" if surface == "codex" else ".agents/skills")
    if surface == "codex":
        codex_home = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))).expanduser()
        return absolute_no_resolve(codex_home) / "skills"
    return absolute_no_resolve(Path.home() / ".agents" / "skills")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f"duplicate JSON key in MANIFEST.json: {key}")
        value[key] = item
    return value


def _cache_path(relative: Path) -> bool:
    return bool(set(relative.parts) & CACHE_DIRS) or relative.suffix in CACHE_SUFFIXES


def _portable_path_key(raw: str, label: str) -> str:
    if len(raw.encode("utf-8")) > MAX_RELATIVE_PATH_BYTES:
        raise ValueError(f"{label} exceeds portable path length")
    path = Path(raw)
    for part in path.parts:
        if unicodedata.normalize("NFC", part) != part:
            raise ValueError(f"non-NFC {label}: {raw!r}")
        if len(part.encode("utf-8")) > MAX_PATH_COMPONENT_BYTES:
            raise ValueError(f"{label} component exceeds portable length: {part!r}")
        if part.endswith((" ", ".")):
            raise ValueError(f"non-portable trailing space/dot in {label}: {raw!r}")
        if any(ord(ch) < 32 or ch in WINDOWS_FORBIDDEN_CHARS for ch in part):
            raise ValueError(f"Windows-incompatible character in {label}: {raw!r}")
        stem = part.split(".", 1)[0].casefold()
        if stem in WINDOWS_RESERVED:
            raise ValueError(f"Windows-reserved component in {label}: {raw!r}")
    return unicodedata.normalize("NFC", raw).casefold()


def _safe_manifest_path(raw: Any, label: str) -> str:
    if not isinstance(raw, str) or not raw or "\x00" in raw or "\\" in raw:
        raise ValueError(f"unsafe {label}: {raw!r}")
    path = Path(raw)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"unsafe {label}: {raw!r}")
    rel = path.as_posix()
    _portable_path_key(rel, label)
    return rel


def _independent_files(root: Path, mode: str, excludes: set[str]) -> dict[str, tuple[int, str]]:
    if mode not in {"distribution", "installed"}:
        raise ValueError(f"invalid validation mode: {mode}")
    root = absolute_no_resolve(root)
    if not root.exists():
        raise FileNotFoundError(f"skill root does not exist: {root}")
    if stat.S_ISLNK(root.lstat().st_mode):
        raise ValueError(f"skill root must not be a symlink: {root}")
    if not root.is_dir():
        raise ValueError(f"skill root is not a directory: {root}")
    result: dict[str, tuple[int, str]] = {}
    folded: dict[str, str] = {}
    total = 0
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix().casefold()):
        relative = path.relative_to(root)
        rel = relative.as_posix()
        mode_bits = path.lstat().st_mode
        if stat.S_ISLNK(mode_bits):
            raise ValueError(f"symlink forbidden in skill payload: {rel}")
        if stat.S_ISDIR(mode_bits):
            continue
        if not stat.S_ISREG(mode_bits):
            raise ValueError(f"non-regular entry forbidden in skill payload: {rel}")
        if _cache_path(relative):
            if mode == "distribution":
                raise ValueError(f"runtime cache forbidden in distribution: {rel}")
            continue
        if rel in excludes:
            continue
        _safe_manifest_path(rel, "payload path")
        key = _portable_path_key(rel, "payload path")
        if key in folded and folded[key] != rel:
            raise ValueError(f"case-colliding payload paths: {folded[key]} / {rel}")
        folded[key] = rel
        size = path.stat().st_size
        total += size
        if len(result) >= MAX_SKILL_FILES or total > MAX_SKILL_BYTES:
            raise ValueError("skill payload exceeds installer safety limits")
        result[rel] = (size, sha256_file(path))
    return result


def _parse_checksum_file(path: Path) -> dict[str, str]:
    if path.stat().st_size > MAX_MANIFEST_BYTES:
        raise ValueError("SHA256SUMS.txt exceeds safety limit")
    result: dict[str, str] = {}
    folded: dict[str, str] = {}
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line or "  " not in line:
            raise ValueError(f"SHA256SUMS.txt:{number}: invalid format")
        digest, raw = line.split("  ", 1)
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError(f"SHA256SUMS.txt:{number}: invalid digest")
        rel = _safe_manifest_path(raw, f"SHA256SUMS.txt:{number} path")
        if rel in result:
            raise ValueError(f"SHA256SUMS.txt:{number}: duplicate path {rel}")
        key = _portable_path_key(rel, f"SHA256SUMS.txt:{number} path")
        if key in folded and folded[key] != rel:
            raise ValueError(f"SHA256SUMS.txt case collision: {folded[key]} / {rel}")
        folded[key] = rel
        result[rel] = digest
    return result


def verify_payload_without_execution(root: Path, mode: str) -> dict[str, Any]:
    root = absolute_no_resolve(root)
    manifest_path = root / "MANIFEST.json"
    sums_path = root / "SHA256SUMS.txt"
    version_path = root / "VERSION"
    for path in (manifest_path, sums_path, version_path, root / "SKILL.md"):
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"missing or unsafe required payload file: {path.name}")
    if manifest_path.stat().st_size > MAX_MANIFEST_BYTES:
        raise ValueError("MANIFEST.json exceeds safety limit")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"), object_pairs_hook=_no_duplicate_keys)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as error:
        raise ValueError(f"invalid MANIFEST.json: {error}") from error
    if not isinstance(manifest, dict):
        raise ValueError("MANIFEST.json root must be an object")
    version = version_path.read_text(encoding="utf-8").strip()
    if version != SKILL_VERSION or manifest.get("skill") != SKILL_NAME or manifest.get("skill_version") != version:
        raise ValueError("payload skill/version identity mismatch")
    expected_list = manifest.get("entries")
    if not isinstance(expected_list, list):
        raise ValueError("MANIFEST.json entries must be a list")
    expected: dict[str, tuple[int, str]] = {}
    folded: dict[str, str] = {}
    for index, item in enumerate(expected_list):
        if not isinstance(item, dict):
            raise ValueError(f"MANIFEST.json entries[{index}] must be an object")
        rel = _safe_manifest_path(item.get("path"), f"MANIFEST.json entries[{index}].path")
        size = item.get("size")
        digest = item.get("sha256")
        if isinstance(size, bool) or not isinstance(size, int) or size < 0 or not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError(f"MANIFEST.json entries[{index}] has invalid size/hash")
        if rel in expected:
            raise ValueError(f"MANIFEST.json duplicate path: {rel}")
        key = _portable_path_key(rel, f"MANIFEST.json entries[{index}].path")
        if key in folded and folded[key] != rel:
            raise ValueError(f"MANIFEST.json case collision: {folded[key]} / {rel}")
        folded[key] = rel
        expected[rel] = (size, digest)
    actual = _independent_files(root, mode, {"MANIFEST.json", "SHA256SUMS.txt"})
    if expected != actual:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        changed = sorted(rel for rel in set(expected) & set(actual) if expected[rel] != actual[rel])
        raise ValueError(f"payload manifest mismatch: missing={missing[:5]} extra={extra[:5]} changed={changed[:5]}")
    expected_sums = _parse_checksum_file(sums_path)
    actual_sums = {rel: digest for rel, (_size, digest) in _independent_files(root, mode, {"SHA256SUMS.txt"}).items()}
    if expected_sums != actual_sums:
        missing = sorted(set(expected_sums) - set(actual_sums))
        extra = sorted(set(actual_sums) - set(expected_sums))
        changed = sorted(rel for rel in set(expected_sums) & set(actual_sums) if expected_sums[rel] != actual_sums[rel])
        raise ValueError(f"payload checksum mismatch: missing={missing[:5]} extra={extra[:5]} changed={changed[:5]}")
    return {"ok": True, "root": str(root), "mode": mode, "files": len(actual), "version": version}


def run_checked(argv: list[str], cwd: Path, timeout: int = 240) -> dict[str, Any]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = "0"
    try:
        proc = subprocess.run(
            argv,
            cwd=cwd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=timeout,
            env=env,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        raise RuntimeError(f"command failed to start: {argv!r}: {error}") from error
    result = {
        "argv": argv,
        "returncode": proc.returncode,
        "stdout": proc.stdout[-20_000:],
        "stderr": proc.stderr[-20_000:],
    }
    if proc.returncode != 0:
        raise RuntimeError(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def validate_skill(root: Path, mode: str, selftest: bool = False) -> list[dict[str, Any]]:
    root = absolute_no_resolve(root)
    independent = verify_payload_without_execution(root, mode)
    steps = [{"independent_verification": independent},
        run_checked([sys.executable, "-B", "scripts/validate_pack.py", ".", "--mode", mode, "--json"], root),
        run_checked([sys.executable, "-B", "scripts/verify_distribution.py", "verify", ".", "--mode", mode, "--json"], root),
    ]
    if selftest:
        steps.append(run_checked([sys.executable, "-B", "scripts/run_selftest.py", "--repeat", "1", "--json"], root))
    return steps


def manifest_digest(root: Path) -> str:
    manifest = root / "MANIFEST.json"
    checksums = root / "SHA256SUMS.txt"
    if not manifest.is_file() or not checksums.is_file():
        return "unverified"
    digest = hashlib.sha256()
    digest.update(manifest.read_bytes())
    digest.update(checksums.read_bytes())
    return digest.hexdigest()[:16]


def assert_directory_not_symlink(path: Path, label: str) -> None:
    absolute = absolute_no_resolve(path)
    current = Path(absolute.anchor)
    parts = absolute.parts[1:] if absolute.anchor else absolute.parts
    for part in parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"{label} contains a symlink component: {current}")
        if not current.exists():
            break


def copy_skill_strict(source: Path, destination: Path) -> None:
    if destination.exists():
        raise FileExistsError(f"destination exists: {destination}")
    destination.mkdir(parents=False)
    try:
        for path in sorted(source.rglob("*"), key=lambda p: p.relative_to(source).as_posix().casefold()):
            relative = path.relative_to(source)
            out = destination / relative
            mode = path.lstat().st_mode
            if stat.S_ISLNK(mode):
                raise ValueError(f"symlink forbidden in source skill: {relative.as_posix()}")
            if stat.S_ISDIR(mode):
                out.mkdir()
            elif stat.S_ISREG(mode):
                out.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, out)
            else:
                raise ValueError(f"non-regular source entry: {relative.as_posix()}")
    except Exception:
        shutil.rmtree(destination, ignore_errors=True)
        raise


def same_distribution(left: Path, right: Path) -> bool:
    try:
        return (left / "MANIFEST.json").read_bytes() == (right / "MANIFEST.json").read_bytes() and (
            left / "SHA256SUMS.txt"
        ).read_bytes() == (right / "SHA256SUMS.txt").read_bytes()
    except OSError:
        return False


def backup_path(target_root: Path, target: Path, action: str) -> Path:
    backup_root = target_root / BACKUP_DIR_NAME
    assert_directory_not_symlink(backup_root, "backup root")
    backup_root.mkdir(parents=True, exist_ok=True)
    token = manifest_digest(target)
    candidate = backup_root / f"{utc_stamp()}-{action}-{token}"
    suffix = 1
    while candidate.exists():
        candidate = backup_root / f"{utc_stamp()}-{action}-{token}-{suffix}"
        suffix += 1
    return candidate


def install(
    target_root: Path,
    replace: bool = False,
    run_selftest: bool = True,
) -> dict[str, Any]:
    source = absolute_no_resolve(source_skill())
    validate_skill(source, "distribution", selftest=False)
    assert_directory_not_symlink(target_root, "target root")
    target_root.mkdir(parents=True, exist_ok=True)
    target = target_root / SKILL_NAME
    assert_directory_not_symlink(target, "installed skill")

    if target.exists() and same_distribution(source, target):
        try:
            validate_skill(target, "installed", selftest=run_selftest)
        except (OSError, ValueError, RuntimeError):
            if not replace:
                raise
        else:
            return {
                "ok": True,
                "action": "already-installed",
                "target": str(target),
                "version": SKILL_VERSION,
                "backup": None,
            }
    if target.exists() and not replace:
        raise FileExistsError(f"different verifier installation exists at {target}; re-run with --replace")

    target_existed = target.exists()
    stage = target_root / f".{SKILL_NAME}.stage-{uuid.uuid4().hex}"
    backup: Optional[Path] = None
    copy_skill_strict(source, stage)
    try:
        validate_skill(stage, "installed", selftest=False)
        if target.exists():
            backup = backup_path(target_root, target, "replace")
            target.replace(backup)
        try:
            stage.replace(target)
        except Exception:
            if backup is not None and backup.exists() and not target.exists():
                backup.replace(target)
            raise
        validate_skill(target, "installed", selftest=run_selftest)
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        if target.exists():
            if backup is not None and backup.exists():
                shutil.rmtree(target, ignore_errors=True)
                backup.replace(target)
            elif not target_existed:
                shutil.rmtree(target, ignore_errors=True)
        raise

    return {
        "ok": True,
        "action": "installed" if backup is None else "replaced",
        "target": str(target),
        "version": SKILL_VERSION,
        "backup": str(backup) if backup else None,
    }


def verify_install(target_root: Path, run_selftest: bool = False) -> dict[str, Any]:
    assert_directory_not_symlink(target_root, "target root")
    target = target_root / SKILL_NAME
    assert_directory_not_symlink(target, "installed skill")
    steps = validate_skill(target, "installed", selftest=run_selftest)
    return {
        "ok": True,
        "action": "verified",
        "target": str(target),
        "version": (target / "VERSION").read_text(encoding="utf-8").strip(),
        "steps": len(steps),
    }


def uninstall(target_root: Path, force: bool = False) -> dict[str, Any]:
    assert_directory_not_symlink(target_root, "target root")
    target = target_root / SKILL_NAME
    assert_directory_not_symlink(target, "installed skill")
    if not target.exists():
        return {"ok": True, "action": "already-absent", "target": str(target), "backup": None}
    if not force:
        validate_skill(target, "installed", selftest=False)
    backup = backup_path(target_root, target, "uninstall")
    target.replace(backup)
    return {"ok": True, "action": "uninstalled-to-backup", "target": str(target), "backup": str(backup)}


def list_backups(target_root: Path) -> list[Path]:
    assert_directory_not_symlink(target_root, "target root")
    root = target_root / BACKUP_DIR_NAME
    if not root.is_dir():
        return []
    assert_directory_not_symlink(root, "backup root")
    backups: list[Path] = []
    for path in root.iterdir():
        if path.is_dir() and not path.is_symlink() and (path / "SKILL.md").is_file():
            backups.append(path)
    return sorted(backups, key=lambda p: p.name, reverse=True)


def rollback(target_root: Path, backup: Optional[Path], replace_current: bool) -> dict[str, Any]:
    assert_directory_not_symlink(target_root, "target root")
    candidates = list_backups(target_root)
    if backup is None:
        if not candidates:
            raise FileNotFoundError("no verifier backup available")
        selected = candidates[0]
    else:
        selected = backup.expanduser().resolve(strict=True)
        expected_parent = (target_root / BACKUP_DIR_NAME).resolve()
        try:
            selected.relative_to(expected_parent)
        except ValueError as error:
            raise ValueError("backup must be inside the target root backup directory") from error
        if selected not in candidates:
            raise ValueError(f"not a valid verifier backup: {selected}")
    validate_skill(selected, "installed", selftest=False)

    target = target_root / SKILL_NAME
    assert_directory_not_symlink(target, "installed skill")
    current_backup: Optional[Path] = None
    if target.exists():
        if not replace_current:
            raise FileExistsError("current verifier exists; use --replace-current to preserve it as a backup")
        current_backup = backup_path(target_root, target, "pre-rollback")
        target.replace(current_backup)
    try:
        selected.replace(target)
        validate_skill(target, "installed", selftest=True)
    except Exception:
        if target.exists():
            target.replace(selected)
        if current_backup is not None and current_backup.exists():
            current_backup.replace(target)
        raise
    return {
        "ok": True,
        "action": "rolled-back",
        "target": str(target),
        "restored_backup": str(selected),
        "preserved_current": str(current_backup) if current_backup else None,
    }


def inspect_package(target_root: Path) -> dict[str, Any]:
    assert_directory_not_symlink(target_root, "target root")
    source = absolute_no_resolve(source_skill())
    validate_skill(source, "distribution", selftest=False)
    target = target_root / SKILL_NAME
    return {
        "ok": True,
        "action": "inspected",
        "package_root": str(package_root()),
        "source_skill": str(source),
        "skill_version": SKILL_VERSION,
        "source_manifest_sha256": sha256_file(source / "MANIFEST.json"),
        "target_root": str(target_root),
        "target": str(target),
        "installed": target.is_dir() and not target.is_symlink(),
        "same_distribution": target.is_dir() and same_distribution(source, target),
        "backups": [str(path) for path in list_backups(target_root)],
    }


def parse_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--surface", choices=("codex", "agents"), default="codex")
    parser.add_argument("--target-root", type=Path)
    parser.add_argument("--project-root", type=Path)
    parser.add_argument("--json", action="store_true")


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("inspect", "verify"):
        item = sub.add_parser(name)
        parse_common(item)
        if name == "verify":
            item.add_argument("--selftest", action="store_true")
    item = sub.add_parser("install")
    parse_common(item)
    item.add_argument("--replace", action="store_true")
    item.add_argument("--no-selftest", action="store_true")
    item = sub.add_parser("uninstall")
    parse_common(item)
    item.add_argument("--force", action="store_true")
    item = sub.add_parser("rollback")
    parse_common(item)
    item.add_argument("--backup", type=Path)
    item.add_argument("--replace-current", action="store_true")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    try:
        target_root = resolve_target_root(args.surface, args.target_root, args.project_root)
        if args.command == "inspect":
            result = inspect_package(target_root)
        elif args.command == "install":
            result = install(target_root, replace=args.replace, run_selftest=not args.no_selftest)
        elif args.command == "verify":
            result = verify_install(target_root, run_selftest=args.selftest)
        elif args.command == "uninstall":
            result = uninstall(target_root, force=args.force)
        else:
            result = rollback(target_root, args.backup, args.replace_current)
    except (OSError, ValueError, RuntimeError) as error:
        result = {"ok": False, "command": args.command, "error": str(error)}
    if args.json or not result.get("ok"):
        stream = sys.stdout if result.get("ok") else sys.stderr
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True), file=stream)
    else:
        print(f"{result['action']}: {result.get('target', '')}")
        if result.get("backup"):
            print(f"backup: {result['backup']}")
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
