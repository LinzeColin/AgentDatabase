# PRD - Verifier v0.0.2.2 原样落库、安装与验证

- Task Pack 版本：`v0.0.0.1`
- 类型：落库/安装/验证，不是开发任务
- 目标：把随包 `verifier/` 原子安装到指定 Codex/Agent Skills 根目录，并证明版本、完整性、自检、幂等、卸载/回滚边界符合交付。

## 范围

1. 原样保留 ZIP 或解压树；不重写格式、不重新生成内容。
2. 运行 delivery `inspect`、`install`、`verify --selftest`。
3. 按 Owner 指定仓库执行 commit、push、PR/merge 和备份。
4. 异常时只记录事实、日志、路径、链接；由 ChatGPT 继续修复。

## 非目标

- 不修改 `verifier/`、installer、reports、Task Pack 或被测项目；
- 不新增依赖、不重跑竞品研究、不改变验收规则；
- 不绕过 manifest/hash/symlink/unknown-file/backup-root 检查；
- 不把 `role_separated_same_model` 描述成独立 SubAgent。

## 成功结果

1. `inspect` 返回 source distribution valid，VERSION=`0.0.2.2`；
2. 目标为精确 `<skills-root>/verifier`，无半安装状态；
3. `verify --selftest` exit 0；
4. 重复安装同一分发保持幂等；
5. 记录 target、backup（如有）、VERSION、installed manifest SHA-256；
6. commit/push/PR/merge/backup 完成且链接可核验；
7. 最终回报精炼，不消耗额外 Agent token。
