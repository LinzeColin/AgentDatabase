# Codex 执行入口

本任务包只允许原样落库、安装、验证、commit/push/PR/merge 和备份；禁止开发或修改 Verifier。

先把 ZIP 的 SHA-256 与 ChatGPT 最终交付消息逐字比对；一致后解压。在交付根目录运行：

```bash
python3 -B install.py inspect --surface codex
python3 -B install.py install --surface codex
python3 -B install.py verify --surface codex --selftest
```

Owner 指定项目级安装时添加 `--project-root /absolute/path/to/project`；指定其他 skills 根目录时用 `--target-root /absolute/path/to/skills`。

只回报：`PASS|BLOCKED`、target、backup、VERSION、installed manifest SHA-256、commit/PR/merge/backup 链接；失败时附精确错误和 installer 给出的恢复命令，不粘贴无关日志。
