# Acceptance

| ID | Oracle | Evidence |
|---|---|---|
| AC-INSTALL-000 | ZIP SHA-256 与可信最终交付消息完全一致 | `shasum -a 256` output |
| AC-INSTALL-001 | ZIP 根目录精确为 `verifier-skill-v0.0.2.2`，交付树未被 Codex 修改 | file tree / git diff |
| AC-INSTALL-002 | `install.py inspect` exit 0，source distribution valid，VERSION=`0.0.2.2` | stdout/JSON |
| AC-INSTALL-003 | 目标为精确 `<skills-root>/verifier`，安装通过 atomic stage；post-switch 失败不会留下半安装目录 | target path + installer result |
| AC-INSTALL-004 | `verify --selftest` exit 0 | command result |
| AC-INSTALL-005 | 相同分发重复安装不产生内容漂移 | idempotent install result |
| AC-INSTALL-006 | MANIFEST 与全部 SHA-256 匹配；未知、篡改、symlink 输入被拒绝 | verify result |
| AC-INSTALL-007 | 替换已有版本时 backup 位于 installer 管理目录，rollback 边界可核验 | backup path / optional rollback result |
| AC-GIT-001 | 原样 commit/push/PR/merge/备份完成，无源码改写 | commit/PR/merge/backup links |
| AC-REPORT-001 | 最终只返回必要结论、路径、hash、链接和失败恢复命令 | final report |
