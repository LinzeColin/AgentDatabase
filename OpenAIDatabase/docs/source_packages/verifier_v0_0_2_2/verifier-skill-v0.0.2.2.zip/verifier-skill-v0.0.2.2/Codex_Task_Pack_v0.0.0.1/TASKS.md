# Tasks

1. 先把唯一交付 ZIP 的 SHA-256 与最终交付消息逐字比对；一致后解压，确认根目录为 `verifier-skill-v0.0.2.2`。
2. 在交付根运行 `python3 -B install.py inspect --surface codex`。
3. 按 Owner 指定 surface/project-root/target-root 安装；未指定时使用 Codex 用户默认目录。
4. 运行 `python3 -B install.py verify --surface codex --selftest`，参数必须与安装目标一致。
5. 可选地重复运行相同 install，确认 `already-installed`/幂等行为。
6. 原样落库并执行 commit、push、PR/merge 和备份。
7. 最终只报告 PASS/BLOCKED、target、backup、VERSION、manifest hash 与 Git 链接。

## 失败处理

- 不手工覆盖、不删校验文件、不修改源码“让测试通过”；
- installer 返回 backup 时，仅使用其受管理路径执行 rollback；
- 保存精确命令、exit code、stderr/stdout 摘要和相关路径；
- BLOCKED 后停止额外开发，把事实交回 ChatGPT。
