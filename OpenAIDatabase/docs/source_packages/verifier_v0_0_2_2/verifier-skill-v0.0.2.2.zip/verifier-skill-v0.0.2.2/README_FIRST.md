# Verifier v0.0.2.2 Final Delivery - 先看这里

这是一个完整、可直接安装的 AI 软件验收复审 Skill 交付包。默认只需三条安装命令，不需要 Codex 改代码、补依赖或重新设计。

## 0. 解压前先核对唯一 ZIP

```bash
shasum -a 256 "verifier skill v0.0.2.2.zip"
```

输出必须与最终交付消息中的 SHA-256 完全一致；不一致立即停止。唯一 ZIP 无法把自身最终哈希写入自身，因此该值必须来自可信交付消息。

## 1. 默认安装到 Codex 用户 Skill 目录

在解压后的 `verifier-skill-v0.0.2.2` 根目录运行：

```bash
python3 -B install.py inspect --surface codex
python3 -B install.py install --surface codex
python3 -B install.py verify --surface codex --selftest
```

默认目标：`${CODEX_HOME:-~/.codex}/skills/verifier`。

## 2. 安装到指定项目

```bash
cd /absolute/path/to/project
python3 -B /absolute/path/to/verifier-skill-v0.0.2.2/install.py install --surface codex --project-root .
python3 -B /absolute/path/to/verifier-skill-v0.0.2.2/install.py verify --surface codex --project-root . --selftest
```

目标：`<project>/.codex/skills/verifier`。

## 3. 其他安装面

Agent Skills 用户目录：

```bash
python3 -B install.py install --surface agents
python3 -B install.py verify --surface agents --selftest
```

显式 skills 根目录：

```bash
python3 -B install.py install --target-root /absolute/path/to/skills
python3 -B install.py verify --target-root /absolute/path/to/skills --selftest
```

`--target-root` 是 skills 根目录，最终安装位置始终为 `<target-root>/verifier`。

## 4. 回滚与卸载

安装替换已有版本时，输出会给出受管理的 backup 路径：

```bash
python3 -B install.py rollback --target-root /absolute/path/to/skills --backup /exact/managed/backup/path --replace-current
python3 -B install.py uninstall --target-root /absolute/path/to/skills
```

失败时不要手工覆盖目标目录；保持 fail-closed，使用 installer 给出的精确恢复命令。

## 5. 可选：验证整个交付 ZIP

在 ZIP 所在目录，用本包中的验证器执行：

```bash
python3 -B verifier-skill-v0.0.2.2/verify_release.py "verifier skill v0.0.2.2.zip" --full --json
```

在先核对可信 SHA-256 并取得脚本后，它会对原始 ZIP 执行解压前检查：路径穿越、绝对路径、反斜杠、重复/大小写冲突、非 NFC/Windows 不兼容路径、symlink、非常规 mode/timestamp/compression、特殊/加密条目、压缩炸弹和完整性篡改；随后运行全部 105 项回归，并在临时 `CODEX_HOME` 完成真实安装、幂等、卸载、回滚、自检和测试后 tree-seal 复核。

## 6. 安全与裁决不变量

- installer 先用自身代码核验 payload manifest 与 SHA-256，之后才允许执行 payload 脚本；
- staging 验证全部通过后才原子切换；切换后的验证失败时，新装会清除半安装目录，替换会恢复旧版本；
- verifier 不修改被测产品、Product-Design-Taskpack 或上游 Skill，不 commit/push，不替开发修复；
- 外部扫描、测试、发布与 AI-eval 工具只能提交无裁决权 Adapter 观察；
- `NOT_RUN`、`UNKNOWN`、`WAIVED`、`warning`、`skipped`、`partial` 不得洗成 PASS；
- target root 任一 symlink 组件、跨平台危险路径、非 canonical ZIP 元数据、包内自包含输出均 fail-closed；
- 当前两轮六视角复审为 `role_separated_same_model`，真实 SubAgent 数为 0，不虚报独立性。

## 7. 交付内容

- `verifier/`：最终可安装 Skill；
- `install.py`：检查、安装、验证、卸载、回滚；
- `build_release.py` / `verify_release.py`：确定性封装与安全验证；
- `delivery_tests/`：installer 与 release-wrapper 回归；
- `reports/`：84 项竞品矩阵、十轮完善、两轮六视角复审、验证日志与 PDF；
- `Codex_Task_Pack_v0.0.0.1/`：Codex 原样落库/安装任务包；
- `handoff.md`：完整交接；
- `DELIVERY_MANIFEST.json` / `SHA256SUMS.txt`：交付树完整性。
