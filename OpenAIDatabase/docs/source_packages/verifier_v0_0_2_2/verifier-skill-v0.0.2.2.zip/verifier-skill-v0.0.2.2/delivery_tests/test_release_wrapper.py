#!/usr/bin/env python3
"""Security and reproducibility tests for the outer release envelope."""

from __future__ import annotations

import importlib.util
import shutil
import sys
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


builder = load_module("verifier_release_builder", ROOT / "build_release.py")
verifier = load_module("verifier_release_verifier", ROOT / "verify_release.py")


class ReleaseWrapperTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix="verifier-release-tests-")
        cls.work = Path(cls.temporary.name)
        cls.valid = cls.work / "valid.zip"
        builder.build(ROOT, cls.valid)

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def rewrite(self, name: str, mutate) -> Path:
        output = self.work / name
        with zipfile.ZipFile(self.valid) as source, zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as target:
            for info in source.infolist():
                data = source.read(info)
                mutate(target, info, data)
        return output

    def test_valid_release_verifies(self):
        result = verifier.verify_release(self.valid, full=False)
        self.assertTrue(result["ok"])
        self.assertGreater(result["archive"]["members"], 100)

    def test_rebuild_is_byte_reproducible(self):
        second = self.work / "second.zip"
        first = builder.build(ROOT, self.valid)
        other = builder.build(ROOT, second)
        self.assertEqual(first["sha256"], other["sha256"])
        self.assertEqual(self.valid.read_bytes(), second.read_bytes())

    def test_path_traversal_member_is_rejected(self):
        output = self.work / "traversal.zip"
        shutil.copy2(self.valid, output)
        with zipfile.ZipFile(output, "a") as archive:
            archive.writestr(f"{verifier.DELIVERY_NAME}/../escape.txt", b"x")
        with self.assertRaisesRegex(ValueError, "unsafe"):
            verifier.inspect_archive(output)

    def test_absolute_member_is_rejected(self):
        output = self.work / "absolute.zip"
        shutil.copy2(self.valid, output)
        with zipfile.ZipFile(output, "a") as archive:
            archive.writestr("/absolute.txt", b"x")
        with self.assertRaisesRegex(ValueError, "unsafe"):
            verifier.inspect_archive(output)

    def test_backslash_member_is_rejected(self):
        output = self.work / "backslash.zip"
        shutil.copy2(self.valid, output)
        with zipfile.ZipFile(output, "a") as archive:
            archive.writestr(verifier.DELIVERY_NAME + "\\escape.txt", b"x")
        with self.assertRaisesRegex(ValueError, "unsafe"):
            verifier.inspect_archive(output)

    def test_duplicate_member_is_rejected(self):
        output = self.work / "duplicate.zip"
        shutil.copy2(self.valid, output)
        member = f"{verifier.DELIVERY_NAME}/README_FIRST.md"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with zipfile.ZipFile(output, "a") as archive:
                archive.writestr(member, b"duplicate")
        with self.assertRaisesRegex(ValueError, "duplicate ZIP member"):
            verifier.inspect_archive(output)

    def test_case_collision_is_rejected(self):
        output = self.work / "case.zip"
        shutil.copy2(self.valid, output)
        with zipfile.ZipFile(output, "a") as archive:
            archive.writestr(f"{verifier.DELIVERY_NAME}/readme_first.md", b"x")
        with self.assertRaisesRegex(ValueError, "case-colliding"):
            verifier.inspect_archive(output)

    def test_symlink_member_is_rejected(self):
        output = self.work / "symlink.zip"
        shutil.copy2(self.valid, output)
        info = zipfile.ZipInfo(f"{verifier.DELIVERY_NAME}/evil-link")
        info.create_system = 3
        info.external_attr = (0o120777 & 0xFFFF) << 16
        with zipfile.ZipFile(output, "a") as archive:
            archive.writestr(info, b"../../outside")
        with self.assertRaisesRegex(ValueError, "symlink"):
            verifier.inspect_archive(output)

    def test_wrong_root_member_is_rejected(self):
        output = self.work / "wrong-root.zip"
        shutil.copy2(self.valid, output)
        with zipfile.ZipFile(output, "a") as archive:
            archive.writestr("other-root/file.txt", b"x")
        with self.assertRaisesRegex(ValueError, "outside exact root"):
            verifier.inspect_archive(output)

    def test_tampered_payload_fails_outer_manifest(self):
        member = f"{verifier.DELIVERY_NAME}/README_FIRST.md"

        def mutate(target, info, data):
            if info.filename == member:
                data += b"\ntampered\n"
            target.writestr(info, data)

        output = self.rewrite("tampered.zip", mutate)
        with self.assertRaisesRegex(ValueError, "manifest mismatch"):
            verifier.verify_release(output, full=False)

    def test_duplicate_manifest_json_key_is_rejected(self):
        member = f"{verifier.DELIVERY_NAME}/{verifier.MANIFEST_NAME}"

        def mutate(target, info, data):
            if info.filename == member:
                text = data.decode("utf-8")
                text = text.replace('{\n  "delivery_name"', '{\n  "schema_version": "1.0",\n  "delivery_name"', 1)
                data = text.encode("utf-8")
            target.writestr(info, data)

        output = self.rewrite("duplicate-key.zip", mutate)
        with self.assertRaisesRegex(ValueError, "duplicate JSON key"):
            verifier.verify_release(output, full=False)

    def test_compression_ratio_limit_is_enforced(self):
        output = self.work / "ratio.zip"
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr(f"{verifier.DELIVERY_NAME}/huge.txt", b"A" * 100_000)
        original = verifier.MAX_COMPRESSION_RATIO
        verifier.MAX_COMPRESSION_RATIO = 2
        try:
            with self.assertRaisesRegex(ValueError, "compression ratio"):
                verifier.inspect_archive(output)
        finally:
            verifier.MAX_COMPRESSION_RATIO = original


    def test_builder_rejects_output_inside_root_and_symlink_root(self):
        with self.assertRaisesRegex(ValueError, "outside the release root"):
            builder.build(ROOT, ROOT / "nested-release.zip")
        if hasattr(Path, "symlink_to"):
            link = self.work / builder.DELIVERY_NAME
            try:
                link.symlink_to(ROOT, target_is_directory=True)
            except OSError:
                return
            with self.assertRaisesRegex(ValueError, "must not be a symlink"):
                builder.build(link, self.work / "from-symlink.zip")

    def test_archive_symlink_is_rejected(self):
        link = self.work / "archive-link.zip"
        try:
            link.symlink_to(self.valid)
        except (OSError, NotImplementedError):
            self.skipTest("symlink unavailable")
        with self.assertRaisesRegex(ValueError, "must not be a symlink"):
            verifier.inspect_archive(link)

    def test_portable_path_hazards_are_rejected(self):
        hazards = [
            f"{verifier.DELIVERY_NAME}/cafe\u0301.txt",
            f"{verifier.DELIVERY_NAME}/CON",
            f"{verifier.DELIVERY_NAME}/aux.log",
            f"{verifier.DELIVERY_NAME}/trailing-dot.",
            f"{verifier.DELIVERY_NAME}/trailing-space ",
            f"{verifier.DELIVERY_NAME}/colon:name.txt",
        ]
        for index, member in enumerate(hazards):
            output = self.work / f"portable-{index}.zip"
            shutil.copy2(self.valid, output)
            with zipfile.ZipFile(output, "a") as archive:
                archive.writestr(member, b"x")
            with self.subTest(member=member):
                with self.assertRaises(ValueError):
                    verifier.inspect_archive(output)

    def test_noncanonical_zip_metadata_is_rejected(self):
        member = f"{verifier.DELIVERY_NAME}/README_FIRST.md"

        def mutate(target, info, data):
            if info.filename == member:
                info.external_attr = (0o600 & 0xFFFF) << 16
            target.writestr(info, data)

        output = self.rewrite("bad-mode.zip", mutate)
        with self.assertRaisesRegex(ValueError, "non-canonical ZIP mode"):
            verifier.inspect_archive(output)



if __name__ == "__main__":
    unittest.main(verbosity=2)
