#!/usr/bin/env python3
"""End-to-end tests for the Verifier delivery installer."""

from __future__ import annotations

import importlib.util
import os
import shutil
import subprocess
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent


def load_installer_from(root: Path, module_name: str = "verifier_delivery_installer"):
    spec = importlib.util.spec_from_file_location(module_name, root / "install.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load install.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


installer = load_installer_from(ROOT)


class InstallerTests(unittest.TestCase):
    def test_clean_install_verify_and_idempotence(self):
        with tempfile.TemporaryDirectory() as temporary:
            target_root = Path(temporary) / "skills"
            first = installer.install(target_root, run_selftest=False)
            self.assertEqual(first["action"], "installed")
            verified = installer.verify_install(target_root, run_selftest=True)
            self.assertTrue(verified["ok"])
            second = installer.install(target_root, run_selftest=False)
            self.assertEqual(second["action"], "already-installed")
            self.assertEqual((target_root / "verifier/VERSION").read_text().strip(), "0.0.2.2")

    def test_tamper_is_detected(self):
        with tempfile.TemporaryDirectory() as temporary:
            target_root = Path(temporary) / "skills"
            installer.install(target_root, run_selftest=False)
            skill = target_root / "verifier"
            (skill / "SKILL.md").write_text((skill / "SKILL.md").read_text() + "\ntampered\n", encoding="utf-8")
            with self.assertRaises((ValueError, RuntimeError)):
                installer.verify_install(target_root, run_selftest=False)

    def test_uninstall_to_backup_and_rollback(self):
        with tempfile.TemporaryDirectory() as temporary:
            target_root = Path(temporary) / "skills"
            installer.install(target_root, run_selftest=False)
            removed = installer.uninstall(target_root)
            self.assertEqual(removed["action"], "uninstalled-to-backup")
            self.assertFalse((target_root / "verifier").exists())
            restored = installer.rollback(target_root, backup=None, replace_current=False)
            self.assertEqual(restored["action"], "rolled-back")
            self.assertTrue((target_root / "verifier/SKILL.md").is_file())
            installer.verify_install(target_root, run_selftest=False)

    def test_surface_and_project_root_resolution(self):
        with tempfile.TemporaryDirectory() as temporary:
            project = Path(temporary)
            self.assertEqual(installer.resolve_target_root("codex", project_root=project), project / ".codex/skills")
            self.assertEqual(installer.resolve_target_root("agents", project_root=project), project / ".agents/skills")

    def test_source_tamper_is_rejected_before_payload_code_executes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            package = root / "package"
            shutil.copytree(ROOT, package)
            sentinel = package / "PAYLOAD_EXECUTED.txt"
            script = package / "verifier/scripts/validate_pack.py"
            original = script.read_text(encoding="utf-8")
            script.write_text(
                "from pathlib import Path\nPath(" + repr(str(sentinel)) + ").write_text('executed')\n" + original,
                encoding="utf-8",
            )
            copied = load_installer_from(package, "verifier_delivery_installer_tamper")
            with self.assertRaises(ValueError):
                copied.install(root / "skills", run_selftest=False)
            self.assertFalse(sentinel.exists())

    def test_independent_verifier_checks_manifest_and_checksums(self):
        result = installer.verify_payload_without_execution(ROOT / "verifier", "distribution")
        self.assertTrue(result["ok"])
        self.assertGreater(result["files"], 40)

    @unittest.skipIf(not hasattr(os, "symlink"), "symlink unavailable")
    def test_symlink_target_root_is_rejected_by_all_operations(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            real = root / "real"
            real.mkdir()
            link = root / "skills"
            link.symlink_to(real, target_is_directory=True)
            operations = [
                lambda: installer.install(link, run_selftest=False),
                lambda: installer.inspect_package(link),
                lambda: installer.verify_install(link, run_selftest=False),
                lambda: installer.uninstall(link),
                lambda: installer.list_backups(link),
                lambda: installer.rollback(link, backup=None, replace_current=False),
            ]
            for operation in operations:
                with self.subTest(operation=operation):
                    with self.assertRaises(ValueError):
                        operation()


    def test_text_mode_inspect_is_executable_interface(self):
        with tempfile.TemporaryDirectory() as temporary:
            env = dict(os.environ)
            env["CODEX_HOME"] = str(Path(temporary) / "codex-home")
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            proc = subprocess.run(
                [sys.executable, "-B", str(ROOT / "install.py"), "inspect", "--surface", "codex"],
                cwd=ROOT,
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
                timeout=120,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertIn("inspected:", proc.stdout)

    def test_json_inspect_has_stable_machine_contract(self):
        with tempfile.TemporaryDirectory() as temporary:
            env = dict(os.environ)
            env["CODEX_HOME"] = str(Path(temporary) / "codex-home")
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            proc = subprocess.run(
                [sys.executable, "-B", str(ROOT / "install.py"), "inspect", "--surface", "codex", "--json"],
                cwd=ROOT,
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
                timeout=120,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            result = json.loads(proc.stdout)
            self.assertEqual(result["action"], "inspected")
            self.assertEqual(result["skill_version"], "0.0.2.2")
            self.assertRegex(result["source_manifest_sha256"], r"^[0-9a-f]{64}$")

    def test_rollback_rejects_backup_outside_managed_directory(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            target_root = root / "skills"
            installer.install(target_root, run_selftest=False)
            outside = root / "outside"
            shutil.copytree(target_root / "verifier", outside)
            with self.assertRaises(ValueError):
                installer.rollback(target_root, backup=outside, replace_current=True)


    def test_fresh_post_switch_failure_removes_partial_install(self):
        with tempfile.TemporaryDirectory() as temporary:
            target_root = Path(temporary) / "skills"
            target = target_root / "verifier"
            original_validate = installer.validate_skill

            def controlled_validate(root, mode, selftest=False):
                if Path(root) == target:
                    raise RuntimeError("synthetic post-switch failure")
                return original_validate(Path(root), mode, selftest=False)

            with mock.patch.object(installer, "validate_skill", side_effect=controlled_validate):
                with self.assertRaisesRegex(RuntimeError, "post-switch"):
                    installer.install(target_root, run_selftest=False)
            self.assertFalse(target.exists())
            self.assertFalse(any(target_root.glob(".verifier.stage-*")))

    def test_replace_post_switch_failure_restores_previous_install(self):
        with tempfile.TemporaryDirectory() as temporary:
            target_root = Path(temporary) / "skills"
            installer.install(target_root, run_selftest=False)
            target = target_root / "verifier"
            marker = "\nPRESERVE_PREVIOUS_INSTALL\n"
            skill_md = target / "SKILL.md"
            skill_md.write_text(skill_md.read_text(encoding="utf-8") + marker, encoding="utf-8")
            original_validate = installer.validate_skill

            def controlled_validate(root, mode, selftest=False):
                if Path(root) == target:
                    raise RuntimeError("synthetic target validation failure")
                return original_validate(Path(root), mode, selftest=False)

            with mock.patch.object(installer, "validate_skill", side_effect=controlled_validate):
                with self.assertRaisesRegex(RuntimeError, "target validation"):
                    installer.install(target_root, replace=True, run_selftest=False)
            self.assertTrue(target.is_dir())
            self.assertIn(marker.strip(), skill_md.read_text(encoding="utf-8"))
            self.assertFalse(any(target_root.glob(".verifier.stage-*")))


    def test_replace_repairs_tampered_same_manifest_install(self):
        with tempfile.TemporaryDirectory() as temporary:
            target_root = Path(temporary) / "skills"
            installer.install(target_root, run_selftest=False)
            target = target_root / "verifier"
            skill_md = target / "SKILL.md"
            skill_md.write_text(skill_md.read_text(encoding="utf-8") + "\nTAMPERED\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                installer.verify_install(target_root, run_selftest=False)
            repaired = installer.install(target_root, replace=True, run_selftest=False)
            self.assertEqual(repaired["action"], "replaced")
            self.assertNotIn("TAMPERED", skill_md.read_text(encoding="utf-8"))
            installer.verify_install(target_root, run_selftest=False)

    def test_portable_payload_paths_reject_unicode_and_windows_hazards(self):
        unsafe = [
            "cafe\u0301.txt",
            "CON",
            "aux.log",
            "trailing-dot.",
            "trailing-space ",
            "colon:name.txt",
            "control\x01.txt",
        ]
        for raw in unsafe:
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    installer._safe_manifest_path(raw, "test path")



if __name__ == "__main__":
    unittest.main(verbosity=2)
