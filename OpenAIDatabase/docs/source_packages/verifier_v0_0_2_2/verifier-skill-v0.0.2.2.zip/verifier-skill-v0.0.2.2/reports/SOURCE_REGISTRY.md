# Source Registry

- 核验日期：2026-07-25。
- 原则：官方仓库、官方文档、标准正文优先；营销性能数字不作为硬证据。
- 竞品矩阵中的评分是本验收场景的架构适配判断，不代表供应商认证或实验 benchmark。

## 用户公开 GitHub 面核验

| 对象 | 官方 URL | 2026-07-25 可见范围 |
|---|---|---|
| LinzeColin profile/repositories | https://github.com/LinzeColin?tab=repositories | 公开仓库索引 7 个；Projects 页面显示 0。 |
| LinzeHomeHub | https://github.com/LinzeColin/LinzeHomeHub | 读取公开仓库入口、README 与根项目说明。 |
| MetaDatabase | https://github.com/LinzeColin/MetaDatabase | 读取公开仓库入口、根项目清单和版本治理说明。 |
| AgentDatabase | https://github.com/LinzeColin/AgentDatabase | 读取公开仓库入口、OpenAIDatabase/CodexSkills 等根目录项目面。 |
| CodexProject | https://github.com/LinzeColin/CodexProject | 读取公开仓库入口、治理和项目导航面。 |
| KMOS | https://github.com/LinzeColin/KMOS | 读取公开仓库入口和公开项目结构。 |
| NotionStudyProject | https://github.com/LinzeColin/NotionStudyProject | 读取公开仓库入口和 Study OS 架构说明。 |
| Archive | https://github.com/LinzeColin/Archive | 读取公开仓库入口和归档项目导航。 |

> 边界：网页方式核验了全部 7 个公开仓库入口与可见根项目面；没有声称逐字读取所有历史 commit、LFS、submodule 或每个嵌套文件。

## 竞品、执行器与标准一手来源

| 类别 | 项目 | 官方 URL | 本次使用边界 |
|---|---|---|
| 直接同类/规格治理 | Proof Loop | https://github.com/LeoStehlik/proof-loop | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 直接同类/规格治理 | Agile-V | https://github.com/Agile-V/agile_v_skills | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 直接同类/规格治理 | TLC Spec-Driven | https://github.com/tech-leads-club/agent-skills/blob/main/packages/skills-catalog/skills/(development)/tlc-spec-driven/SKILL.md | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 直接同类/规格治理 | GitHub Spec Kit | https://github.com/github/spec-kit | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 直接同类/规格治理 | OpenSpec | https://github.com/Fission-AI/OpenSpec | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 直接同类/规格治理 | Agent Skills Specification | https://agentskills.io/specification | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 直接同类/规格治理 | NIST SSDF | https://csrc.nist.gov/pubs/sp/800/218/final | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | Qodo Merge | https://docs.qodo.ai/qodo-documentation/code-review | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | CodeRabbit | https://docs.coderabbit.ai/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | Greptile | https://docs.greptile.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | GitHub Copilot code review | https://docs.github.com/en/copilot/concepts/agents/code-review | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | Graphite Reviewer | https://graphite.com/ai-code-review | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | Ellipsis | https://www.ellipsis.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI PR Review | Bito AI Code Review Agent | https://bito.ai/product/ai-code-review-agent/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | SonarQube | https://docs.sonarsource.com/sonarqube-server/quality-standards-administration/managing-quality-gates/introduction-to-quality-gates | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | Semgrep | https://semgrep.dev/docs/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | GitHub CodeQL | https://codeql.github.com/docs/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | Snyk Code | https://docs.snyk.io/scan-with-snyk/snyk-code | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | Codacy | https://docs.codacy.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | Trivy | https://trivy.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | OpenSSF Scorecard | https://scorecard.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | OSV-Scanner | https://google.github.io/osv-scanner/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 静态质量/AppSec | Checkmarx One | https://checkmarx.com/product/checkmarx-one/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Playwright | https://playwright.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Cypress | https://docs.cypress.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Selenium | https://www.selenium.dev/documentation/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Robot Framework | https://robotframework.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Cucumber | https://cucumber.io/docs/cucumber/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Testkube | https://docs.testkube.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | QA Wolf | https://www.qawolf.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | mabl | https://help.mabl.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Momentic | https://momentic.ai/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | testRigor | https://testrigor.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | BrowserStack | https://www.browserstack.com/docs | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Sauce Labs | https://docs.saucelabs.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试执行/QA 平台 | Applitools | https://applitools.com/docs/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 契约/集成/可观测测试 | Pact | https://docs.pact.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 契约/集成/可观测测试 | Schemathesis | https://schemathesis.readthedocs.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 契约/集成/可观测测试 | Dredd | https://dredd.org/en/latest/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 契约/集成/可观测测试 | Testcontainers | https://testcontainers.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 契约/集成/可观测测试 | Tracetest | https://tracetest.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | Stryker | https://stryker-mutator.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | mutmut | https://mutmut.readthedocs.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | Hypothesis | https://hypothesis.readthedocs.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | fast-check | https://fast-check.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | k6 | https://grafana.com/docs/k6/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | Locust | https://docs.locust.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 测试有效性/性能 | Apache JMeter | https://jmeter.apache.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 发布/韧性 | Argo Rollouts | https://argoproj.github.io/argo-rollouts/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 发布/韧性 | Flagger | https://docs.flagger.app/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 发布/韧性 | Chaos Mesh | https://chaos-mesh.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 发布/韧性 | LitmusChaos | https://litmuschaos.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 发布/韧性 | Gremlin | https://www.gremlin.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Promptfoo | https://www.promptfoo.dev/docs/intro/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | DeepEval | https://deepeval.com/docs/getting-started | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Inspect AI | https://inspect.aisi.org.uk/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | OpenAI Evals | https://github.com/openai/evals | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | LangSmith | https://docs.smith.langchain.com/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Braintrust | https://www.braintrust.dev/docs | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | W&B Weave | https://weave-docs.wandb.ai/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Arize Phoenix | https://arize.com/docs/phoenix | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Ragas | https://docs.ragas.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Giskard | https://docs.giskard.ai/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Garak | https://github.com/NVIDIA/garak | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | Microsoft PyRIT | https://github.com/Azure/PyRIT | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| AI/Agent Eval | TruLens | https://www.trulens.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | in-toto | https://in-toto.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | SLSA | https://slsa.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | Sigstore | https://docs.sigstore.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | GitHub Artifact Attestations | https://docs.github.com/en/actions/security-for-github-actions/using-artifact-attestations | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | GUAC | https://guac.sh/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | Syft + Grype | https://github.com/anchore/syft | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | CycloneDX | https://cyclonedx.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | SPDX | https://spdx.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | Conftest / OPA | https://www.conftest.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 供应链/政策门禁 | Kyverno | https://kyverno.io/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | NIST AI RMF | https://www.nist.gov/itl/ai-risk-management-framework | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | OWASP ASVS | https://owasp.org/www-project-application-security-verification-standard/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | OWASP SAMM | https://owaspsamm.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | OWASP Top 10 for LLM Applications | https://genai.owasp.org/llm-top-10/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | MITRE ATLAS | https://atlas.mitre.org/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | ISO/IEC 25010 | https://www.iso.org/standard/78176.html | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |
| 标准/治理 | OpenSSF Best Practices Badge | https://www.bestpractices.dev/ | 用于核验公开定位/机制；不采用未经独立验证的营销效果数字。 |

## 检索与证据限制

- 容器本身无法 bulk clone/API 遍历；使用可访问网页、官方文档和官方仓库页交叉核验。
- 公开页面可能更新；记录日期是 2026-07-25。
- 对付费商业产品没有执行统一真实缺陷 corpus，因此不宣称实际准确率排名。
