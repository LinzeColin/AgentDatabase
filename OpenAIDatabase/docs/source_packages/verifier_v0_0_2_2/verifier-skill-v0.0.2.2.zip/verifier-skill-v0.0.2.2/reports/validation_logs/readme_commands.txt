README exact install commands: PASS

python3 -B install.py inspect --surface codex
python3 -B install.py install --surface codex
python3 -B install.py verify --surface codex --selftest

Observed in an isolated temporary CODEX_HOME; see manual_install_flow.txt.
