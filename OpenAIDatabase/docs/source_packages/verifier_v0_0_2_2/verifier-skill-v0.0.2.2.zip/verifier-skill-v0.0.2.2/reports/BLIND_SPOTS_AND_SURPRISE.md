# 盲点、剩余风险与 Surprise

## 已扫清的高价值盲点

1. **Verifier 的安装命令本身也是产品接口。** `inspect` 的一个缺失字段会让首条 README 命令直接崩溃；现已纳入 text/JSON 回归。
2. **外部工具的 PASS 不是 Verifier 的 PASS。** Adapter 被永久剥离裁决权；warning/skipped/partial、timeout 和无证据结果不能洗绿。
3. **运行测试会改变被验证目录。** distribution 与 installed 模式必须区分 runtime cache，同时保持未知文件 fail-closed。
4. **ZIP 在代码运行前就是攻击面。** traversal、绝对路径、反斜杠、duplicate、case collision、symlink、special file、bomb 都必须先拒绝。
5. **哈希不等于 provenance。** 它只证明 bytes 一致；发布者身份与 trusted builder 要靠 Sigstore/SLSA/in-toto。
6. **六个角色不等于六个 SubAgent。** 独立性成为机器字段；同模型角色复审只能提高覆盖，不能满足 critical 双独立 gate。
7. **installer 的“原子切换”还必须覆盖切换后验证失败。** 新装必须删除半安装目录，替换必须恢复旧版本；同 manifest 但内容被篡改时，`--replace` 必须能修复。
8. **唯一 ZIP 存在 bootstrap trust。** 包不能自包含自身最终 SHA-256；因此解压前先比对可信交付消息中的 hash，之后再使用包内 verifier。
9. **跨平台污染不止大小写。** 非 NFC、Windows reserved name、尾随点/空格、危险字符和非 canonical ZIP metadata 均已进入 release/installer 门。
10. **“世界最好”需要可反证 benchmark。** 84 项功能矩阵能证明覆盖策略，不能证明真实 defect-detection recall 全球第一。

## 剩余风险与长期验证

| 风险 | 当前控制 | 进一步补强 |
|---|---|---|
| 无第三方签名 | trusted-message SHA-256、deterministic ZIP、双 manifest/SHA-256、tamper tests | Sigstore keyless signing、SLSA provenance、trusted CI builder |
| 真实缺陷召回率未知 | 75 Skill tests、negative canaries、mutation/discrimination 规则 | 跨语言 golden defective projects、长期 recall/false-positive trend |
| 同模型锚定 | 角色/round/失败模型分离，诚实标注 | 不同模型/上下文/人工 reviewer；审计 context IDs |
| Adapter Oracle 错误 | exact Subject、evidence hash、逐 claim Oracle、无 verdict authority | 每类 Adapter golden fixtures、双实现交叉验证 |
| 隐私漏检 | binary/oversize default deny、最小外发、retention | DLP、加密私有 evidence store、组织数据分级 policy |
| 生产不可复现 | environment/deployment fingerprint、scope 限制 | config attestation、可观测快照、release controller integration |

## Surprise

- **最强架构不是拥有最多工具，而是任何工具都不能越权。** 这比继续增加 scanner 更能减少错误放行。
- **BLOCKED 是高质量结果。** 身份、权限、Oracle、环境或独立性不足时，停止比生成似是而非 PASS 更节省总 token 和返工。
- **最省 Codex token 的不是少测试，而是一个机器真相。** JSON/hash/manifest、一个 ZIP、三条安装命令让 Codex 不需要重新设计和解释。
- **成熟竞品通常更窄。** Sonar、Playwright、Argo、Inspect、Sigstore 不是被替代，而是被置于一个更严格的授权与裁决链中。
