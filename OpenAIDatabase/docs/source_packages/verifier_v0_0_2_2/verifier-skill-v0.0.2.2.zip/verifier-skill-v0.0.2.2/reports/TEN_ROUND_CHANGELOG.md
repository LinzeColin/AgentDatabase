# Verifier v0.0.2.2 十轮完善记录

- 日期：2026-07-25
- 方法：每轮闭合“痛点 → 竞品机制 → 设计决策 → 机器门禁 → 回归测试 → 剩余风险”。
- 基线红线：builder/verifier 分离、单一精确 Subject、Taskpack 只读、真实执行、NOT_RUN/WAIVED/UNKNOWN 不得变 PASS、无授权不产生副作用、无独立性不虚报 SubAgent。

| 轮次 | 痛点与竞品启发 | 实现 | 机器验收 | 剩余风险 |
|---:|---|---|---|---|
| 1 | **统一定位与竞品反向工程。** Proof Loop/Agile-V/TLC 强在契约和独立验证；Sonar/Playwright/Argo/Inspect/Sigstore 各自在单点更成熟。 | 把产品收敛为 `fail-closed decision kernel + external adapters`；完成 84 项矩阵，拒绝复制所有执行器。 | `COMPETITOR_MATRIX.md/.csv`、`SOURCE_REGISTRY.md`；每项记录优势、缺口和融合方式。 | 未购买全部商业工具跑同一 corpus，评分不是实验 benchmark。 |
| 2 | **版本/契约歧义。** 旧包使用 `2.2.0`，用户要求 numeric-quad `0.0.2.2`；YAML/Markdown 多真相会漂移。 | 统一 release、installer、templates、tests 与 Task Pack 为 `0.0.2.2`；JSON 是机器真相；保留 evidence schema 2.1 兼容键 `assurance_v22`。 | `VERSION`、manifest、installer 常量和 positive-verdict gate 必须一致。 | 旧 evidence consumer 仍需兼容测试。 |
| 3 | **风险发现与计划依赖 Agent 自由发挥。** 借鉴 V-Model、SSDF、ASVS 的结构化控制。 | `doctor.py` 只读发现语言/CI/迁移/权限/AI/发布信号；`plan_acceptance.py` 生成 risk/depth/scope、预算、blocking unknowns。 | Positive verdict 绑定 capability/plan 哈希；高风险信号自动升级。 | 启发式可能漏报，关键域仍需 Owner/专家补充。 |
| 4 | **命令、网络、费用和副作用越权。** 竞品执行能力越强，越需要独立 authority gate。 | `command_guard.py` 使用 exact argv、allowlist、cwd、预算、网络/凭据/side-effect 分类和 abort 条件；禁止 `shell=True`。 | 未授权命令、预算超限、记录缺失均阻断；仓库指令按 untrusted data 处理。 | 仅凭命令日志不能证明 OS 外部进程从未绕过，critical 环境需 sandbox/audit。 |
| 5 | **源码、artifact 与 deployment 混同；安装器可能让 payload 自证。** 吸收 SLSA/in-toto/Sigstore 的身份链。 | 强制 `source snapshot → build → artifact/image → deployment`；区分 hash-only/signed/trusted builder；installer 先用自身代码独立核验 payload。 | 篡改 payload 或校验脚本在执行 payload 前被拒；release scope 必须绑定不可变 digest。 | 本包没有第三方签名，SHA-256 只证明一致性。 |
| 6 | **绿测试不代表测试能抓错；重试可洗绿。** 借鉴 Stryker/Hypothesis/fast-check。 | discrimination gate：mutation/property/fault/counterexample；flake 账本、clean-state 复跑、retry 保留首次失败；repeat-2 selftest。 | surviving mutant/失效 Oracle 形成 finding；共享状态不可产生正向结论。 | 通用 Skill 不自动生成所有语言的高质量 mutation corpus。 |
| 7 | **外部工具状态污染最终 verdict。** AI reviewer、quality gate、test platform 常输出各自的“pass/warn/skipped”。 | 新增六类统一 Adapter 契约和 `normalize_adapter_result.py`；绑定 Subject、argv、显式映射、证据 SHA-256、逐 claim Oracle；`decision_authority=none`。 | 26 项 Adapter contract tests；直接 verdict、warning/skipped/partial→PASS、timeout PASS、无证据 PASS、总体 PASS 掩盖失败均拒绝。 | Adapter 仍可能用错误 Oracle；需要 golden adapter fixtures 和项目级复核。 |
| 8 | **release_candidate、post-deploy 与 AI 结果被错误上调。** 借鉴 Argo/Flagger、Promptfoo/DeepEval/Inspect。 | 分离 developer/release/staged/post-deploy；定义 baseline/control/bake/abort/recovery；AI 锁 model/prompt/tool/data，切片至少 3 trial，`generator_is_sole_judge=false`。 | 低层 PASS 不可解释为上线成功；AI 总体平均不能掩盖关键切片失败。 | 各平台真实观察仍依赖授权 Adapter 和 telemetry。 |
| 9 | **证据泄露与伪独立复审。** 证据包可能包含 token/PII/binary；同模型角色扮演不等于 6 SubAgent。 | `evidence_guard.py`、binary/oversize 默认拒绝、retention/waiver；两轮×六固定角色、blocker 不投票消除、`role_separated_same_model` 诚实声明。 | Positive verdict 要求两轮完整、同 Subject、无 blocker/未解分歧；critical 仍需不同 context/evaluator。 | 启发式 DLP 有漏报；本会话无法提供真实独立 SubAgent。 |
| 10 | **安装/发布包本身可能不可靠并浪费 Codex token。** 旧 `inspect` 文本模式有 `KeyError`；旧交付依赖 sidecar；ZIP 可有 traversal/symlink/duplicate/bomb；切换后失败可留下半安装。 | 修复 `inspect action`；原子 install/backup/rollback/uninstall；新装失败清理、替换失败恢复、`--replace` repair；新增 deterministic builder、安全 verifier、NFC/Windows 路径门、canonical ZIP metadata、输出树隔离、post-test tree seal；默认只交付一个 ZIP。 | 14 installer tests + 16 release-wrapper tests；拒绝绝对/`..`/反斜杠/duplicate/case/non-NFC/Windows reserved/symlink/special/encrypted/bomb/tamper/非 canonical metadata；两次构建字节一致。 | 仍需外部 signer 才能证明发布者身份；最终 ZIP digest 不能自包含。 |

## 十轮后的裁决链

```text
Owner authority + frozen Taskpack
  → read-only capability/risk discovery
  → exact Subject + authorized command plan
  → external executors through no-verdict adapters
  → real user/API/world-state Oracles
  → release/AI/security/privacy gates
  → two-round six-lens adversarial review
  → fail-closed verdict + sealed evidence
  → deterministic install-ready release ZIP
```

## 明确非目标

- 不复制 SonarQube、Playwright、Testkube、Argo Rollouts、Promptfoo、Inspect AI、Sigstore 等成熟执行器。
- 不自动获得生产写入、付费调用、主动扫描、压测或 chaos 权限。
- 不把 PR 评论、CI 绿灯、quality gate、rollout controller、LLM judge 或 builder 自评直接当最终 PASS。
- 不修改 Product-Design-Taskpack、Skill 1 或被测产品来制造绿色。
