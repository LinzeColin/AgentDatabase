# Verifier v0.0.2.2 Final Delivery - Validation Report

- 验证日期：2026-07-25
- 内容树状态：**PASS / INSTALL_READY**
- 发布策略：单根、确定性 ZIP；包内包含外层 manifest/checksums、builder/verifier 和所有回归测试，不依赖 sidecar。
- 精确最终 ZIP SHA-256 不能自包含于自身，由最终交付消息给出；`verify_release.py --full` 可独立重验。

## 1. 自动测试结果

| 测试组 | 数量 | 结果 | 原始日志 |
|---|---:|---|---|
| Skill decision-kernel 与工具测试 | 75 | PASS | `validation_logs/skill_tests.txt` |
| Installer 测试 | 14 | PASS | `validation_logs/installer_tests.txt` |
| Release-wrapper 安全与可复现测试 | 16 | PASS | `validation_logs/release_wrapper_tests.txt` |
| 合计 | 105 | PASS | 上述三份日志 |

其中 26 项 Adapter tests 专门验证：六类工具归一化、精确 Subject、argv 数组、状态映射、证据哈希、路径/symlink/case collision、防止直接写 verdict，以及 warning/skipped/partial/timeout/无证据 PASS 的 fail-closed 行为。

## 2. 真实安装闭环

在隔离临时 `CODEX_HOME` 中执行：

```text
inspect (text + JSON)
→ install
→ verify --selftest
→ identical reinstall (idempotent)
→ uninstall-to-managed-backup
→ rollback
→ verify --selftest
```

结果：全部 PASS；最终安装状态为 `verifier 0.0.2.2`。原始日志：

- `validation_logs/manual_install_flow.txt`
- `validation_logs/readme_commands.txt`

## 3. 覆盖面

| 验证面 | 关键机器断言 |
|---|---|
| 分发完整性 | `MANIFEST.json`/SHA-256 全集合；distribution 拒绝 cache、unknown、symlink、case collision；installed 模式仅容忍受控 runtime cache。 |
| 契约与 Subject | 一次一个项目/版本；任务包完整 digest + contract digest；source→artifact/image→deployment 身份链；正向 verdict 禁止可变 build ID。 |
| 风险与命令 | Doctor 只读；风险升级；exact argv；allowlist、预算、network/credential/side-effect 门；未授权命令阻断。 |
| Adapter | 六类统一 schema；外部执行器无 verdict 权；显式状态映射；PASS 必须有原始证据哈希与 claim 引用。 |
| Evidence | secret/PII、binary/oversize、路径穿越、symlink、hash mismatch、脱敏副本和完整性校验。 |
| Test effectiveness | flake 不洗绿；clean-state；mutation/property/fault counterexample；总体平均不得掩盖失败切片。 |
| Review panel | 两轮 × 六固定角色；同一 Subject；blocker 不可投票消除；诚实独立性声明。 |
| Finalizer | positive verdict 强制 capability/plan/command/privacy/panel/identity/traceability/AI/Release gates。 |
| Installer | payload 执行前独立校验；atomic stage；幂等；managed backup；rollback/uninstall；外部 backup 路径拒绝；post-switch 失败时新装清理/替换恢复；`--replace` 可修复同 manifest 篡改；所有操作拒绝 symlink target root。 |
| ZIP release | exact root；无 absolute/`..`/backslash/duplicate/case collision/non-NFC/Windows reserved/symlink/special/encrypted/bomb；canonical mode/timestamp/compression；builder 输出不得位于自身树；outer manifest/checksum；tamper rejection。 |
| Reproducibility | 两次 build 字节完全一致；固定时间、排序和权限；净解压后完整 full validation；测试前后 delivery manifest/checksum seal 必须不变。 |

## 4. 外层发布验证流程

```bash
python3 -B build_release.py --output "/tmp/verifier-a.zip" --json
python3 -B build_release.py --output "/tmp/verifier-b.zip" --json
cmp "/tmp/verifier-a.zip" "/tmp/verifier-b.zip"
python3 -B verify_release.py "/tmp/verifier-a.zip" --full --json
```

`--full` 先进行解压前 ZIP 防御和 outer manifest/checksum 验证，再从安全解压副本运行 75 项 Skill tests、14 项 installer tests、16 项 release-wrapper tests、文本/JSON inspect，以及真实安装、幂等、卸载、回滚和 selftest；最后重新验证交付树并要求 manifest/checksum seal 未变化。最终发布 ZIP 在封装后按同一流程外部复验。

## 5. 裁决边界

本报告证明此交付包的规则、安装、完整性、负向防御和可复现性达到当前验收条件；它不虚构以下尚未建立的外部证据：

- 全球统一 corpus 上的缺陷召回率第一；
- 六个真实独立 SubAgent；
- 外部发布者签名；
- 对每一种生产平台的真实访问与 post-deploy 观察。

这些边界已进入 Round 2 风险记录，不属于隐藏缺陷。

PDF 另经 12 页渲染与嵌入字体预检，见 `validation_logs/pdf_preflight.txt`。唯一 ZIP 的最终 SHA-256 由交付消息提供，解压前必须先比对。
