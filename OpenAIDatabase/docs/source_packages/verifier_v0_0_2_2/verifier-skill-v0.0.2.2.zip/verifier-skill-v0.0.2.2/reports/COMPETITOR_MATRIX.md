# Verifier v0.0.2.2 竞品、互补执行器与标准矩阵

- 核验日期：2026-07-25。
- 样本：84 项（含本次交付；其余为直接同类、成熟软件、开源框架、商业平台或权威标准）。
- 评分性质：基于公开一手资料的结构化分析者判断，不是供应商 benchmark、安全认证或真实缺陷召回率实测。
- 维度 1–5：契约追溯、真实执行、制品/发布身份、AI/Agent 评测、证据/供应链、独立复审、运营成熟度。
- 权重：20% / 20% / 15% / 15% / 15% / 10% / 5%。成熟度权重故意较低，避免窄域成熟产品用采用度替代端到端覆盖。

## 结论与默认架构

**有大量项目在单点能力上比 Verifier 更成熟、更深；没有找到公开证据证明某一个单体系统同时覆盖“授权契约 → 精确 Subject → 风险驱动真实执行 → 用户/调用方 world state → 发布观察 → AI 多 trial → 证据隐私/封存 → 独立复审 → 最终放行”。**

因此本次不是复制 83 个产品，而是采用：

```text
Verifier = fail-closed decision kernel
External systems = capability/evidence adapters
Final verdict = frozen contract + exact subject + verified evidence + independent gates
```

“世界最好”无法仅靠功能清单科学证明；本包把可验证目标定义为：覆盖链更完整、拒绝假绿、外部工具不越权、安装可复现、负向攻击可阻断。

## 横向总表

| 类别 | 项目 | 成熟度 | 契约 | 执行 | 身份/发布 | AI | 证据/供应链 | 独立复审 | 运营成熟 | 加权适配 | 最强点 | 对统一验收的缺口 | 融合方式 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|
| 本次交付 | Verifier v0.0.2.2 | 新发布；本包验证 | 5 | 4 | 5 | 4 | 5 | 4 | 2 | 4.40 | 冻结授权契约、精确 Subject、真实 world state、发布/AI/证据门和两轮六视角统一裁决 | 无公开采用度；不替代各领域执行器；无外部签名或真实 SubAgent dispatcher | 决策内核；通过六类 Adapter 消费外部证据 |
| 直接同类/规格治理 | [Proof Loop](https://github.com/LeoStehlik/proof-loop) | 新兴开源 | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | 冻结 AC、builder/verifier 分离、fresh verification、durable proof | 部署身份、AI eval、隐私与供应链覆盖较浅 | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| 直接同类/规格治理 | [Agile-V](https://github.com/Agile-V/agile_v_skills) | 成长型开源 | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | V-Model、REQ 追溯、Red Team、Human Gate、合规产物 | 全生命周期较重；精确可安装 acceptance evidence pack 不是核心 | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| 直接同类/规格治理 | [TLC Spec-Driven](https://github.com/tech-leads-club/agent-skills/blob/main/packages/skills-catalog/skills/(development)/tlc-spec-driven/SKILL.md) | 新兴开源 Skill | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | Specify→Design→Tasks→Execute、独立 verifier、evidence-or-zero | 发布观察、供应链、AI 运行风险与证据隐私不足 | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| 直接同类/规格治理 | [GitHub Spec Kit](https://github.com/github/spec-kit) | 成熟开源工具包 | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | 规格驱动开发、constitution、plan/tasks 工作流 | 主要解决如何构建，不承担独立验收和发布裁决 | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| 直接同类/规格治理 | [OpenSpec](https://github.com/Fission-AI/OpenSpec) | 成长型开源 | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | 结构化 spec/change artifacts、proposal-first 工作流 | 验收执行、Subject 身份和 evidence sealing 需外部系统 | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| 直接同类/规格治理 | [Agent Skills Specification](https://agentskills.io/specification) | 开放规范 | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | Skill 包结构、metadata、progressive disclosure 与跨 agent 兼容 | 规范不执行测试或提供 verdict | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| 直接同类/规格治理 | [NIST SSDF](https://csrc.nist.gov/pubs/sp/800/218/final) | 成熟政府标准 | 4 | 3 | 2 | 2 | 3 | 4 | 3 | 3.00 | 安全软件开发实践、角色与任务基线 | 控制框架而非项目级自动验收器 | 吸收契约冻结、角色分离和 progressive disclosure；由 Verifier 补齐运行与裁决 |
| AI PR Review | [Qodo Merge](https://docs.qodo.ai/qodo-documentation/code-review) | 成熟商业 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | 代码库上下文、多代理 review、策略化规则与 PR 建议 | PR 层不能证明用户结果、部署身份或 post-deploy | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| AI PR Review | [CodeRabbit](https://docs.coderabbit.ai/) | 成熟商业 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | 上下文 PR review、逐行建议、知识库与对话修复 | 受 diff/仓库上下文和误报影响，不是 acceptance authority | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| AI PR Review | [Greptile](https://docs.greptile.com/) | 成熟商业 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | repository-aware 跨文件分析与 PR review | 真实执行、发布观察和 sealed evidence 需外部补充 | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| AI PR Review | [GitHub Copilot code review](https://docs.github.com/en/copilot/concepts/agents/code-review) | 成熟平台能力 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | GitHub/IDE 原生 review 与可定制指令 | 不可信分支指令边界；不能替代 release gate | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| AI PR Review | [Graphite Reviewer](https://graphite.com/ai-code-review) | 成熟商业 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | stacked PR 上下文、自动 review 与开发工作流集成 | 聚焦变更审查，不闭合需求→world state | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| AI PR Review | [Ellipsis](https://www.ellipsis.dev/) | 成长型商业 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | 异步 AI 工程代理、PR review/fix 与 repo context | 自主修改和 review 独立性需额外治理 | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| AI PR Review | [Bito AI Code Review Agent](https://bito.ai/product/ai-code-review-agent/) | 成熟商业 | 2 | 2 | 1 | 1 | 2 | 2 | 5 | 1.85 | PR 自动审查、代码库上下文和团队规则 | 缺少精确 deployment identity 与最终用户 outcome | 作为静态/逻辑线索 Adapter；原始输出和 commit hash 必须绑定 |
| 静态质量/AppSec | [SonarQube](https://docs.sonarsource.com/sonarqube-server/quality-standards-administration/managing-quality-gates/introduction-to-quality-gates) | 成熟商业/社区 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 多语言静态分析、质量门、安全热点与趋势 | 静态规则不能证明业务正确性或运行恢复 | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [Semgrep](https://semgrep.dev/docs/) | 成熟开源/商业 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 可定制规则、SAST/SCA/secrets、CI 集成 | 规则召回率与误报依赖配置；无业务 Oracle | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [GitHub CodeQL](https://codeql.github.com/docs/) | 成熟平台/开源查询 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 语义代码数据库、复杂数据流查询、GitHub code scanning | 运行行为与部署状态不在覆盖范围 | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [Snyk Code](https://docs.snyk.io/scan-with-snyk/snyk-code) | 成熟商业 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 开发者工作流中的代码安全分析与修复建议 | 供应商分析结论仍需绑定 Subject 和复核 | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [Codacy](https://docs.codacy.com/) | 成熟商业 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 多工具代码质量/安全聚合、PR gate 与趋势 | 聚合绿灯不等于 acceptance contract 通过 | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [Trivy](https://trivy.dev/) | 成熟开源 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 容器、文件系统、依赖、IaC、secret 扫描 | 漏洞数据库时效与范围限制；不证明功能正确 | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [OpenSSF Scorecard](https://scorecard.dev/) | 成熟开源 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 仓库安全实践自动检查与风险信号 | 项目姿态评分不能裁决某个 release | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [OSV-Scanner](https://google.github.io/osv-scanner/) | 成熟开源 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 基于 OSV 的依赖漏洞扫描与 lockfile/SBOM 输入 | 只覆盖已知漏洞，且不验证 runtime exploitability | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 静态质量/AppSec | [Checkmarx One](https://checkmarx.com/product/checkmarx-one/) | 成熟商业 | 1 | 3 | 2 | 1 | 3 | 2 | 5 | 2.15 | 统一 AST/SCA/IaC/API 安全平台与企业治理 | 成本与平台依赖较高；业务验收仍需独立闭环 | 作为 A4/A6 Adapter；不继承 vendor verdict，保留规则集和原始证据 |
| 测试执行/QA 平台 | [Playwright](https://playwright.dev/) | 成熟开源 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | Chromium/Firefox/WebKit E2E、trace、video、并行和稳定定位器 | 仅覆盖可自动化 UI 旅程，需业务 world-state Oracle | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Cypress](https://docs.cypress.io/) | 成熟开源/商业 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 浏览器测试体验、time travel 调试与 CI cloud | 跨域/多窗口和非浏览器系统需其他工具 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Selenium](https://www.selenium.dev/documentation/) | 成熟开源生态 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 跨浏览器 WebDriver 标准与广泛语言/网格生态 | 维护成本和 flake 控制依赖工程纪律 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Robot Framework](https://robotframework.org/) | 成熟开源 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 关键字驱动通用验收、可读性与库生态 | 权威契约、Subject 和 evidence authenticity 外置 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Cucumber](https://cucumber.io/docs/cucumber/) | 成熟开源/商业生态 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | BDD executable specification 与业务可读场景 | 可读 Scenario 仍可能有弱 Oracle 或过时实现 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Testkube](https://docs.testkube.io/) | 成熟云原生开源/商业 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | Kubernetes 原生跨工具工作流、调度、并行与结果管理 | 执行器强但不定义 acceptance authority | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [QA Wolf](https://www.qawolf.com/) | 成熟商业服务 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 托管式高并行 E2E 测试创建、运行和维护 | 供应商/人工服务边界、成本和外部数据治理 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [mabl](https://help.mabl.com/) | 成熟商业 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 低代码智能测试、API/UI、CI 和测试洞察 | 闭源行为与 self-healing 可能掩盖语义漂移 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Momentic](https://momentic.ai/) | 成长型商业 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | AI-native Web 测试生成、维护与自然语言工作流 | 生成测试仍需独立 Oracle 和覆盖审计 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [testRigor](https://testrigor.com/) | 成熟商业 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 自然语言端到端测试和多渠道自动化 | 抽象层便利但底层行为/定位透明度有限 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [BrowserStack](https://www.browserstack.com/docs) | 成熟商业基础设施 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 大规模真实浏览器/设备云与跨平台执行 | 提供环境而非测试意图和最终裁决 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Sauce Labs](https://docs.saucelabs.com/) | 成熟商业基础设施 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 跨浏览器/移动执行、测试洞察与企业网格 | 执行基础设施不替代契约和证据治理 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 测试执行/QA 平台 | [Applitools](https://applitools.com/docs/) | 成熟商业 | 2 | 5 | 2 | 1 | 3 | 1 | 5 | 2.65 | 视觉 AI 回归、跨浏览器渲染比较与 UI 变更审查 | 视觉差异不能证明交互、数据或业务语义正确 | 通过 test_execution/human_manual Adapter 归一化，真实结果须关联 Acceptance |
| 契约/集成/可观测测试 | [Pact](https://docs.pact.io/) | 成熟开源/商业生态 | 3 | 5 | 2 | 1 | 3 | 1 | 4 | 2.80 | consumer-driven contract testing 与 provider 验证 | 不能替代完整 E2E、共享数据或生产观察 | 作为执行 Adapter，补上 exact Subject、外部状态和 release scope |
| 契约/集成/可观测测试 | [Schemathesis](https://schemathesis.readthedocs.io/) | 成熟开源 | 3 | 5 | 2 | 1 | 3 | 1 | 4 | 2.80 | 由 OpenAPI/GraphQL 生成 property-based API 测试与最小复现 | schema 本身可能不权威；主动测试需副作用授权 | 作为执行 Adapter，补上 exact Subject、外部状态和 release scope |
| 契约/集成/可观测测试 | [Dredd](https://dredd.org/en/latest/) | 成熟开源 | 3 | 5 | 2 | 1 | 3 | 1 | 4 | 2.80 | API description 与实现的一致性测试 | 生态和协议覆盖较窄；业务不变量有限 | 作为执行 Adapter，补上 exact Subject、外部状态和 release scope |
| 契约/集成/可观测测试 | [Testcontainers](https://testcontainers.com/) | 成熟开源 | 3 | 5 | 2 | 1 | 3 | 1 | 4 | 2.80 | 真实数据库/队列/服务容器化集成测试 | 容器拓扑不必然代表生产配置 | 作为执行 Adapter，补上 exact Subject、外部状态和 release scope |
| 契约/集成/可观测测试 | [Tracetest](https://tracetest.io/) | 成长型开源 | 3 | 5 | 2 | 1 | 3 | 1 | 4 | 2.80 | 基于 OpenTelemetry trace 的分布式断言 | trace 正确仍不等于最终业务状态正确 | 作为执行 Adapter，补上 exact Subject、外部状态和 release scope |
| 测试有效性/性能 | [Stryker](https://stryker-mutator.io/) | 成熟开源生态 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | mutation testing 检验测试能否抓住错误 | 聚焦代码级 test effectiveness，不覆盖产品全链路 | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 测试有效性/性能 | [mutmut](https://mutmut.readthedocs.io/) | 成熟 Python 开源 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | Python mutation testing 与 surviving mutant 反馈 | 语言范围窄；变异体代表性有限 | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 测试有效性/性能 | [Hypothesis](https://hypothesis.readthedocs.io/) | 成熟开源 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | property-based testing、边界生成与反例缩小 | 需要正确属性/Oracle，不能自证业务语义 | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 测试有效性/性能 | [fast-check](https://fast-check.dev/) | 成熟开源 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | JavaScript/TypeScript property-based testing 与可复现 seed | 同样依赖高质量 property 和系统 harness | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 测试有效性/性能 | [k6](https://grafana.com/docs/k6/) | 成熟开源/商业 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | 脚本化负载、阈值、协议支持与可观测集成 | 性能 PASS 依赖真实容量模型与环境代表性 | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 测试有效性/性能 | [Locust](https://docs.locust.io/) | 成熟开源 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | Python 分布式负载建模和可编程用户行为 | 测试模型、数据与环境偏差可造成假结论 | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 测试有效性/性能 | [Apache JMeter](https://jmeter.apache.org/) | 成熟开源 | 1 | 5 | 1 | 1 | 2 | 1 | 4 | 2.10 | 多协议负载/功能测试与插件生态 | 大型计划维护和结果解释成本高 | 作为 discrimination/performance evidence；阈值和环境由 Acceptance 锁定 |
| 发布/韧性 | [Argo Rollouts](https://argoproj.github.io/argo-rollouts/) | 成熟 CNCF 生态 | 1 | 4 | 5 | 1 | 3 | 1 | 4 | 2.65 | Blue-Green/Canary、analysis、promotion/abort | Kubernetes rollout 不解决不可逆迁移和业务不变量 | 通过 release_observation Adapter；Verifier 定义 baseline、abort、bake 与 post-deploy verdict |
| 发布/韧性 | [Flagger](https://docs.flagger.app/) | 成熟 CNCF 生态 | 1 | 4 | 5 | 1 | 3 | 1 | 4 | 2.65 | 自动 canary、metrics/webhook analysis 与 service mesh 集成 | 依赖 telemetry 和平台配置；不定义业务 acceptance | 通过 release_observation Adapter；Verifier 定义 baseline、abort、bake 与 post-deploy verdict |
| 发布/韧性 | [Chaos Mesh](https://chaos-mesh.org/) | 成熟 CNCF 开源 | 1 | 4 | 5 | 1 | 3 | 1 | 4 | 2.65 | Kubernetes fault injection、workflow 与可观测实验 | 故障实验有真实副作用，需严格授权/停止条件 | 通过 release_observation Adapter；Verifier 定义 baseline、abort、bake 与 post-deploy verdict |
| 发布/韧性 | [LitmusChaos](https://litmuschaos.io/) | 成熟 CNCF 开源 | 1 | 4 | 5 | 1 | 3 | 1 | 4 | 2.65 | 云原生 chaos workflows、probes 与 resilience validation | 实验代表性和 blast radius 需独立治理 | 通过 release_observation Adapter；Verifier 定义 baseline、abort、bake 与 post-deploy verdict |
| 发布/韧性 | [Gremlin](https://www.gremlin.com/) | 成熟商业 | 1 | 4 | 5 | 1 | 3 | 1 | 4 | 2.65 | 企业级 reliability testing、fault library 与安全控制 | 商业平台不能替代业务恢复 Oracle 与 owner authority | 通过 release_observation Adapter；Verifier 定义 baseline、abort、bake 与 post-deploy verdict |
| AI/Agent Eval | [Promptfoo](https://www.promptfoo.dev/docs/intro/) | 成熟开源/商业 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | Prompt/model 对比、断言、red team、CI 与报告 | Prompt 层结果不自动证明工具副作用/world state | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [DeepEval](https://deepeval.com/docs/getting-started) | 成熟开源/商业 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | LLM/agent/RAG metrics、datasets、tracing 与 pytest 风格 | LLM-as-judge 相关偏差和业务 Oracle 缺口 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Inspect AI](https://inspect.aisi.org.uk/) | 成熟政府支持开源 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | task/dataset/solver/scorer 组件化与广泛 AI eval | 评估框架不是一般软件 release/supply-chain gate | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [OpenAI Evals](https://github.com/openai/evals) | 成熟开源生态 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | 可扩展 eval、registry 和私有数据评测 | 主要面向模型/系统评估，不处理完整软件验收 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [LangSmith](https://docs.smith.langchain.com/) | 成熟商业平台 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | trace、dataset、offline/online eval、实验比较 | 平台锁定和 evaluator 设计仍需治理 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Braintrust](https://www.braintrust.dev/docs) | 成熟商业/开源组件 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | evals、tracing、datasets、scorers 与 production feedback | 组织业务门和 artifact identity 需外接 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [W&B Weave](https://weave-docs.wandb.ai/) | 成熟商业/开源组件 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | LLM app tracing、evaluation、versioning 与可视化 | ML/LLM observability 不等于 release authority | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Arize Phoenix](https://arize.com/docs/phoenix) | 成熟开源/商业 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | OpenTelemetry tracing、RAG/LLM eval 与 production observability | 最终 acceptance 与副作用验证需外部闭环 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Ragas](https://docs.ragas.io/) | 成熟开源 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | RAG/agent 指标、testset 与 evaluation workflow | 指标有效性依赖场景和 judge calibration | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Giskard](https://docs.giskard.ai/) | 成熟开源/商业 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | AI testing、vulnerability scanning 与 quality reports | 扫描覆盖和业务行为必须独立验证 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Garak](https://github.com/NVIDIA/garak) | 成熟开源 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | LLM vulnerability scanner 与 probe/detector 生态 | 红队探针不是完整功能/发布验收 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [Microsoft PyRIT](https://github.com/Azure/PyRIT) | 成熟开源 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | 生成式 AI 风险识别、orchestration 与 attack strategy | 安全 red team 不能替代正常业务质量裁决 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| AI/Agent Eval | [TruLens](https://www.trulens.org/) | 成熟开源 | 2 | 5 | 2 | 5 | 3 | 2 | 4 | 3.30 | LLM/RAG feedback functions、tracing 与 evaluation | feedback 指标与真实业务 outcome 仍有距离 | 通过 ai_evaluation Adapter；锁模型/Prompt/tool/data，按切片多 trial 和独立 judge |
| 供应链/政策门禁 | [in-toto](https://in-toto.io/) | 成熟开源规范/工具 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | 供应链步骤、layout/link metadata 与 attestation | 证明过程/bytes，不证明业务 Acceptance | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [SLSA](https://slsa.dev/) | 成熟开放规范 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | provenance、build integrity 和供应链威胁模型 | 等级/证明不是功能正确性 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [Sigstore](https://docs.sigstore.dev/) | 成熟开源生态 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | keyless signing、identity、transparency log 与 verification | 签名证明主体/制品关系，不证明产品可用 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [GitHub Artifact Attestations](https://docs.github.com/en/actions/security-for-github-actions/using-artifact-attestations) | 成熟平台能力 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | GitHub Actions 原生 provenance/attestation 与验证 | 依赖 GitHub builder/trust boundary | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [GUAC](https://guac.sh/) | 成长型开源 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | 聚合/查询软件供应链 metadata 和图谱 | 事实质量取决于输入 provenance/SBOM | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [Syft + Grype](https://github.com/anchore/syft) | 成熟开源 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | SBOM 生成与漏洞匹配、广泛 artifact 支持 | 组件清单/漏洞不等于来源真实性或功能验收 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [CycloneDX](https://cyclonedx.org/) | 成熟 OWASP 标准 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | SBOM/MBOM/VEX 等供应链数据格式生态 | 格式本身不保证内容正确或签名 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [SPDX](https://spdx.dev/) | 成熟 ISO 标准/开源 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | 软件物料、许可和 provenance 元数据交换 | 标准化描述不执行验证 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [Conftest / OPA](https://www.conftest.dev/) | 成熟开源 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | 对结构化配置执行可版本化 policy-as-code | 策略只与输入和规则同等可靠 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 供应链/政策门禁 | [Kyverno](https://kyverno.io/) | 成熟 CNCF 开源 | 1 | 2 | 5 | 1 | 5 | 1 | 4 | 2.55 | Kubernetes policy、validation/mutation/generation 与 image verification | 集群策略不覆盖产品全链路 | 通过 supply_chain Adapter；Verifier 消费签名/provenance/SBOM 而不混同功能 PASS |
| 标准/治理 | [NIST AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) | 成熟政府框架 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | Govern/Map/Measure/Manage AI 风险与组织责任 | 非自动化项目级 eval 或 release gate | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |
| 标准/治理 | [OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/) | 成熟开放标准 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | 应用安全验证要求分级和可审计基线 | 安全要求不覆盖完整产品/业务验收 | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |
| 标准/治理 | [OWASP SAMM](https://owaspsamm.org/) | 成熟开放模型 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | 软件保障成熟度、治理与改进路线 | 组织成熟度模型，不裁决单次制品 | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |
| 标准/治理 | [OWASP Top 10 for LLM Applications](https://genai.owasp.org/llm-top-10/) | 成熟开放风险清单 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | LLM 应用常见风险分类和缓解方向 | 风险清单不能替代项目特定 threat model/evidence | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |
| 标准/治理 | [MITRE ATLAS](https://atlas.mitre.org/) | 成熟知识库 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | AI 对抗战术/技术与案例映射 | 知识库不是测试 harness 或 verdict engine | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |
| 标准/治理 | [ISO/IEC 25010](https://www.iso.org/standard/78176.html) | 成熟国际标准 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | 产品质量模型与质量特性词汇 | 高层模型需转成可执行 Acceptance/Oracle | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |
| 标准/治理 | [OpenSSF Best Practices Badge](https://www.bestpractices.dev/) | 成熟开源治理项目 | 4 | 1 | 2 | 3 | 4 | 3 | 5 | 2.90 | 开源项目安全实践自评与公开 badge | 自报/项目级实践不能证明某 release | 转化为风险与 Acceptance 条目；不把 checklist 直接当 PASS |

## 竞品优势吸收与缺点修复映射

| 竞品机制 | 吸收进 v0.0.2.2 | 原机制常见缺点 | 本包修复 |
|---|---|---|---|
| Proof Loop / Agile-V 的契约冻结、builder-verifier 分离 | Taskpack 双 digest、exact Acceptance/Task IDs、两轮六视角 | 主要证明任务完成，发布/AI/隐私链较浅 | exact Subject、release/AI/privacy gate、不可豁免项 |
| Qodo/CodeRabbit/Greptile 的 repository-aware review | 作为 static/logic Adapter 输入 | PR 绿灯可能被误当 release 绿灯 | Adapter `decision_authority=none`，禁止写 verdict |
| Sonar/Semgrep/CodeQL/Snyk 的质量与安全门 | A4/A6 静态证据 | 规则误报/漏报，不能证明用户结果 | 必须关联 Acceptance、Subject、原始证据和 runtime journey |
| Playwright/Testkube/Pact/Testcontainers 的真实执行 | 风险驱动 execution plan 与 evidence hash | 执行器不定义权威契约/裁决 | Requirement→Oracle→Test→Evidence→Subject 闭环 |
| Stryker/Hypothesis 的反例能力 | discrimination gate | 不能自动覆盖所有业务语义 | 关键路径至少一种 mutation/property/fault/counterexample 证据 |
| Argo Rollouts/Flagger/Chaos 的发布与韧性 | release_candidate/post_deploy scope | rollout 指标不等于业务成功；chaos 有副作用 | baseline、业务不变量、abort、bake、授权与恢复门 |
| Promptfoo/DeepEval/Inspect 等 AI eval | 多 trial、切片阈值、judge 独立性 | 总体平均掩盖关键失败、LLM judge 偏差 | 分切片门禁、generator_is_sole_judge=false、world state |
| SLSA/Sigstore/in-toto/SBOM | source→build→artifact→deployment 证据链 | provenance 不证明功能正确 | 来源真实性与业务 Acceptance 双轨，不互相替代 |
| NIST/OWASP/ISO/MITRE | 风险分类、控制和验收条目来源 | checklist 容易形成纸面合规 | 转为可执行 Oracle/证据；NOT_RUN 不折算 PASS |

## 选择矩阵

| 实际需求 | 优先执行器 | Verifier 必做 |
|---|---|---|
| PR 逻辑/安全初筛 | Qodo、CodeRabbit、Greptile、Sonar、Semgrep、CodeQL | 锁 commit、验证规则集与原始输出，不继承 verdict |
| Web/跨服务验收 | Playwright/Cypress + Pact/Schemathesis/Testcontainers/Tracetest | 证明用户结果与持久 world state，而非只看 HTTP 200 |
| 测试是否真能抓错 | Stryker/mutmut/Hypothesis/fast-check | surviving mutant/反例成为 finding，重试不洗绿 |
| 发布放量 | Argo Rollouts/Flagger + metrics | 绑定 deployment identity、baseline、abort、bake 和业务不变量 |
| AI/Agent | Inspect/Promptfoo/DeepEval/LangSmith/Braintrust/Phoenix | 锁模型/Prompt/tool/data，切片多 trial，验证副作用 |
| 供应链 | SLSA/Sigstore/in-toto/Syft/Grype/CycloneDX/SPDX | 验证 provenance/signature；明确其不等于功能 PASS |

## 研究限制

- 商业产品的准确率、速度、客户数量和“自动修复”营销数字没有作为硬证据。
- 本轮未购买所有商业产品并在同一缺陷语料上跑受控 benchmark，因此加权分只用于架构选择。
- GitHub/网页可见内容会变化；矩阵记录的是 2026-07-25 可核验公开能力。
- “没有找到单体全覆盖”是搜索结论，不是数学上的不存在证明；应通过后续 golden defective projects 持续反证。
