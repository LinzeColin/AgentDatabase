# Verifier v0.0.2.2 竞品研究、反向工程与最终复审报告

- 日期：2026-07-25
- 输入基线：用户上传 `verifier-v2.2.0-final-installable(1).zip`
- 最终 Skill release：`0.0.2.2`
- Evidence schema compatibility：`2.1`
- 交付目标：AI 软件开发的独立验收复审 Skill；Codex 仅原样落库/commit/push/merge/backup。

## 1. 结论与下一步

**默认采用 Verifier v0.0.2.2 作为统一 `decision kernel`，把成熟竞品作为无裁决权 Adapter。** 84 项研究表明：大量项目在 PR review、静态分析、浏览器/API 测试、mutation、渐进发布、AI eval 或供应链证明上更成熟；未找到公开证据证明某个单体系统覆盖完整授权与放行链。

交付不是“把所有竞品重写一遍”，而是：

```text
frozen authority/contract
  → exact source/artifact/deployment Subject
  → authorized risk-driven execution
  → normalized no-verdict adapters
  → real user/API/world-state Oracles
  → release/AI/security/privacy/independence gates
  → one scoped verdict + sealed evidence + deterministic ZIP
```

## 2. 目标、范围、非目标与验收

| 项目 | 定义 |
|---|---|
| 目标 | 安装即用、fail-closed、可复现、低歧义、低 Codex token 的行业顶级验收复审 Skill。 |
| 范围 | Skill 文档/references/templates、stdlib CLI、finalizer、Adapter contract、installer、outer release verifier、测试、竞品/十轮/复审/PDF/handoff。 |
| 非目标 | 不修改被测产品；不替代 Product-Design-Taskpack/Skill 1；不内置所有测试平台；不伪造生产权限、签名或独立 SubAgent。 |
| 硬约束 | 单一目标/Subject；Taskpack 只读；真实执行；外部工具不能写 verdict；NOT_RUN/WAIVED/UNKNOWN 不变 PASS；无授权不产生副作用。 |
| 验收 | 75 Skill tests、14 installer tests、16 release-wrapper tests（合计 105）；README 实跑；净环境 install/verify/idempotence/uninstall/rollback；两次 ZIP 字节一致；full archive verify 与 post-test tree seal。 |

## 3. 基线审计与实际修复

| 基线问题 | 用户影响 | 本次修复 |
|---|---|---|
| 包内版本是 `2.2.0` 而非要求的 `0.0.2.2` | 安装后版本/Task Pack/报告不一致 | 全树统一 numeric-quad，manifest 和 positive gate 强制一致。 |
| `install.py inspect` 文本模式读取缺失 `action` | README 首条命令 `KeyError`，Agent 重试浪费 token | 稳定 `action=inspected` + source manifest digest；text/JSON tests。 |
| 外部工具只有文档级 Adapter 约定 | warning/skipped/partial/总体平均可能污染 verdict | 六类机器契约、证据 hash、逐 claim Oracle、26 项负向测试。 |
| 旧 release 依赖 sidecar，外层 ZIP 缺独立安全 verifier | 自引用/漂移；Zip Slip、symlink、duplicate、bomb 风险 | deterministic builder + pre-extraction verifier + outer manifest/checksum + canonical metadata/path portability。 |
| 竞品矩阵只有约 28 项 | 研究宽度不足，难以证明融合路径 | 扩展至 84 项并逐项记录优势、缺口、融合边界。 |
| 复审容易把角色扮演称作 SubAgent | critical 独立性证据欺诈 | `role_separated_same_model` 机器声明；critical 需真实不同 context。 |
| installer 切换后验证失败可能留下新目录；同 manifest 篡改安装无法直接修复 | 半安装、恢复路径不清、Agent 手工删除 | 新装失败清理、替换失败恢复旧版本、`--replace` repair、14 项 installer 回归。 |

## 4. 竞品反向研究

完整表：`COMPETITOR_MATRIX.md/.csv`；来源：`SOURCE_REGISTRY.md`。

| 能力域 | 单点更成熟的代表 | 吸收机制 | Verifier 补齐 |
|---|---|---|---|
| 规格/独立验证 | Proof Loop、Agile-V、TLC、Spec Kit、OpenSpec | AC/REQ 冻结、builder-verifier separation、progressive disclosure | exact artifact/deployment、真实 world state、发布/AI/隐私/封存 |
| PR/静态安全 | Qodo、CodeRabbit、Greptile、Sonar、Semgrep、CodeQL、Snyk | repo-aware review、规则/quality gate | 不继承 vendor verdict；绑定 Subject/规则集/原始证据 |
| 执行/契约 | Playwright、Testkube、Pact、Schemathesis、Testcontainers、Tracetest | 真浏览器、K8s orchestration、API/服务契约和 trace | authority、Oracle、world state、scope 和 evidence chain |
| 测试有效性 | Stryker、mutmut、Hypothesis、fast-check | mutation/property/counterexample | 将 surviving mutant 变成 finding；重试不洗绿 |
| 发布/韧性 | Argo Rollouts、Flagger、Chaos Mesh、Litmus、Gremlin | canary/control、analysis、fault injection | deployment identity、业务不变量、授权、abort/bake/recovery |
| AI/Agent eval | Promptfoo、DeepEval、Inspect、LangSmith、Braintrust、Phoenix、Ragas、Giskard、Garak、PyRIT | datasets、scorers、traces、red team | model/prompt/tool/data lock、切片多 trial、world state、judge independence |
| 供应链/政策 | SLSA、Sigstore、in-toto、GitHub attestations、Syft/Grype、CycloneDX/SPDX、OPA/Kyverno | provenance/signing/SBOM/policy | 与功能 Acceptance 双轨，不把来源证明当业务 PASS |

## 5. 架构：为什么能融合而不污染

### 5.1 三层责任

1. **Authority layer**：Owner/Taskpack 定义什么算成功，不能由 builder、scanner 或 LLM 改写。
2. **Observation layer**：项目原生测试和竞品工具执行，Adapter 只提交已哈希观察，`decision_authority=none`。
3. **Decision layer**：Verifier 依据 traceability、exact Subject、真实 world state 和风险门给唯一 scope-limited verdict。

### 5.2 Adapter 防污染

支持 `static_analysis|test_execution|release_observation|ai_evaluation|supply_chain|human_manual`。每个结果必须含：工具/版本/来源、Subject、argv/cwd/exit/timeout、显式状态映射、raw evidence SHA-256、逐 claim Oracle、限制。任何 direct verdict、warning/skipped/partial→PASS、timeout PASS、无证据 PASS 或 aggregate masking 都被机械拒绝。

### 5.3 Token 与性能

- 先身份/契约/低成本门，再跑高成本 journey/AI/chaos；不可恢复 blocker 时停止。
- JSON 是机器真相，Markdown 是人类解释；大日志只保留路径/hash/必要 tail。
- 每个 reviewer 只拿最小 context capsule，不拿前一角色 verdict。
- Owner/Codex 默认只收到一个 ZIP 和三条安装命令。

## 6. 十轮完善与两轮六视角

十轮明细见 `TEN_ROUND_CHANGELOG.md`。Round 1 找到并关闭版本身份、Adapter 洗绿、ZIP 安全、sidecar 漂移、独立性虚报、`inspect` 崩溃六项问题。Round 2 以反事实验证 schema 兼容、真实缺陷 recall、签名真实性、跨平台 post-deploy、同模型锚定、隐私启发式六项边界；0 blocker，保留项目级 gate。

本会话没有真正 SubAgent 调度工具，因此 12 份复审是角色隔离的同一模型，而非六个独立 Agent。该限制不会被隐藏，critical positive verdict 仍需真实独立 evaluator/context。

## 7. 安装和发布信任链

```text
trusted-channel SHA-256 bootstrap
  → archive inspect before extraction
  → exact single root / no traversal, duplicate, case collision, non-NFC/Windows hazard, symlink, bomb
  → outer DELIVERY_MANIFEST + SHA256SUMS
  → installer independently verifies inner MANIFEST + SHA256SUMS
  → copy to staging
  → validate + optional selftest
  → atomic replace / backup / rollback / post-switch failure recovery
  → repeat verification + post-test delivery tree seal
```

`build_release.py` 使用固定时间、排序 member、规范权限和确定性压缩，拒绝输出位于自身 release tree；两次构建必须字节完全相同。ZIP digest 不写入自身，避免自引用，因此解压前的 bootstrap trust 来自最终交付消息中的 SHA-256。

## 8. 结论边界

- 本包可以被证实为 **install-ready、reproducible、tamper-detecting、fail-closed**。
- 它不能仅凭本次功能矩阵被证明为“数学意义世界第一”；真实领先需要统一 defective-project benchmark、false-positive/recall、跨语言/平台和长期运行数据。
- 单点成熟工具不是竞争失败，而是被纳入严格的 authority/evidence/decision 分工。
- 对任何具体软件项目，Verifier 仍必须重新锁定其 Taskpack、Subject、环境、权限和 Oracles；本包自检 PASS 不代表未来项目自动 PASS。
