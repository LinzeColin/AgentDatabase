# Codex Adaptive Human Voice Router

当前版本：`1.1.1`

只修改 Codex 的全局语气路由器。它不是让 Codex 每次“碰运气调用 Skill”，而是使用 Codex 原生 lifecycle hooks：

- `SessionStart`：在启动、恢复、`/clear` 和 compact 后加载完整 Voice Contract；
- `UserPromptSubmit`：每个用户回合都运行，只注入一个短路由标签；
- `SubagentStart`：让新 subagent 继承同一套表达契约；
- 可选 Skill：只用于显式检查、调试和修改，不承担强制触发。

## 默认效果

路由同时判断：

- task：high-risk / debug / decision / research / explain / creative / execution / quick / default；
- emotion：frustrated / uncertain / positive / neutral；
- density：concise / normal / deep / deep_concise；
- tone：adaptive / warm / strict / off；
- urgency 和主要语言。

关键原则：风险越高，表达越克制；普通对话、解释、调试、决策和创意默认使用更可感知的自然承接。话语标记不设固定数量上限，但不能为了显得口语化而堆砌。

## 一条命令安装

macOS / Linux：

```bash
python3 install.py --no-skill
```

Windows：

```powershell
py -3 install.py --no-skill
```

这个默认方案只安装 Codex Hook，不安装 Skill，也不修改 `~/.codex/config.toml`。如确实希望同时关闭 Codex 内建 personality 并显式打开 Hooks，可选择运行 `--configure-codex`；它会先备份再修改两个字段：

```toml
personality = "none"

[features]
hooks = true
```

安装器会：

1. 合并到 `~/.codex/hooks.json`，不删除已有 hooks；
2. 在覆盖任何程序文件前创建备份；
3. 安装 `~/.codex/hooks/adaptive_voice_router.py`；
4. 安装可编辑的 `~/.codex/voice-router/voice_contract.md` 与 `config.json`；
5. 只有不使用 `--no-skill` 时，才安装可选的 `$adaptive-human-voice` Skill。

然后重启 Codex，运行：

```text
/hooks
```

检查并 trust 新 Hook 一次。Codex 对变更后的非托管 command hook 会重新要求审查。

## 验证

运行完整测试：

```bash
python3 -m unittest discover -s tests -v
```

预览某个提示会选什么路由：

```bash
python3 src/adaptive_voice_router.py --preview "为什么又失败了，还是不行？"
```

安装后也可以直接运行安装器输出的 preview 命令。

## 调整“像真人”的程度

编辑：

```text
~/.codex/voice-router/voice_contract.md
```

这是唯一主要语气源。建议改行为和示例，而不是堆“嗯、啊、哈哈”。

编辑：

```text
~/.codex/voice-router/config.json
```

可调整：

- `max_discourse_markers`：`null` 表示不设固定数量上限；也可以填写非负整数重新启用硬上限；
- `allow_emojis`：默认 false；
- `default_density`：concise / normal / deep / deep_concise；
- `banned_openers`：默认避免的客服式开场；
- `base_appendix`：追加你的个人语气偏好；v1.1.1 默认启用平衡的自然增强；
- `enabled`：紧急总开关；
- `debug`：只向 stderr 输出 route，不记录用户 prompt。

升级安装默认保留你改过的 Voice Contract 和 config。只有显式使用 `--force-assets` 才会在备份后替换。

## 单回合手动控制

在提示任意位置加入：

```text
@tone:off
@tone:default
@tone:warm
@tone:strict
@tone:concise
@tone:deep
@tone:creative
@tone:debug
```

标签只影响当前回合。

## 与现有 CodexProject 的兼容性

全局 `~/.codex/hooks.json` 与仓库内 `.codex/hooks.json` 会同时加载，不是相互覆盖。因此 CodexProject 已有的 governance `Stop` hook 会保留；本路由器不注册 `Stop`，不会和现有完成检查竞争。

## 已知限制

- Hook 的触发是确定性的；模型的具体措辞仍是概率性的。它比 Skill/AGENTS 自主匹配更强，但不是模型权重级强制。
- “不设数量上限”不是要求每句话都出现语气词；极简、高风险或严格回答仍可为零，普通场景则更积极地使用自然承接。
- 截至 2026-07-18，OpenAI Codex CLI 的公开 issue #16933 / #16486 仍记录 `additionalContext` 可能显示在 TUI history 中且多行渲染不理想。本实现把每回合 context 压成单行短标签，完整契约只在会话事件加载，以降低噪声。
- 不使用 `model_instructions_file`，因为它是替换内建 instructions/AGENTS 的重型开关，不适合只改语气。
- 本路由器不联网、不写入 prompt、不保存会话内容。

## 卸载

```bash
python3 uninstall.py
```

保留你编辑过的 Voice Contract 和 config：

```bash
python3 uninstall.py --keep-assets
```

卸载只移除本路由器的 hook entries 与文件；不会自动反改 `~/.codex/config.toml`。安装器已为该文件创建备份。

## 一手依据

- Codex Hooks: https://developers.openai.com/codex/hooks
- Codex Skills: https://developers.openai.com/codex/build-skills
- Codex Configuration Reference: https://developers.openai.com/codex/config-reference
- Codex CLI issue #16933: https://github.com/openai/codex/issues/16933
- Codex CLI issue #16486: https://github.com/openai/codex/issues/16486
