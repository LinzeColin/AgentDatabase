# Codex Adaptive Human Voice Router - Verification Report

**Date:** 2026-07-19  
**Status:** Ready for local installation
**Version:** 1.1.1

## Decision

Use a hybrid native Codex architecture:

1. `SessionStart` injects one stable, editable Voice Contract.
2. `UserPromptSubmit` deterministically runs on every user turn and injects only a compact adaptive route.
3. `SubagentStart` gives subagents the same contract.
4. A Skill remains optional and manual; it is not treated as an enforcement mechanism.

## Why

Codex Skills support explicit invocation and model-chosen implicit invocation, so a Skill alone cannot guarantee activation on every turn. Codex Hooks are deterministic lifecycle scripts; `UserPromptSubmit` receives the prompt and can add developer context before the turn. Global and repository hook files are merged, preserving CodexProject's existing governance Stop hook.

## Rejected alternatives

- **Skill-only:** activation is not guaranteed.
- **AGENTS-only:** static repository guidance, not a per-turn adaptive trigger.
- **Friendly personality only:** broad default style, not enough behavioral control.
- **model_instructions_file:** replaces built-in instructions instead of merely adding tone guidance.
- **Stop rewrite guard by default:** adds continuation cost and can compete with existing completion workflows; not needed for the first reliable version.

## Implementation properties

- No third-party Python dependencies.
- No network access.
- No prompt logging or persistence.
- Atomic hook-registry writes and timestamped backups.
- Idempotent hook merge.
- Editable assets preserved on upgrades.
- Cross-platform command and commandWindows entries.
- Compact per-turn route to reduce current Codex CLI TUI hook-context noise.
- `max_discourse_markers = null` maps to an explicit unbounded runtime setting without integer coercion errors.
- Balanced natural enhancement is active by default while quick and high-risk responses may remain marker-free.

## Verification evidence

- Python compilation: passed.
- Unit/integration tests: 14/14 passed before packaging.
- Existing Stop hook preservation: tested.
- Repeated installation idempotence: tested.
- Uninstall ownership boundary: tested.
- Deep research + concise output route: tested as `deep_concise`.
- Strict tone does not fabricate high risk: tested.
- False-positive frustration pattern “又快又好”: tested.
- Unbounded marker route and SessionStart contract: tested.

## Confidence

- Hook trigger and merge behavior: high, based on current official Codex documentation and executable tests.
- Tone consistency: medium-high; materially stronger than Skill-only guidance, but exact wording remains model-probabilistic.
- Exact Fable 5 equivalence: not claimable because its private weights/system behavior are not available as a transferable style preset.
