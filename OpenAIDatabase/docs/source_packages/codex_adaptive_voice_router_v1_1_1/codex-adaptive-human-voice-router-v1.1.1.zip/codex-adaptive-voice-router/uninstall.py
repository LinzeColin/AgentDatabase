#!/usr/bin/env python3
"""Remove only the Adaptive Human Voice Router entries and installed files."""

from __future__ import annotations

import argparse
import json
import shutil
import tempfile
import os
import time
from pathlib import Path
from typing import Any

MARKER = "adaptive_voice_router.py"


def contains_marker(entry: Any) -> bool:
    return MARKER in json.dumps(entry, ensure_ascii=False)


def unique_backup(path: Path) -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    candidate = path.with_name(f"{path.name}.backup-{stamp}")
    index = 1
    while candidate.exists():
        candidate = path.with_name(f"{path.name}.backup-{stamp}-{index}")
        index += 1
    shutil.copy2(path, candidate)
    return candidate


def atomic_write_text(path: Path, text: str) -> None:
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except BaseException:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description="Uninstall the Codex Adaptive Human Voice Router.")
    parser.add_argument("--home", type=Path, default=Path.home())
    parser.add_argument("--keep-assets", action="store_true", help="Keep editable config and voice contract.")
    args = parser.parse_args()
    home = args.home.expanduser().resolve()
    codex_home = home / ".codex"
    hooks_path = codex_home / "hooks.json"

    if hooks_path.exists():
        try:
            data = json.loads(hooks_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SystemExit(f"Refusing to edit invalid JSON: {hooks_path}: {exc}") from exc
        if not isinstance(data, dict):
            raise SystemExit(f"Refusing to edit non-object JSON: {hooks_path}")
        backup = unique_backup(hooks_path)
        hooks = data.get("hooks", {})
        if isinstance(hooks, dict):
            for event, groups in list(hooks.items()):
                if isinstance(groups, list):
                    hooks[event] = [group for group in groups if not contains_marker(group)]
                    if not hooks[event]:
                        hooks.pop(event)
        atomic_write_text(hooks_path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
        print(f"Updated {hooks_path}; backup: {backup}")

    paths = [
        codex_home / "hooks" / MARKER,
        home / ".agents" / "skills" / "adaptive-human-voice" / "SKILL.md",
    ]
    if not args.keep_assets:
        paths.extend(
            [
                codex_home / "voice-router" / "config.json",
                codex_home / "voice-router" / "voice_contract.md",
            ]
        )

    for path in paths:
        try:
            path.unlink()
            print(f"Removed {path}")
        except FileNotFoundError:
            pass

    for directory in [
        codex_home / "voice-router",
        home / ".agents" / "skills" / "adaptive-human-voice",
    ]:
        try:
            directory.rmdir()
        except OSError:
            pass

    print("Note: ~/.codex/config.toml is not reverted automatically; use the installer-created backup if needed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
