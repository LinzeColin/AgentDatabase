# Codex Task Pack - Adaptive Human Voice Router

## Objective

Install a global, adaptive communication layer for Codex that applies on every user turn without relying on implicit Skill selection, while preserving repository governance hooks.

## Scope

- Global user hook registry: `~/.codex/hooks.json`
- Global voice assets: `~/.codex/voice-router/`
- Optional user Skill: `~/.agents/skills/adaptive-human-voice/`
- Optional safe patch to `~/.codex/config.toml`

## Non-goals

- Replacing Codex model weights or exactly cloning Anthropic Fable 5 internals
- Replacing built-in Codex instructions with `model_instructions_file`
- Post-generation rewriting or a custom App Server frontend
- Logging or persisting user prompts

## Deployment

```bash
python3 install.py --no-skill
```

Restart Codex, then run `/hooks` and trust the three definitions.

## Acceptance criteria

- `SessionStart`, `UserPromptSubmit`, and `SubagentStart` entries exist once each.
- Pre-existing global and repository hooks remain unchanged.
- Hook-only installation leaves `~/.codex/config.toml` unchanged.
- `max_discourse_markers = null` produces an unbounded runtime marker setting.
- `--preview` returns the expected route for debug, decision, high-risk, creative, and deep+concise prompts.
- Unit and integration tests pass.
- Uninstall removes only router-owned entries/files.

## Validation

```bash
python3 -m py_compile install.py uninstall.py src/adaptive_voice_router.py
python3 -m unittest discover -s tests -v
python3 src/adaptive_voice_router.py --preview "全网深度验证，最后仅输出简明结论"
```

Expected density: `deep_concise`.

## Rollback

```bash
python3 uninstall.py
```

When the default `--no-skill` path is used, `~/.codex/config.toml` does not need restoration.

## Residual risks

- Exact wording remains model-probabilistic.
- Codex CLI may visibly render hook context; per-turn context is intentionally compact.
- Regex routing can be coarse; explicit user instructions and the semantic contract remain higher priority.
