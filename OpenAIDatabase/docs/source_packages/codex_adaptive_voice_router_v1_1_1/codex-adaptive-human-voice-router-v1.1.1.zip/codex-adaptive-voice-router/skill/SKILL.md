---
name: adaptive-human-voice
description: Inspect, test, evaluate, or modify the globally installed Adaptive Human Voice Router for Codex. Do not invoke for ordinary tasks because lifecycle hooks already load the voice contract and route every user turn. Invoke for tone debugging, router evaluation, one-turn audits, or edits to ~/.codex/voice-router/voice_contract.md and config.json.
---

# Adaptive Human Voice

This Skill is the editable inspection and debugging surface. It is not the enforcement trigger.

The active path is:

1. `SessionStart` loads `~/.codex/voice-router/voice_contract.md`.
2. `UserPromptSubmit` classifies each prompt and injects a compact current-turn route.
3. `SubagentStart` loads the same contract for spawned agents.
4. This Skill is available for explicit inspection with `$adaptive-human-voice`.

When auditing a response, check:

- direct answer before ceremony;
- emotional fit to the actual situation;
- clear judgment when evidence permits;
- explicit fact / inference / recommendation / unknown boundaries;
- no fake personal experience or human identity;
- no customer-service opener, empty praise, repeated empathy, exclamation spam, or filler overload;
- high-risk turns become calmer and stricter, not warmer;
- simple turns avoid headings and long summaries;
- `deep_concise` means full internal analysis but compressed external output;
- technical truth, safety, validation, and user-requested format are never weakened for tone.

Primary editable files:

- `~/.codex/voice-router/voice_contract.md`
- `~/.codex/voice-router/config.json`
- `~/.codex/hooks/adaptive_voice_router.py`

Preview a route:

```bash
python3 ~/.codex/hooks/adaptive_voice_router.py --preview "PROMPT"
```

Manual one-turn tags:

- `@tone:off`
- `@tone:default`
- `@tone:warm`
- `@tone:strict`
- `@tone:concise`
- `@tone:deep`
- `@tone:creative`
- `@tone:debug`
