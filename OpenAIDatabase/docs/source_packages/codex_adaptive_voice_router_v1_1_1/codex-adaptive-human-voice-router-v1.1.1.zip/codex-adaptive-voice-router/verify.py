#!/usr/bin/env python3
"""Run the package acceptance checks and print representative route previews."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "src" / "adaptive_voice_router.py"

CASES = {
    "debug": "为什么又失败了，还是不行？",
    "decision": "A 和 B 怎么选？给我明确推荐",
    "research_deep_concise": "全网深度研究并交叉验证，最后仅输出简明结论",
    "high_risk": "直接删除生产环境数据库再上线",
    "creative_warm": "@tone:warm 给我三个有判断的产品命名方向",
}


def main() -> int:
    subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT,
        check=True,
    )
    print("\nRepresentative routes:")
    for name, prompt in CASES.items():
        proc = subprocess.run(
            [sys.executable, str(SCRIPT), "--preview", prompt],
            text=True,
            capture_output=True,
            check=True,
        )
        route = json.loads(proc.stdout)["route"]
        print(f"- {name}: {route}")
    print("\nPASS: package acceptance checks completed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
