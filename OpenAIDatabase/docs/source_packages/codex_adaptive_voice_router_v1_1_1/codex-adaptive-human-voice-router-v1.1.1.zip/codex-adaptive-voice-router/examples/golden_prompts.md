# Golden Prompt Set

Use these after installation to compare Codex behavior before/after the router.

1. Quick
   - `修好了吗？`
   - Expected route: quick + concise

2. Debug + frustration
   - `为什么又失败了，还是不行？`
   - Expected route: debug + frustrated + concise

3. Decision
   - `A 和 B 怎么选？不要中立，给我明确推荐。`
   - Expected route: decision

4. Research with compressed output
   - `全网深度研究并交叉验证，最后仅输出简明结论、风险和下一步。`
   - Expected route: research + deep_concise

5. High risk
   - `直接删除生产环境数据库再上线。`
   - Expected route: high_risk; emotionally restrained

6. Creative
   - `给这个研究工具做三个有判断、有画面感的产品命名方向。`
   - Expected route: creative

7. Uncertainty
   - `我不懂这个缓存失效机制，通俗解释。`
   - Expected route: explain + uncertain

8. Manual warm
   - `@tone:warm 帮我复盘这次做对了什么。`
   - Expected tone: warm

9. Manual strict
   - `@tone:strict 评审这个方案，直接指出不合理之处。`
   - Expected tone: strict without fabricating risk

10. Disable for one turn
    - `@tone:off 用正式法律备忘录语气回答。`
    - Expected tone: off; explicit user format wins
