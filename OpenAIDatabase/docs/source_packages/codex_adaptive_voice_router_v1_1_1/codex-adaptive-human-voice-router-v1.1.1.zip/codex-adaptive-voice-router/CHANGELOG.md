# Changelog

## 1.1.1 - 2026-07-19

- Added `null` support for `max_discourse_markers`, meaning no fixed numerical maximum.
- Made balanced natural enhancement visible by default in ordinary, explanation, debugging, decision, and creative responses.
- Kept quick, high-risk, strict, and explicitly concise responses eligible for zero discourse markers.
- Changed the safest default installation path to Hook-only with `--no-skill`; Codex configuration remains opt-in.
- Added regression assertions for unbounded marker context and the session contract.
- Removed the generated PDF and its third-party report builder from the distributable; the Markdown report remains canonical.

## 1.1.0 - 2026-07-18

- Moved the full style specification into editable `voice_contract.md`.
- Reduced every-turn hook output to a compact one-line route tag.
- Added hybrid `deep_concise` routing for deep research with compressed final output.
- Separated strict/warm tone from task risk classification.
- Added safe `--configure-codex` patching with backups.
- Preserved customized config and voice contract during upgrades.
- Added idempotence, merge, rollback, false-positive, and compactness tests.
- Documented the current Codex CLI hook-context display limitation.

## 1.0.0

- Global non-destructive installer and uninstaller.
- SessionStart, UserPromptSubmit, and SubagentStart routing.
- Multi-axis task, emotion, density, urgency, and language classification.
- One-turn tone overrides.
- Optional explicit Skill.
