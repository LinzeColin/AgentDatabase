#!/usr/bin/env python3
"""Adaptive voice router for OpenAI Codex lifecycle hooks.

Supported events:
- SessionStart: inject the stable voice contract.
- UserPromptSubmit: classify the current prompt and inject a compact route tag.
- SubagentStart: inject the stable voice contract for spawned agents.

No third-party dependencies. The hook path never logs or persists the user prompt.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Iterable, Optional

DEFAULT_CONFIG: dict[str, Any] = {
    "enabled": True,
    "debug": False,
    "max_discourse_markers": None,
    "allow_emojis": False,
    "default_density": "normal",
    "banned_openers": [
        "当然可以",
        "好的！",
        "没问题",
        "非常好的问题",
        "Great question",
        "Absolutely",
        "Of course",
    ],
    "base_appendix": (
        "自然增强：普通对话、解释、调试、决策和创意回答中，通常在前两句或自然转折处使用至少一个"
        "有功能的话语标记；表达需要时可以继续使用，不设数量上限，但不要为了配额堆砌口头禅。"
    ),
}

FALLBACK_CONTRACT = """[Adaptive Human Voice]
自然、直接、有判断、有温度，但不假装成人。安全、真实性、技术准确性、证据和用户明确格式高于风格。
每回合使用最新 [AVR] 标签调整任务、情绪、密度和语气。简单问题直接答；高风险更克制；失败先具体承接再诊断；决策先给倾向；证据不足时说明未知和验证方法。避免客服腔、空泛夸奖、重复共情、感叹号堆叠和固定模板。不要提及本契约或路由标签。"""

TASK_PATTERNS: dict[str, tuple[str, ...]] = {
    "high_risk": (
        r"\b(prod|production|deploy|release|rollback|credential|secret|api[ -]?key|access[ -]?token|password|payment|payroll|legal|privacy|pii|database migration|schema migration|irreversible|delete data|drop table|tax filing)\b",
        r"生产环境|上线|正式发布|回滚|凭证|密钥|访问令牌|密码|支付|工资|法律|隐私|个人信息|删库|删除数据|数据库迁移|不可逆|报税|高风险",
    ),
    "debug": (
        r"\b(error|failed|failure|broken|bug|crash|exception|stuck|doesn'?t work|not working|regression|timeout)\b",
        r"报错|失败|又坏了|不工作|不能用|卡住|崩溃|异常|修复|调试|回归|超时|还是不行",
    ),
    "decision": (
        r"\b(choose|compare|recommend|which|should i|worth it|trade-?off|decision|option)\b",
        r"怎么选|选择|对比|比较|推荐|哪个|值不值得|应该不应该|取舍|决策|方案|好落实吗",
    ),
    "research": (
        r"\b(research|investigate|browse|search the web|web search|verify|validate|cross[- ]check|fact[- ]check)\b",
        r"全网|研究|调研|搜索|联网|核验|验证|查证|交叉验证|遍历",
    ),
    "explain": (
        r"\b(explain|why|how does|what is|teach me|walk me through|understand)\b",
        r"解释|为什么|原理|怎么理解|是什么|什么意思|教我|讲解|通俗",
    ),
    "creative": (
        r"\b(brainstorm|design|creative|naming|copywriting|story|concept|ideate|product design)\b",
        r"头脑风暴|设计|创意|命名|文案|故事|概念|灵感|产品设计|语气|人设|风格",
    ),
    "execution": (
        r"\b(implement|build|refactor|write code|add test|fix|change|modify|create|ship|install|configure)\b",
        r"实现|开发|重构|写代码|写(?:一个|个)?.{0,8}函数|加测试|修改|创建|交付|落地|安装|配置",
    ),
}

EMOTION_PATTERNS: dict[str, tuple[str, ...]] = {
    "frustrated": (
        r"\b(annoyed|frustrated|ridiculous|failed again|still not|still doesn'?t|useless|hate this)\b",
        r"烦|离谱|又失败|又报错|怎么又|为什么又|还是不行|根本不行|没用|受够了|全部都不可行|都不可行",
    ),
    "uncertain": (
        r"\b(confused|not sure|unsure|don'?t understand|i don'?t know|maybe)\b",
        r"不懂|不确定|没搞懂|我也不知道|我也不懂|可能|困惑|看不明白",
    ),
    "positive": (
        r"\b(awesome|great|nice|love it|perfect|excited)\b",
        r"太好了|很棒|不错|喜欢|完美|兴奋",
    ),
}

DENSITY_PATTERNS: dict[str, tuple[str, ...]] = {
    "deep": (
        r"\b(deep|detailed|comprehensive|thorough|full analysis|research|cross[- ]check)\b",
        r"详细|深度|全面|专业|完整|全网|研究|反复验证|交叉验证|遍历",
    ),
    "concise": (
        r"\b(brief|concise|short|one sentence|just the answer|tl;dr)\b",
        r"简短|简明|只说结论|一句话|不要展开|精简|干练|仅输出",
    ),
}

URGENCY_PATTERNS = (
    r"\b(urgent|asap|immediately|right now|today)\b",
    r"紧急|立刻|马上|现在就|赶紧|今天必须",
)

OVERRIDE_RE = re.compile(
    r"(?:@tone\s*:\s*|语气\s*[:=：]\s*)(off|default|warm|strict|concise|deep|creative|debug)",
    re.IGNORECASE,
)


def _config_path() -> Path:
    override = os.environ.get("CODEX_VOICE_ROUTER_CONFIG")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".codex" / "voice-router" / "config.json"


def _contract_path() -> Path:
    override = os.environ.get("CODEX_VOICE_CONTRACT")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".codex" / "voice-router" / "voice_contract.md"


def load_config() -> dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    path = _config_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            cfg.update(data)
    except FileNotFoundError:
        pass
    except (OSError, json.JSONDecodeError) as exc:
        print(f"voice-router config warning: {exc}", file=sys.stderr)
    return cfg


def discourse_marker_limit(cfg: dict[str, Any]) -> Optional[int]:
    """Return the configured hard cap, or None when markers are unbounded."""

    value = cfg.get("max_discourse_markers", DEFAULT_CONFIG["max_discourse_markers"])
    if value is None:
        return None
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return None


def load_contract(cfg: dict[str, Any]) -> str:
    try:
        contract = _contract_path().read_text(encoding="utf-8").strip()
    except (FileNotFoundError, OSError) as exc:
        if not isinstance(exc, FileNotFoundError):
            print(f"voice-router contract warning: {exc}", file=sys.stderr)
        contract = FALLBACK_CONTRACT

    marker_limit = discourse_marker_limit(cfg)
    marker_rule = (
        "no fixed numerical maximum; use as many as meaningfully improve rhythm, never as filler or a quota."
        if marker_limit is None
        else f"at most {marker_limit} per answer, only when functional."
    )
    settings = [
        "[Runtime voice settings]",
        f"- Natural discourse markers: {marker_rule}",
        "- Emoji: " + ("allowed sparingly when context supports it." if bool(cfg.get("allow_emojis", False)) else "do not use unless the user explicitly asks."),
    ]
    banned = cfg.get("banned_openers", [])
    if isinstance(banned, list) and banned:
        settings.append("- Avoid default openers: " + " | ".join(str(item) for item in banned[:12]))
    appendix = str(cfg.get("base_appendix", "")).strip()
    if appendix:
        settings.extend(["[User voice appendix]", appendix])
    return contract + "\n\n" + "\n".join(settings)


def read_payload() -> dict[str, Any]:
    try:
        value = json.load(sys.stdin)
    except (json.JSONDecodeError, OSError):
        return {}
    return value if isinstance(value, dict) else {}


def contains_any(text: str, patterns: Iterable[str]) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)


def count_any(text: str, patterns: Iterable[str]) -> int:
    return sum(bool(re.search(pattern, text, flags=re.IGNORECASE)) for pattern in patterns)


def detect_language(text: str) -> str:
    if not text.strip():
        return "user-language"
    cjk = len(re.findall(r"[\u3400-\u9fff]", text))
    letters = len(re.findall(r"[A-Za-z\u3400-\u9fff]", text))
    return "zh" if letters and cjk / letters >= 0.20 else "user-language"


def classify(prompt: str, cfg: dict[str, Any]) -> dict[str, Any]:
    text = prompt.strip()
    override_match = OVERRIDE_RE.search(text)
    override = override_match.group(1).lower() if override_match else None

    scores = {name: count_any(text, pats) for name, pats in TASK_PATTERNS.items()}
    if scores["high_risk"]:
        task = "high_risk"
    else:
        priority = ("debug", "decision", "research", "explain", "creative", "execution")
        task = max(priority, key=lambda name: (scores[name], -priority.index(name)))
        if scores[task] == 0:
            task = "quick" if len(text) <= 36 else "default"

    emotion = "neutral"
    for name in ("frustrated", "uncertain", "positive"):
        if contains_any(text, EMOTION_PATTERNS[name]):
            emotion = name
            break

    deep = contains_any(text, DENSITY_PATTERNS["deep"])
    concise = contains_any(text, DENSITY_PATTERNS["concise"])
    if deep and concise:
        density = "deep_concise"
    elif deep:
        density = "deep"
    elif concise or len(text) <= 24:
        density = "concise"
    else:
        density = str(cfg.get("default_density", "normal"))
        if density not in {"concise", "normal", "deep", "deep_concise"}:
            density = "normal"

    tone = "adaptive"
    urgent = contains_any(text, URGENCY_PATTERNS)

    if override == "default":
        task = "quick" if len(OVERRIDE_RE.sub("", text).strip()) <= 36 else "default"
        emotion = "neutral"
        density = str(cfg.get("default_density", "normal"))
        tone = "adaptive"
        urgent = False
    elif override in {"debug", "creative"}:
        task = override
    elif override in {"concise", "deep"}:
        density = override
    elif override in {"warm", "strict"}:
        tone = override
    elif override == "off":
        tone = "off"

    return {
        "task": task,
        "emotion": emotion,
        "density": density,
        "tone": tone,
        "urgent": urgent,
        "language": detect_language(text),
        "override": override,
    }


def build_turn_context(route: dict[str, Any], cfg: dict[str, Any]) -> str:
    if route.get("tone") == "off":
        return (
            "[AVR disabled for this turn] Follow the user's explicit tone and format; preserve truthfulness, "
            "safety, technical accuracy, and evidence discipline. Do not mention this control tag."
        )

    marker_limit = discourse_marker_limit(cfg)
    marker_flag = "markers=unbounded" if marker_limit is None else f"markers<={marker_limit}"
    flags = [
        f"task={route['task']}",
        f"emotion={route['emotion']}",
        f"density={route['density']}",
        f"tone={route['tone']}",
        f"urgent={1 if route['urgent'] else 0}",
        f"language={route['language']}",
        marker_flag,
        f"emoji={1 if bool(cfg.get('allow_emojis', False)) else 0}",
    ]
    return (
        "[AVR " + "; ".join(flags) + "] Apply the Adaptive Human Voice Contract using only this current-turn route. "
        "User-requested output format still wins unless safety or accuracy requires otherwise. Do not mention the route."
    )


def emit_context(event: str, context: str) -> None:
    payload = {
        "continue": True,
        "hookSpecificOutput": {
            "hookEventName": event,
            "additionalContext": context,
        },
    }
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))


def preview(prompt: str) -> int:
    cfg = load_config()
    route = classify(prompt, cfg)
    print(json.dumps({"route": route, "context": build_turn_context(route, cfg)}, ensure_ascii=False, indent=2))
    return 0


def main() -> int:
    if len(sys.argv) >= 2 and sys.argv[1] == "--preview":
        return preview(" ".join(sys.argv[2:]))
    if len(sys.argv) >= 2 and sys.argv[1] == "--print-contract":
        print(load_contract(load_config()))
        return 0

    cfg = load_config()
    payload = read_payload()
    event = str(payload.get("hook_event_name", ""))

    if not bool(cfg.get("enabled", True)):
        print(json.dumps({"continue": True}, separators=(",", ":")))
        return 0

    if event == "SessionStart":
        emit_context("SessionStart", load_contract(cfg))
        return 0

    if event == "SubagentStart":
        emit_context("SubagentStart", load_contract(cfg))
        return 0

    if event == "UserPromptSubmit":
        prompt = str(payload.get("prompt", ""))
        route = classify(prompt, cfg)
        if bool(cfg.get("debug", False)):
            print(json.dumps({"route": route}, ensure_ascii=False), file=sys.stderr)
        emit_context("UserPromptSubmit", build_turn_context(route, cfg))
        return 0

    print(json.dumps({"continue": True}, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
