#!/usr/bin/env python3
"""Install the Adaptive Human Voice Router globally for Codex.

Safety properties:
- existing ~/.codex/hooks.json entries are preserved;
- every overwritten file is backed up;
- editable router config and voice contract are preserved on upgrades unless --force-assets;
- ~/.codex/config.toml is changed only with --configure-codex.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

MARKER = "adaptive_voice_router.py"
STATUS_SESSION = "Loading adaptive human voice"
STATUS_TURN = "Adapting response voice"


def load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Refusing to overwrite invalid JSON: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit(f"Refusing to overwrite non-object JSON: {path}")
    return value


def unique_backup(path: Path) -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    candidate = path.with_name(f"{path.name}.backup-{stamp}")
    index = 1
    while candidate.exists():
        candidate = path.with_name(f"{path.name}.backup-{stamp}-{index}")
        index += 1
    shutil.copy2(path, candidate)
    return candidate


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except BaseException:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def contains_marker(entry: Any) -> bool:
    return MARKER in json.dumps(entry, ensure_ascii=False)


def quote_posix(path: Path) -> str:
    import shlex

    return shlex.quote(str(path))


def quote_windows(path: Path) -> str:
    return subprocess.list2cmdline([str(path)])


def hook_group(event: str, python_path: Path, script_path: Path, status: str) -> dict[str, Any]:
    handler: dict[str, Any] = {
        "type": "command",
        "command": f"{quote_posix(python_path)} {quote_posix(script_path)}",
        "commandWindows": f"{quote_windows(python_path)} {quote_windows(script_path)}",
        "timeout": 5,
        "statusMessage": status,
    }
    group: dict[str, Any] = {"hooks": [handler]}
    if event == "SessionStart":
        group["matcher"] = "startup|resume|clear|compact"
    return group


def merge_hooks(path: Path, python_path: Path, script_path: Path) -> Path | None:
    data = load_json(path)
    hooks = data.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        raise SystemExit(f"Expected 'hooks' object in {path}")

    desired = {
        "SessionStart": hook_group("SessionStart", python_path, script_path, STATUS_SESSION),
        "UserPromptSubmit": hook_group("UserPromptSubmit", python_path, script_path, STATUS_TURN),
        "SubagentStart": hook_group("SubagentStart", python_path, script_path, "Loading subagent voice"),
    }

    for event, group in desired.items():
        existing = hooks.setdefault(event, [])
        if not isinstance(existing, list):
            raise SystemExit(f"Expected hooks.{event} to be an array in {path}")
        hooks[event] = [item for item in existing if not contains_marker(item)]
        hooks[event].append(group)

    backup = unique_backup(path) if path.exists() else None
    atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    return backup


def install_file(source: Path, target: Path, *, preserve_existing: bool) -> tuple[str, Path | None]:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and preserve_existing:
        return "preserved", None
    backup = unique_backup(target) if target.exists() else None
    shutil.copy2(source, target)
    return "installed", backup


def validate_toml(text: str, path: Path) -> None:
    try:
        import tomllib
    except ImportError:
        return
    try:
        tomllib.loads(text)
    except Exception as exc:  # tomllib raises TOMLDecodeError, kept broad for old Python variants.
        raise SystemExit(f"Refusing to edit invalid TOML: {path}: {exc}") from exc


def patch_codex_config(path: Path) -> Path | None:
    original = path.read_text(encoding="utf-8") if path.exists() else ""
    if original:
        validate_toml(original, path)
    lines = original.splitlines()

    first_section = next((i for i, line in enumerate(lines) if re.match(r"^\s*\[", line)), len(lines))
    personality_re = re.compile(r'^\s*personality\s*=\s*["\'][^"\']*["\']\s*(?:#.*)?$')
    top_personality = next((i for i in range(first_section) if personality_re.match(lines[i])), None)
    if top_personality is not None:
        comment = ""
        if "#" in lines[top_personality]:
            comment = "  #" + lines[top_personality].split("#", 1)[1]
        lines[top_personality] = f'personality = "none"{comment}'
    else:
        insert_at = 0
        while insert_at < len(lines) and (not lines[insert_at].strip() or lines[insert_at].lstrip().startswith("#")):
            insert_at += 1
        lines.insert(insert_at, 'personality = "none"')
        if insert_at + 1 < len(lines) and lines[insert_at + 1].strip():
            lines.insert(insert_at + 1, "")

    features_start = next((i for i, line in enumerate(lines) if re.match(r"^\s*\[features\]\s*(?:#.*)?$", line)), None)
    if features_start is None:
        while lines and not lines[-1].strip():
            lines.pop()
        if lines:
            lines.append("")
        lines.extend(["[features]", "hooks = true"])
    else:
        features_end = next(
            (i for i in range(features_start + 1, len(lines)) if re.match(r"^\s*\[", lines[i])),
            len(lines),
        )
        hook_re = re.compile(r"^\s*hooks\s*=\s*(?:true|false)\s*(?:#.*)?$", re.IGNORECASE)
        hook_line = next((i for i in range(features_start + 1, features_end) if hook_re.match(lines[i])), None)
        if hook_line is not None:
            comment = ""
            if "#" in lines[hook_line]:
                comment = "  #" + lines[hook_line].split("#", 1)[1]
            lines[hook_line] = f"hooks = true{comment}"
        else:
            lines.insert(features_start + 1, "hooks = true")

    updated = "\n".join(lines).rstrip() + "\n"
    validate_toml(updated, path)
    if updated == original:
        return None
    backup = unique_backup(path) if path.exists() else None
    atomic_write_text(path, updated)
    return backup


def inspect_config(config_path: Path) -> list[str]:
    warnings: list[str] = []
    if not config_path.exists():
        warnings.append("~/.codex/config.toml does not exist; hooks are enabled by default in current Codex releases.")
        return warnings
    text = config_path.read_text(encoding="utf-8", errors="replace")
    if re.search(r"^\s*hooks\s*=\s*false\b", text, flags=re.MULTILINE):
        warnings.append("Your config contains hooks = false. Change it to hooks = true before testing.")
    if re.search(r"^\s*model_instructions_file\s*=", text, flags=re.MULTILINE):
        warnings.append("model_instructions_file is present. It replaces built-in/AGENTS instructions; review it for conflicts.")
    return warnings


def main() -> int:
    parser = argparse.ArgumentParser(description="Install the Codex Adaptive Human Voice Router globally.")
    parser.add_argument("--home", type=Path, default=Path.home(), help="Override home directory for testing.")
    parser.add_argument("--no-skill", action="store_true", help="Do not install the optional manual skill.")
    parser.add_argument(
        "--force-assets",
        action="store_true",
        help="Replace existing editable config/voice contract after backing them up.",
    )
    parser.add_argument(
        "--configure-codex",
        action="store_true",
        help='Safely set top-level personality = "none" and [features].hooks = true in ~/.codex/config.toml.',
    )
    args = parser.parse_args()

    package = Path(__file__).resolve().parent
    home = args.home.expanduser().resolve()
    codex_home = home / ".codex"
    hook_dir = codex_home / "hooks"
    router_dir = codex_home / "voice-router"
    script_target = hook_dir / MARKER
    config_target = router_dir / "config.json"
    contract_target = router_dir / "voice_contract.md"
    hooks_json = codex_home / "hooks.json"

    hook_dir.mkdir(parents=True, exist_ok=True)
    router_dir.mkdir(parents=True, exist_ok=True)

    script_status, script_backup = install_file(package / "src" / MARKER, script_target, preserve_existing=False)
    script_target.chmod(script_target.stat().st_mode | stat.S_IXUSR)
    config_status, config_backup = install_file(
        package / "src" / "config.json", config_target, preserve_existing=not args.force_assets
    )
    contract_status, contract_backup = install_file(
        package / "src" / "voice_contract.md", contract_target, preserve_existing=not args.force_assets
    )

    python_path = Path(sys.executable).resolve()
    hooks_backup = merge_hooks(hooks_json, python_path, script_target)

    skill_status = "skipped"
    skill_backup: Path | None = None
    if not args.no_skill:
        skill_target = home / ".agents" / "skills" / "adaptive-human-voice" / "SKILL.md"
        skill_status, skill_backup = install_file(package / "skill" / "SKILL.md", skill_target, preserve_existing=False)

    codex_config_backup: Path | None = None
    if args.configure_codex:
        codex_config_backup = patch_codex_config(codex_home / "config.toml")

    print("Installed Adaptive Human Voice Router.")
    print(f"  Hook script ({script_status}): {script_target}")
    print(f"  Router config ({config_status}): {config_target}")
    print(f"  Voice contract ({contract_status}): {contract_target}")
    print(f"  Hook registry: {hooks_json}")
    if not args.no_skill:
        print(f"  Skill ({skill_status}): {home / '.agents' / 'skills' / 'adaptive-human-voice' / 'SKILL.md'}")
    if args.configure_codex:
        print(f"  Codex config patched: {codex_home / 'config.toml'}")

    backups = [script_backup, config_backup, contract_backup, hooks_backup, skill_backup, codex_config_backup]
    for backup in (item for item in backups if item is not None):
        print(f"  Backup: {backup}")

    for warning in inspect_config(codex_home / "config.toml"):
        print(f"WARNING: {warning}")

    print("\nNext: restart Codex, run /hooks, review the definitions, and trust them once.")
    print(f"Preview: {python_path} {script_target} --preview '为什么又失败了？'")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
