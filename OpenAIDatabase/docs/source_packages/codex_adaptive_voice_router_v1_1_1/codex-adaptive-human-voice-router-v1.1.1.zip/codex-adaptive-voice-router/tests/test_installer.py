from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALL = ROOT / "install.py"
UNINSTALL = ROOT / "uninstall.py"
MARKER = "adaptive_voice_router.py"


class InstallerTests(unittest.TestCase):
    def test_install_is_idempotent_and_preserves_existing_stop_hook(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            codex = home / ".codex"
            codex.mkdir()
            existing = {
                "description": "existing",
                "hooks": {
                    "Stop": [
                        {
                            "hooks": [
                                {
                                    "type": "command",
                                    "command": "python3 repo_governance_stop.py",
                                    "timeout": 5,
                                }
                            ]
                        }
                    ]
                },
            }
            (codex / "hooks.json").write_text(json.dumps(existing), encoding="utf-8")

            for _ in range(2):
                subprocess.run(
                    [sys.executable, str(INSTALL), "--home", str(home), "--configure-codex"],
                    check=True,
                    text=True,
                    capture_output=True,
                )

            data = json.loads((codex / "hooks.json").read_text(encoding="utf-8"))
            self.assertEqual(data["description"], "existing")
            self.assertIn("Stop", data["hooks"])
            self.assertIn("repo_governance_stop.py", json.dumps(data["hooks"]["Stop"]))
            for event in ("SessionStart", "UserPromptSubmit", "SubagentStart"):
                matches = [entry for entry in data["hooks"][event] if MARKER in json.dumps(entry)]
                self.assertEqual(len(matches), 1)

            config_text = (codex / "config.toml").read_text(encoding="utf-8")
            self.assertIn('personality = "none"', config_text)
            self.assertIn("hooks = true", config_text)

            subprocess.run(
                [sys.executable, str(UNINSTALL), "--home", str(home)],
                check=True,
                text=True,
                capture_output=True,
            )
            after = json.loads((codex / "hooks.json").read_text(encoding="utf-8"))
            self.assertIn("repo_governance_stop.py", json.dumps(after["hooks"]["Stop"]))
            for event in ("SessionStart", "UserPromptSubmit", "SubagentStart"):
                self.assertNotIn(event, after["hooks"])

    def test_upgrade_preserves_editable_assets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            target = home / ".codex" / "voice-router"
            target.mkdir(parents=True)
            custom_config = '{"enabled": true, "max_discourse_markers": 1}\n'
            custom_contract = "CUSTOM CONTRACT\n"
            (target / "config.json").write_text(custom_config, encoding="utf-8")
            (target / "voice_contract.md").write_text(custom_contract, encoding="utf-8")

            subprocess.run(
                [sys.executable, str(INSTALL), "--home", str(home)],
                check=True,
                text=True,
                capture_output=True,
            )
            self.assertEqual((target / "config.json").read_text(encoding="utf-8"), custom_config)
            self.assertEqual((target / "voice_contract.md").read_text(encoding="utf-8"), custom_contract)


if __name__ == "__main__":
    unittest.main()
