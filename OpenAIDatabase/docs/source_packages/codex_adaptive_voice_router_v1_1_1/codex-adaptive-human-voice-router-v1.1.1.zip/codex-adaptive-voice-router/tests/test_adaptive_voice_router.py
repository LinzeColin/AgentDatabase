from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "src" / "adaptive_voice_router.py"
CONTRACT = ROOT / "src" / "voice_contract.md"

spec = importlib.util.spec_from_file_location("router", SCRIPT)
assert spec and spec.loader
router = importlib.util.module_from_spec(spec)
spec.loader.exec_module(router)


class ClassifierTests(unittest.TestCase):
    def setUp(self) -> None:
        self.cfg = dict(router.DEFAULT_CONFIG)

    def test_high_risk_wins(self) -> None:
        route = router.classify("直接删掉 production 数据库再上线", self.cfg)
        self.assertEqual(route["task"], "high_risk")

    def test_debug_and_frustration(self) -> None:
        route = router.classify("为什么又失败了，还是不行？", self.cfg)
        self.assertEqual(route["task"], "debug")
        self.assertEqual(route["emotion"], "frustrated")

    def test_decision(self) -> None:
        route = router.classify("A 和 B 怎么选？给我推荐", self.cfg)
        self.assertEqual(route["task"], "decision")

    def test_deep_concise_density(self) -> None:
        route = router.classify("全网深度研究并详细验证，最后仅输出简明结论", self.cfg)
        self.assertEqual(route["task"], "research")
        self.assertEqual(route["density"], "deep_concise")

    def test_manual_strict_changes_tone_not_risk(self) -> None:
        route = router.classify("@tone:strict 写一个普通函数", self.cfg)
        self.assertEqual(route["task"], "execution")
        self.assertEqual(route["tone"], "strict")

    def test_manual_warm(self) -> None:
        route = router.classify("@tone:warm 解释一下", self.cfg)
        self.assertEqual(route["tone"], "warm")
        self.assertEqual(route["task"], "explain")
        capped = dict(self.cfg, max_discourse_markers=3)
        self.assertIn("markers<=3", router.build_turn_context(route, capped))

    def test_manual_default_resets(self) -> None:
        route = router.classify("@tone:default 为什么又失败了", self.cfg)
        self.assertEqual(route["task"], "quick")
        self.assertEqual(route["emotion"], "neutral")

    def test_short_prompt_is_quick(self) -> None:
        route = router.classify("修好了吗？", self.cfg)
        self.assertEqual(route["task"], "quick")
        self.assertEqual(route["density"], "concise")

    def test_plain_you_is_not_frustration(self) -> None:
        route = router.classify("这个方案又快又好", self.cfg)
        self.assertNotEqual(route["emotion"], "frustrated")


class HookOutputTests(unittest.TestCase):
    def run_hook(self, payload: dict[str, object]) -> dict[str, object]:
        with tempfile.TemporaryDirectory() as tmp:
            env = os.environ.copy()
            env.update(
                {
                    "HOME": tmp,
                    "CODEX_VOICE_ROUTER_CONFIG": str(Path(tmp) / "missing.json"),
                    "CODEX_VOICE_CONTRACT": str(CONTRACT),
                }
            )
            proc = subprocess.run(
                [sys.executable, str(SCRIPT)],
                input=json.dumps(payload, ensure_ascii=False),
                text=True,
                capture_output=True,
                check=True,
                env=env,
            )
            self.assertEqual(proc.stderr, "")
            return json.loads(proc.stdout)

    def test_session_start_schema(self) -> None:
        out = self.run_hook({"hook_event_name": "SessionStart", "source": "startup"})
        self.assertTrue(out["continue"])
        self.assertEqual(out["hookSpecificOutput"]["hookEventName"], "SessionStart")
        self.assertIn("Adaptive Human Voice Contract", out["hookSpecificOutput"]["additionalContext"])
        self.assertIn("no fixed numerical maximum", out["hookSpecificOutput"]["additionalContext"])

    def test_prompt_submit_schema_and_compactness(self) -> None:
        out = self.run_hook({"hook_event_name": "UserPromptSubmit", "prompt": "为什么又报错了？"})
        self.assertEqual(out["hookSpecificOutput"]["hookEventName"], "UserPromptSubmit")
        context = out["hookSpecificOutput"]["additionalContext"]
        self.assertIn("task=debug", context)
        self.assertIn("markers=unbounded", context)
        self.assertIn("Do not mention", context)
        self.assertLess(len(context), 500)

    def test_disabled_turn(self) -> None:
        out = self.run_hook({"hook_event_name": "UserPromptSubmit", "prompt": "@tone:off 随便说"})
        context = out["hookSpecificOutput"]["additionalContext"]
        self.assertIn("disabled", context)


if __name__ == "__main__":
    unittest.main()
