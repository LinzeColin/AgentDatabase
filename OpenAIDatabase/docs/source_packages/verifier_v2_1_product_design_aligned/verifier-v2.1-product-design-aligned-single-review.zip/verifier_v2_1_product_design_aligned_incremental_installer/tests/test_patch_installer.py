#!/usr/bin/env python3
"""End-to-end tests for the v2.1 fail-closed installer and rollback."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
FIXTURE = Path(__file__).resolve().parent / "fixtures/verifier_v2_payload.zip"


def load_module():
    spec = importlib.util.spec_from_file_location("verifier_v21_patch_installer", PACKAGE_ROOT / "apply_patch.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load apply_patch.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


installer = load_module()


def tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted((p for p in root.rglob("*") if p.is_file()), key=lambda p: p.relative_to(root).as_posix()):
        relative = path.relative_to(root).as_posix()
        digest.update(relative.encode("utf-8") + b"\0")
        digest.update(path.read_bytes())
    return digest.hexdigest()


class PatchInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.parent = Path(self.temporary.name)
        self.target = self.parent / "verifier"
        self.target.mkdir()
        with zipfile.ZipFile(FIXTURE) as archive:
            archive.extractall(self.target)
        self.manifest = installer.load_manifest()

    def tearDown(self):
        self.temporary.cleanup()

    def test_inspect_dry_run_apply_idempotence_and_rollback(self):
        state, problems = installer.target_state(self.target, self.manifest)
        self.assertEqual((state, problems), ("v2.0", []))
        before = tree_hash(self.target)

        dry = installer.apply_patch(self.target, dry_run=True, backup=None)
        self.assertEqual(dry["state"], "dry-run-passed")
        self.assertEqual(tree_hash(self.target), before)

        backup = self.parent / "verifier.backup-test"
        installed = installer.apply_patch(self.target, dry_run=False, backup=backup)
        self.assertEqual(installed["state"], "installed")
        self.assertEqual(installer.target_state(self.target, self.manifest)[0], "v2.1")
        self.assertEqual(installer.target_state(backup, self.manifest)[0], "v2.0")

        second = installer.apply_patch(self.target, dry_run=False, backup=None)
        self.assertEqual(second["state"], "already-installed")
        self.assertFalse(second["changed"])

        rolled_back = installer.rollback(self.target, backup)
        self.assertEqual(rolled_back["state"], "rolled-back")
        self.assertEqual(installer.target_state(self.target, self.manifest)[0], "v2.0")
        self.assertEqual(tree_hash(self.target), before)
        self.assertEqual(installer.target_state(Path(rolled_back["saved_v2_1"]), self.manifest)[0], "v2.1")

    def test_modified_baseline_fails_closed_without_change(self):
        skill = self.target / "SKILL.md"
        skill.write_text(skill.read_text(encoding="utf-8") + "\nmodified\n", encoding="utf-8")
        before = tree_hash(self.target)
        with self.assertRaises(installer.PatchError):
            installer.apply_patch(self.target, dry_run=False, backup=self.parent / "never-created")
        self.assertEqual(tree_hash(self.target), before)
        self.assertFalse((self.parent / "never-created").exists())
        self.assertFalse(any("v2_1-stage" in p.name for p in self.parent.iterdir()))

    def test_symlink_target_is_rejected(self):
        real = self.parent / "real-verifier"
        self.target.rename(real)
        try:
            self.target.symlink_to(real, target_is_directory=True)
        except OSError as error:
            self.skipTest(f"symlink unavailable: {error}")
        state, problems = installer.target_state(self.target, self.manifest)
        self.assertEqual(state, "invalid")
        self.assertTrue(any("symlink" in problem for problem in problems))
        with self.assertRaises(installer.PatchError):
            installer.apply_patch(self.target, dry_run=True, backup=None)


    def test_symlink_disguised_as_cache_directory_is_rejected(self):
        outside = self.parent / "outside-cache"
        outside.mkdir()
        cache_link = self.target / "__pycache__"
        try:
            cache_link.symlink_to(outside, target_is_directory=True)
        except OSError as error:
            self.skipTest(f"symlink unavailable: {error}")
        state, problems = installer.target_state(self.target, self.manifest)
        self.assertEqual(state, "invalid")
        self.assertTrue(any("symlink" in problem for problem in problems), problems)
        with self.assertRaises(installer.PatchError):
            installer.apply_patch(self.target, dry_run=True, backup=None)


    def test_unsafe_manifest_paths_are_rejected(self):
        for raw in ("../x", "a\\b", "/x", "C:/x", "a//b", "./x", "~user/x", ""):
            with self.subTest(raw=raw):
                with self.assertRaises(installer.PatchError):
                    installer.safe_relative(raw)

    def test_manifest_relationships_are_fail_closed(self):
        overlap = copy.deepcopy(self.manifest)
        overlap["unchanged_files"].append(overlap["modified_files"][0])
        with self.assertRaises(installer.PatchError):
            installer.validate_manifest_data(overlap)

        missing_classification = copy.deepcopy(self.manifest)
        removed = missing_classification["new_files"].pop()
        self.assertIn(removed, missing_classification["payload_files"])
        with self.assertRaises(installer.PatchError):
            installer.validate_manifest_data(missing_classification)

        case_collision = copy.deepcopy(self.manifest)
        original = case_collision["new_files"][0]
        case_collision["new_files"].append(original.swapcase())
        with self.assertRaises(installer.PatchError):
            installer.validate_manifest_data(case_collision)

    def test_recover_missing_target_from_exact_v2_backup(self):
        backup = self.parent / "verifier.backup-v2.0-crash-window"
        self.target.rename(backup)
        self.assertFalse(self.target.exists())
        result = installer.recover_missing_target(self.target, backup)
        self.assertEqual(result["state"], "recovered-v2")
        self.assertEqual(installer.target_state(self.target, self.manifest)[0], "v2.0")
        self.assertFalse(backup.exists())

        with self.assertRaises(installer.PatchError):
            installer.recover_missing_target(self.target, backup)


if __name__ == "__main__":
    unittest.main(verbosity=2)
