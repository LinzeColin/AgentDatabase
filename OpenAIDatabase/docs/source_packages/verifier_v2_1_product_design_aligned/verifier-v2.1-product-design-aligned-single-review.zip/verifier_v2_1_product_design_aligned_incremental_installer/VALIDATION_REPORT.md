# Verifier v2.1 Product-Design-Aligned + Single Review ZIP — Validation Report

- 日期：2026-07-19
- 范围：仅 Skill 2（单项目独立验收、交付放行、复验与证据封存）
- 基线：用户提供且已安装的 verifier v2
- 最终裁决：**INSTALL_READY / PASS**
- 用户真实全局安装：**NOT_RUN**（本包只完成离线安装、回滚和中断恢复演练）

## 输入与固定身份

| 对象 | SHA-256 / Root | 结果 |
|---|---|---|
| `verifier_creation_pack_v2(1).zip` | `597c0f5492d08cfa131343a115aa0dbe0b3a3e838fcacfa653fd0d56f4a8d3ef` | 精确 v2 基线来源 |
| v2 fixture（21 文件） | `ea54a0ed7a933bcbd94830751b364744778932faa6106a801ba46d8edab4fed4` | 解压后逐文件与基线完全一致 |
| 用户 v2.1 草案 | `3e62ab7f718c50311c56a231b7f22c5d870aac7420672f5eccb09bdfba058747` | 已研究，不直接安装 |
| 旧 Hardened 包 | `05454ed4724e72a0b29e5075611147a7aba66e79143be49f85aa0175818814dc` | 被本 Product-Design-Aligned 包取代 |
| 最终 payload inventory root | `0a450b29c716247a70ec3ddeedd6545b37e686c98ac19752a008f1ed97eb95b0` | 31 个 Skill 文件固定 |
| `PATCH_MANIFEST.json` | `a9a1a560edd24c94ff291073e0c015b5e1eaed37339a792f158d78e3c2b94f31` | 精确记录基线、payload 与集合关系 |
| `apply_patch.py` | `6c3c862a180cb38f7c2811408fb40be5dd71c7f31fece3cfdb9dc6530f834329` | fail-closed 增量安装器 |

`payload inventory root` 的计算方式为：按相对路径排序，对每个 `path + NUL + file_sha256 + LF` 连续计算 SHA-256。

## 变更范围

| 项目 | 数量 |
|---|---:|
| v2 基线文件 | 21 |
| v2.1 payload 文件 | 31 |
| 新增 | 10 |
| 修改 | 16 |
| 原样保留 | 5 |
| 删除 | 0 |

新增文件覆盖 Product-Design-Taskpack 只读接入、完整任务包快照、证据完整性、发布保证、AI/Agent 验收、finalizer、traceability、发布和 AI 模板，以及 sealed-run 单一复审 ZIP 打包器。

## 自动验证结果

1. Payload 结构、链接、frontmatter、模板与关键语义 validator：**PASS，0 errors**。
2. Skill 单元、契约、篡改、任务包、追溯、AI、finalizer 与单一复审 ZIP 测试：**35/35 PASS**。
3. 安装器路径、manifest、精确基线、symlink、dry-run、安装、幂等、回滚和恢复测试：**7/7 PASS**。
4. CLI 全链路：`inspect v2 → dry-run → apply → inspect v2.1 → rollback → crash-window recover → inspect recovered v2`：**全部 PASS**。
5. 安装 staging 会运行最终 payload validator、全部 35 项 Skill 测试和初始化 smoke；任何失败均在切换前终止。
6. 安装后精确 v2.1、保留备份精确 v2、回滚后精确 v2、恢复后精确 v2 均逐文件验证。
7. 单一复审 ZIP 两次打包字节级确定；未封存、篡改、symlink、目标已存在或试图写入 sealed run 均 fail-closed，且打包前后 evidence root 不变。

原始输出：

- `validation/current_single_zip_validation.txt`（本次单 ZIP 适配、真实 apply 与安装后复验）
- `validation/payload_validator.txt`
- `validation/payload_tests.txt`
- `validation/installer_tests.txt`
- `validation/cli_inspect_v2.txt`
- `validation/cli_dry_run.txt`
- `validation/cli_apply.txt`
- `validation/cli_inspect_v21.txt`
- `validation/cli_rollback.txt`
- `validation/cli_recover.txt`
- `validation/cli_inspect_recovered_v2.txt`

## Product-Design-Taskpack 对齐验证

- 完整任务包相关文件先复制到稳定临时快照，再发现七个语义角色和提取 ID，降低读取期间源变动歧义。
- `TASKPACK_SOURCE_SNAPSHOT.zip` 保存完整规范化源树；`source_files` 保存路径、大小和 SHA-256 清单。
- `pack_digest_sha256` 绑定完整规范化文件树；`contract_digest_sha256` 单独绑定七角色。
- 测试证明：七角色相同但附件/schema 不同，contract digest 保持相同而 full-pack digest 必然变化。
- 修改 source snapshot 或 taskpack lock inventory 均被 finalizer 阻断。
- 权威 Acceptance 必须由 Traceability Matrix 精确覆盖，Task/Test/Evidence/Subject 真实存在且 change-impact 非空。
- in-toto Test Result configuration 同时绑定完整任务包快照、taskpack lock、七角色、Traceability Matrix 和实际测试配置。

## 安装安全结论

- 只接受字节级匹配的 v2；人工修改、未知文件、新 v2.1 路径预先存在或目标不是 `verifier` 时拒绝。
- manifest 的 baseline/payload/classification 集合关系、数量、digest、重复、大小写冲突和不安全路径均 fail-closed。
- 不执行 smart merge，不接触 Skill 1，不接触被测产品。
- staging 与目标位于同一父目录；完整校验通过后才进行同文件系统 rename 切换。
- 安装进程内失败自动恢复原 v2；成功后保留完整 v2 备份。
- 极端 crash-window 恢复只接受“目标缺失 + 同目录精确 v2 备份”。

## 剩余边界

- 未操作用户真实 `<GLOBAL_SKILLS_ROOT>/verifier`，因此不能声称已安装。
- 用户当前 v2 若曾被改变，安装器会拒绝覆盖；这是安全行为，不是安装缺陷。
- 未签名 attestation 和哈希 seal 证明内部一致性与封存后变化，不证明来源真实性；高保证环境仍需可信 provenance/签名。
- Skill 2 编排项目已有或获授权工具，不内置全部测试平台，也不自动获得生产写入、压测、主动扫描或故障注入授权。
