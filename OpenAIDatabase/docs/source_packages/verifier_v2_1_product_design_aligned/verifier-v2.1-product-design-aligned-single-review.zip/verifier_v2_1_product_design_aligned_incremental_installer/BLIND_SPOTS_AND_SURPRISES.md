# Blind Spots & Surprises — Verifier v2.1

## 已补齐盲点

1. **七文件锁不等于完整任务包锁。** Acceptance 可能引用 schema、fixture、ADR、迁移说明或样例；只锁七文件会漏掉这些语义变化。已改为完整源快照 + 完整包摘要 + 七角色契约摘要。
2. **哈希正确不等于任务包适用，也不等于实现无漂移。** 完整性、兼容性、漂移被强制为三个独立门。
3. **Traceability 有行不等于追溯真实。** 现在要求 Acceptance 精确覆盖、Task/Test 实体存在、Evidence 路径存在、状态由原始结果聚合，并绑定同一 Subject。
4. **总体 AI 成功率会掩盖关键切片失败。** 每个声明切片独立达到阈值；多模型也不自动代表独立，generator 不能成为 sole judge，模型 grader 要求 cross-model、blind 与异源 evaluator。
5. **相同 ZIP 内容可能有不同 archive hash；相同七文件也可能有不同附件。** `source_archive_sha256`、`pack_digest_sha256` 和 `contract_digest_sha256` 分工明确，授权绑定规范化完整包摘要。
6. **dirty workspace 的旧 commit 会把 PASS 签在错误主体上。** 正向裁决必须绑定 source snapshot 或实际 artifact/image。
7. **未签名 attestation 不是真实性证明。** 它便于策略读取和内部一致性复验；来源真实性仍由可信 provenance/签名承担。
8. **渐进发布工具不是万能回滚。** 共享写资源、队列 worker、不可逆迁移和跨多服务发布可能不适合普通 Canary；必须证明并行版本兼容或使用受控 roll-forward/恢复。
9. **完整证据不等于方便交接。** 多个报告链接会增加 Owner 路由成本并让开发 agent 漏读；现在只在 sealed run 复验通过后生成一个确定性 `*_acceptance_review_taskpack.zip`，以 `README_FIRST.md` 作为 builder 入口，同时保留完整证据树和 evidence root。

## Surprise

- **“相同核心契约”与“相同授权包”是两个不同问题。** 七角色契约摘要相同，只能说明核心合同未变；完整包摘要不同仍可能意味着 schema 或测试输入已变，必须重验影响面。
- **最危险的绿色不是少测，而是测对了逻辑、签错了制品。** 所以 Subject identity 和 source-to-artifact-to-deployment 映射先于通过率。
- **BLOCKED 有时比 FAIL 更准确。** 任务包身份、适用性或证据无法证明时，不应猜测产品失败；应阻断并只请求最小缺失条件。
- **修复一个缺陷可能让旧证据全部失效。** 是否扩大复验取决于改变的契约、数据、依赖、配置和部署身份，而不是代码行数。
- **“只输出一个 ZIP”不等于删除内部证据。** 单 ZIP 是默认交付界面；完整 evidence tree 仍须本地保留并封存，否则便利会反过来破坏可审计性。
