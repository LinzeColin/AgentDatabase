#!/usr/bin/env python3
"""Fail-closed installer and rollback tool for verifier v2.1 Product-Design alignment.

The installer accepts only the exact v2 baseline recorded in PATCH_MANIFEST.json,
stages and validates the complete v2.1 payload, then switches directories with
same-filesystem renames and automatic in-process restoration on failure. It never
merges an unknown target, never modifies Skill 1, and retains a complete v2 backup.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


PACKAGE_ROOT = Path(__file__).resolve().parent
MANIFEST_PATH = PACKAGE_ROOT / "PATCH_MANIFEST.json"
CHECKSUMS_PATH = PACKAGE_ROOT / "SHA256SUMS.txt"
CACHE_DIR_NAMES = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
CACHE_SUFFIXES = {".pyc", ".pyo"}
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")


class PatchError(Exception):
    """Raised when installation cannot continue safely."""


def absolute_no_resolve(path: Path) -> Path:
    """Normalize to an absolute path without following the final symlink."""
    return Path(os.path.abspath(os.fspath(path.expanduser())))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_relative(raw: str) -> Path:
    """Parse a portable, normalized relative file path without accepting aliases."""
    if not isinstance(raw, str):
        raise PatchError(f"path must be a string, got {type(raw).__name__}")
    if not raw or "\x00" in raw or "\\" in raw:
        raise PatchError(f"unsafe relative path in manifest/checksum: {raw!r}")
    if raw.startswith(("/", "~")) or re.match(r"^[A-Za-z]:", raw):
        raise PatchError(f"unsafe relative path in manifest/checksum: {raw!r}")
    parts = raw.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise PatchError(f"unsafe relative path in manifest/checksum: {raw!r}")
    path = Path(*parts)
    if path.is_absolute():
        raise PatchError(f"unsafe relative path in manifest/checksum: {raw!r}")
    return path


def _validated_path_set(values: Any, *, label: str) -> list[str]:
    if not isinstance(values, list):
        raise PatchError(f"PATCH_MANIFEST {label} must be a list")
    normalized: list[str] = []
    seen: set[str] = set()
    seen_casefold: dict[str, str] = {}
    for raw_path in values:
        relative = safe_relative(raw_path)
        relative_text = relative.as_posix()
        folded = relative_text.casefold()
        if relative_text in seen:
            raise PatchError(f"duplicate path in PATCH_MANIFEST {label}: {relative_text}")
        if folded in seen_casefold:
            raise PatchError(
                f"case-insensitive path collision in PATCH_MANIFEST {label}: "
                f"{seen_casefold[folded]!r} vs {relative_text!r}"
            )
        seen.add(relative_text)
        seen_casefold[folded] = relative_text
        normalized.append(relative_text)
    return normalized


def validate_manifest_data(value: Any) -> dict[str, Any]:
    """Validate the complete patch manifest and its set relationships."""
    if not isinstance(value, dict) or value.get("schema_version") != "1.0":
        raise PatchError("unsupported PATCH_MANIFEST schema")

    exact_fields = {
        "scope": "skill-2-only",
        "base_version": "2.0",
        "target_version": "2.1",
        "expected_target_basename": "verifier",
        "apply_mode": "exact-baseline-same-filesystem-rename-with-automatic-in-process-restore",
    }
    for key, expected in exact_fields.items():
        if value.get(key) != expected:
            raise PatchError(f"PATCH_MANIFEST {key} must equal {expected!r}")
    for key in ("patch_id", "release_date"):
        if not isinstance(value.get(key), str) or not value[key].strip():
            raise PatchError(f"PATCH_MANIFEST missing non-empty string: {key}")

    base_archive = value.get("base_archive")
    if not isinstance(base_archive, dict):
        raise PatchError("PATCH_MANIFEST base_archive must be an object")
    if not isinstance(base_archive.get("filename"), str) or not base_archive["filename"]:
        raise PatchError("PATCH_MANIFEST base_archive.filename must be non-empty")
    if not isinstance(base_archive.get("sha256"), str) or not SHA256_RE.fullmatch(
        base_archive["sha256"]
    ):
        raise PatchError("PATCH_MANIFEST base_archive.sha256 must be SHA-256")

    mappings: dict[str, dict[str, str]] = {}
    for key in ("baseline_files", "payload_files"):
        mapping = value.get(key)
        if not isinstance(mapping, dict) or not mapping:
            raise PatchError(f"PATCH_MANIFEST missing non-empty object: {key}")
        normalized_mapping: dict[str, str] = {}
        local_casefold: dict[str, str] = {}
        for raw_path, digest in mapping.items():
            relative = safe_relative(raw_path)
            relative_text = relative.as_posix()
            folded = relative_text.casefold()
            if folded in local_casefold:
                raise PatchError(
                    f"case-insensitive path collision in {key}: "
                    f"{local_casefold[folded]!r} vs {relative_text!r}"
                )
            if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
                raise PatchError(f"invalid digest in {key}: {relative_text}")
            local_casefold[folded] = relative_text
            normalized_mapping[relative_text] = digest.lower()
        mappings[key] = normalized_mapping

    classifications: dict[str, list[str]] = {}
    for key in ("new_files", "modified_files", "unchanged_files", "removed_files"):
        classifications[key] = _validated_path_set(value.get(key), label=key)

    classified_sets = {key: set(paths) for key, paths in classifications.items()}
    keys = list(classified_sets)
    for index, left in enumerate(keys):
        for right in keys[index + 1 :]:
            overlap = classified_sets[left] & classified_sets[right]
            if overlap:
                raise PatchError(
                    f"PATCH_MANIFEST classifications overlap ({left}, {right}): {sorted(overlap)}"
                )

    baseline_set = set(mappings["baseline_files"])
    payload_set = set(mappings["payload_files"])
    expected_baseline = (
        classified_sets["modified_files"]
        | classified_sets["unchanged_files"]
        | classified_sets["removed_files"]
    )
    expected_payload = (
        classified_sets["new_files"]
        | classified_sets["modified_files"]
        | classified_sets["unchanged_files"]
    )
    if baseline_set != expected_baseline:
        raise PatchError(
            "PATCH_MANIFEST baseline classification mismatch; "
            f"missing={sorted(baseline_set - expected_baseline)}, "
            f"extra={sorted(expected_baseline - baseline_set)}"
        )
    if payload_set != expected_payload:
        raise PatchError(
            "PATCH_MANIFEST payload classification mismatch; "
            f"missing={sorted(payload_set - expected_payload)}, "
            f"extra={sorted(expected_payload - payload_set)}"
        )

    for path in classifications["unchanged_files"]:
        if mappings["baseline_files"][path] != mappings["payload_files"][path]:
            raise PatchError(f"unchanged file digest differs between baseline and payload: {path}")
    for path in classifications["modified_files"]:
        if mappings["baseline_files"][path] == mappings["payload_files"][path]:
            raise PatchError(f"modified file digest did not change: {path}")

    counts = value.get("counts")
    if not isinstance(counts, dict):
        raise PatchError("PATCH_MANIFEST counts must be an object")
    expected_counts = {
        "baseline_files": len(baseline_set),
        "payload_files": len(payload_set),
        **{key: len(paths) for key, paths in classifications.items()},
    }
    for key, expected in expected_counts.items():
        if counts.get(key) != expected:
            raise PatchError(
                f"PATCH_MANIFEST counts.{key} must equal {expected}, got {counts.get(key)!r}"
            )

    return value

def is_cache_path(relative: Path) -> bool:
    return any(part in CACHE_DIR_NAMES for part in relative.parts) or relative.suffix in CACHE_SUFFIXES


def regular_file_inventory(root: Path, *, ignore_caches: bool) -> set[str]:
    inventory: set[str] = set()
    for path in root.rglob("*"):
        relative = path.relative_to(root)
        if ignore_caches and is_cache_path(relative):
            continue
        if path.is_file() and not path.is_symlink():
            inventory.add(relative.as_posix())
    return inventory


def load_manifest() -> dict[str, Any]:
    try:
        value = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise PatchError(f"cannot read PATCH_MANIFEST.json: {error}") from error
    return validate_manifest_data(value)

def verify_package_checksums() -> None:
    try:
        lines = CHECKSUMS_PATH.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise PatchError(f"cannot read SHA256SUMS.txt: {error}") from error
    verify_portable_tree(PACKAGE_ROOT, allow_caches=True)
    seen: set[str] = set()
    for line in lines:
        if not line.strip():
            continue
        try:
            expected, raw_path = line.split("  ", 1)
        except ValueError as error:
            raise PatchError(f"invalid SHA256SUMS line: {line!r}") from error
        if not SHA256_RE.fullmatch(expected):
            raise PatchError(f"invalid SHA-256 value for {raw_path!r}")
        relative = safe_relative(raw_path)
        relative_text = relative.as_posix()
        if relative_text in seen:
            raise PatchError(f"duplicate checksum path: {relative}")
        seen.add(relative_text)
        candidate = PACKAGE_ROOT / relative
        if not candidate.is_file() or candidate.is_symlink():
            raise PatchError(f"bundle file missing or unsafe: {relative}")
        if sha256_file(candidate) != expected:
            raise PatchError(f"bundle checksum mismatch: {relative}")

    actual = regular_file_inventory(PACKAGE_ROOT, ignore_caches=True) - {"SHA256SUMS.txt"}
    if seen != actual:
        raise PatchError(
            "SHA256SUMS file set mismatch; "
            f"missing={sorted(actual - seen)}, extra={sorted(seen - actual)}"
        )
    required = {
        "PATCH_MANIFEST.json",
        "apply_patch.py",
        "README_先看这里.md",
        "PRODUCT_DECISION.md",
        "RESEARCH_BENCHMARK_V2_1.md",
        "BLIND_SPOTS_AND_SURPRISES.md",
        "VALIDATION_REPORT.md",
        "tests/test_patch_installer.py",
        "tests/fixtures/verifier_v2_payload.zip",
    }
    if not required.issubset(seen):
        raise PatchError(f"SHA256SUMS omits required files: {sorted(required - seen)}")


def verify_portable_tree(root: Path, *, allow_caches: bool) -> None:
    if not root.is_dir() or root.is_symlink():
        raise PatchError(f"not a safe directory: {root}")
    seen_casefold: dict[str, str] = {}
    for path in root.rglob("*"):
        relative = path.relative_to(root)
        relative_text = safe_relative(relative.as_posix()).as_posix()
        folded = relative_text.casefold()
        if folded in seen_casefold:
            raise PatchError(
                "case-insensitive filesystem collision is forbidden: "
                f"{seen_casefold[folded]!r} vs {relative_text!r}"
            )
        seen_casefold[folded] = relative_text
        mode = path.lstat().st_mode
        # Cache entries may be ignored for exact inventory, but never for type safety.
        # A symlink named __pycache__ must not escape the tree during copy/validation.
        if stat.S_ISLNK(mode):
            raise PatchError(f"symlink is forbidden: {relative}")
        if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise PatchError(f"non-regular filesystem entry is forbidden: {relative}")
        if allow_caches and is_cache_path(relative):
            continue

def verify_payload(manifest: dict[str, Any]) -> None:
    payload_root = PACKAGE_ROOT / "payload"
    verify_portable_tree(payload_root, allow_caches=False)
    expected_files = manifest["payload_files"]
    actual_files = regular_file_inventory(payload_root, ignore_caches=False)
    if actual_files != set(expected_files):
        raise PatchError(
            "payload file set mismatch; "
            f"missing={sorted(set(expected_files) - actual_files)}, "
            f"extra={sorted(actual_files - set(expected_files))}"
        )
    for raw_path, expected in expected_files.items():
        relative = safe_relative(raw_path)
        if sha256_file(payload_root / relative) != expected:
            raise PatchError(f"payload checksum mismatch: {relative}")


def compare_exact_tree(
    target: Path,
    expected_files: dict[str, str],
    *,
    label: str,
) -> list[str]:
    problems: list[str] = []
    actual_files = regular_file_inventory(target, ignore_caches=True)
    expected_set = set(expected_files)
    missing = sorted(expected_set - actual_files)
    extra = sorted(actual_files - expected_set)
    if missing:
        problems.append(f"{label} files missing: {missing}")
    if extra:
        problems.append(f"{label} unexpected files: {extra}")
    for raw_path, expected in expected_files.items():
        path = target / safe_relative(raw_path)
        if not path.is_file() or path.is_symlink():
            continue
        actual = sha256_file(path)
        if actual != expected:
            problems.append(f"{label} file modified: {raw_path}")
    return problems


def target_state(target: Path, manifest: dict[str, Any]) -> tuple[str, list[str]]:
    if not target.exists() and not target.is_symlink():
        return "missing", [f"target does not exist: {target}"]
    if target.is_symlink() or not target.is_dir():
        return "invalid", ["target must be a real directory, not a symlink"]
    try:
        verify_portable_tree(target, allow_caches=True)
    except PatchError as error:
        return "invalid", [str(error)]

    final_problems = compare_exact_tree(target, manifest["payload_files"], label="v2.1")
    if not final_problems:
        return "v2.1", []

    baseline_problems = compare_exact_tree(target, manifest["baseline_files"], label="v2 baseline")
    for raw_path in manifest.get("new_files", []):
        path = target / safe_relative(raw_path)
        if path.exists() or path.is_symlink():
            baseline_problems.append(f"new v2.1 path already exists on non-v2.1 target: {raw_path}")
    return ("v2.0", []) if not baseline_problems else ("mismatch", baseline_problems)


def remove_caches(root: Path) -> None:
    for directory in list(root.rglob("*")):
        if directory.is_dir() and not directory.is_symlink() and directory.name in CACHE_DIR_NAMES:
            shutil.rmtree(directory)
    for path in list(root.rglob("*")):
        if path.is_file() and path.suffix in CACHE_SUFFIXES:
            path.unlink()


def overlay_payload(stage: Path, manifest: dict[str, Any]) -> None:
    payload_root = PACKAGE_ROOT / "payload"
    for raw_path in sorted(manifest["payload_files"]):
        relative = safe_relative(raw_path)
        source = payload_root / relative
        destination = stage / relative
        if destination.exists() and destination.is_dir():
            raise PatchError(f"file/directory conflict in target: {relative}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    remove_caches(stage)


def run_command(command: list[str], *, cwd: Optional[Path] = None) -> str:
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        command,
        cwd=str(cwd) if cwd else None,
        env=environment,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if result.returncode != 0:
        raise PatchError(
            f"validation command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}"
        )
    return result.stdout


def validate_stage(stage: Path, manifest: dict[str, Any]) -> dict[str, str]:
    verify_portable_tree(stage, allow_caches=False)
    problems = compare_exact_tree(stage, manifest["payload_files"], label="staged v2.1")
    if problems:
        raise PatchError("; ".join(problems))

    outputs: dict[str, str] = {}
    outputs["pack"] = run_command(
        [sys.executable, str(stage / "scripts/validate_pack.py"), str(stage), "--json"]
    )
    outputs["tests"] = run_command(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(stage / "tests"),
            "-p",
            "test_*.py",
            "-v",
        ]
    )
    with tempfile.TemporaryDirectory(prefix="verifier-v2.1-install-smoke-") as temporary:
        smoke_root = Path(temporary)
        outputs["init"] = run_command(
            [
                sys.executable,
                str(stage / "scripts/init_acceptance_run.py"),
                str(smoke_root),
                "安装冒烟",
                "--run-id",
                "install-smoke",
                "--target-path",
                "apps/smoke",
                "--decision-scope",
                "developer_check",
            ]
        )
        created = list(smoke_root.glob("*_acceptance_install-smoke"))
        if len(created) != 1:
            raise PatchError("initializer smoke did not create exactly one run directory")
        for required in ("RUN_MANIFEST.yaml", "RELEASE_ASSURANCE.md", "AI_EVAL_MATRIX.md"):
            if not (created[0] / required).is_file():
                raise PatchError(f"initializer smoke missing {required}")
    remove_caches(stage)
    return outputs


def create_stage(target: Path, manifest: dict[str, Any]) -> Path:
    stage = Path(tempfile.mkdtemp(prefix=f".{target.name}.v2_1-stage-", dir=str(target.parent)))
    try:
        shutil.copytree(target, stage, dirs_exist_ok=True, copy_function=shutil.copy2)
        remove_caches(stage)
        overlay_payload(stage, manifest)
        validate_stage(stage, manifest)
        return stage
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise


def default_backup_path(target: Path) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return target.parent / f"{target.name}.backup-v2.0-{stamp}"


def apply_patch(target: Path, *, dry_run: bool, backup: Optional[Path]) -> dict[str, Any]:
    manifest = load_manifest()
    verify_package_checksums()
    verify_payload(manifest)
    target = absolute_no_resolve(target)
    if target.name != manifest.get("expected_target_basename", "verifier"):
        raise PatchError(
            f"target basename must be {manifest.get('expected_target_basename', 'verifier')!r}: {target}"
        )
    state, problems = target_state(target, manifest)
    if state == "v2.1":
        return {"ok": True, "state": "already-installed", "target": str(target), "changed": False}
    if state != "v2.0":
        raise PatchError("target is not the exact verified v2 baseline:\n- " + "\n- ".join(problems))
    if target.parent.is_symlink() or not target.parent.is_dir():
        raise PatchError(f"target parent must be a real directory: {target.parent}")
    if not os.access(target.parent, os.W_OK):
        raise PatchError(f"target parent is not writable: {target.parent}")

    stage = create_stage(target, manifest)
    if dry_run:
        shutil.rmtree(stage, ignore_errors=True)
        return {
            "ok": True,
            "state": "dry-run-passed",
            "target": str(target),
            "changed": False,
            "patch_id": manifest.get("patch_id"),
        }

    backup_path = absolute_no_resolve(backup or default_backup_path(target))
    if backup_path.exists() or backup_path.is_symlink():
        shutil.rmtree(stage, ignore_errors=True)
        raise PatchError(f"backup path already exists: {backup_path}")
    if backup_path.parent != target.parent:
        shutil.rmtree(stage, ignore_errors=True)
        raise PatchError("backup must be in the same parent directory for safe rename switching")

    moved_old = False
    moved_new = False
    try:
        os.replace(target, backup_path)
        moved_old = True
        os.replace(stage, target)
        moved_new = True
        final_state, final_problems = target_state(target, manifest)
        if final_state != "v2.1":
            raise PatchError("post-install state mismatch: " + "; ".join(final_problems))
        backup_state, backup_problems = target_state(backup_path, manifest)
        if backup_state != "v2.0":
            raise PatchError("retained backup is not exact v2: " + "; ".join(backup_problems))
        run_command([sys.executable, str(target / "scripts/validate_pack.py"), str(target), "--json"])
    except Exception as error:
        if moved_new and (target.exists() or target.is_symlink()):
            failed = target.parent / (
                f".{target.name}.failed-v2.1-"
                f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
            )
            os.replace(target, failed)
            shutil.rmtree(failed, ignore_errors=True)
        if moved_old and backup_path.exists():
            os.replace(backup_path, target)
        if stage.exists():
            shutil.rmtree(stage, ignore_errors=True)
        raise PatchError(f"installation failed and the original target was restored: {error}") from error

    return {
        "ok": True,
        "state": "installed",
        "target": str(target),
        "backup": str(backup_path),
        "changed": True,
        "patch_id": manifest.get("patch_id"),
        "rollback_command": (
            f"{sys.executable} {Path(__file__).name} rollback "
            f"--target {target} --backup {backup_path}"
        ),
    }


def rollback(target: Path, backup: Path) -> dict[str, Any]:
    manifest = load_manifest()
    verify_package_checksums()
    verify_payload(manifest)
    target = absolute_no_resolve(target)
    backup = absolute_no_resolve(backup)
    current_state, current_problems = target_state(target, manifest)
    if current_state != "v2.1":
        raise PatchError(
            "refusing rollback: current target is not exact v2.1 payload: "
            + "; ".join(current_problems)
        )
    backup_state, backup_problems = target_state(backup, manifest)
    if backup_state != "v2.0":
        raise PatchError(
            "refusing rollback: backup is not exact v2 baseline: "
            + "; ".join(backup_problems)
        )
    if target.parent != backup.parent:
        raise PatchError("target and backup must share a parent for safe rename rollback")
    saved = target.parent / (
        f"{target.name}.saved-v2.1-"
        f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    )
    if saved.exists() or saved.is_symlink():
        raise PatchError(f"rollback save path already exists: {saved}")
    moved_current = False
    moved_backup = False
    try:
        os.replace(target, saved)
        moved_current = True
        os.replace(backup, target)
        moved_backup = True
        restored_state, restored_problems = target_state(target, manifest)
        if restored_state != "v2.0":
            raise PatchError(
                "restored target failed baseline verification: " + "; ".join(restored_problems)
            )
    except Exception as error:
        if moved_backup and target.exists():
            os.replace(target, backup)
        if moved_current and saved.exists():
            os.replace(saved, target)
        raise PatchError(f"rollback failed; original v2.1 was restored: {error}") from error
    return {
        "ok": True,
        "state": "rolled-back",
        "target": str(target),
        "saved_v2_1": str(saved),
        "changed": True,
    }


def recover_missing_target(target: Path, backup: Path) -> dict[str, Any]:
    """Recover exact v2 when interruption left the canonical target path absent."""
    manifest = load_manifest()
    verify_package_checksums()
    verify_payload(manifest)
    target = absolute_no_resolve(target)
    backup = absolute_no_resolve(backup)
    if target.name != manifest.get("expected_target_basename", "verifier"):
        raise PatchError(
            f"target basename must be {manifest.get('expected_target_basename', 'verifier')!r}: {target}"
        )
    if target.exists() or target.is_symlink():
        raise PatchError("recover is only for a missing target; use rollback when v2.1 exists")
    if target.parent != backup.parent:
        raise PatchError("target and backup must share a parent for safe rename recovery")
    backup_state, backup_problems = target_state(backup, manifest)
    if backup_state != "v2.0":
        raise PatchError(
            "refusing recovery: backup is not exact v2 baseline: "
            + "; ".join(backup_problems)
        )
    os.replace(backup, target)
    restored_state, restored_problems = target_state(target, manifest)
    if restored_state != "v2.0":
        os.replace(target, backup)
        raise PatchError(
            "recovery verification failed; backup was restored to its original path: "
            + "; ".join(restored_problems)
        )
    return {
        "ok": True,
        "state": "recovered-v2",
        "target": str(target),
        "changed": True,
    }


def inspect(target: Path) -> dict[str, Any]:
    manifest = load_manifest()
    verify_package_checksums()
    verify_payload(manifest)
    target = absolute_no_resolve(target)
    state, problems = target_state(target, manifest)
    return {
        "ok": state in {"v2.0", "v2.1"},
        "state": state,
        "target": str(target),
        "problems": problems,
    }


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    subparsers = parser.add_subparsers(dest="command", required=True)

    apply_parser = subparsers.add_parser("apply", help="validate, stage, and safely switch to the patch")
    apply_parser.add_argument("--target", required=True, type=Path)
    apply_parser.add_argument("--dry-run", action="store_true")
    apply_parser.add_argument("--backup", type=Path)

    rollback_parser = subparsers.add_parser("rollback", help="restore a retained v2 backup")
    rollback_parser.add_argument("--target", required=True, type=Path)
    rollback_parser.add_argument("--backup", required=True, type=Path)

    recover_parser = subparsers.add_parser(
        "recover", help="restore exact v2 when an interrupted switch left the target missing"
    )
    recover_parser.add_argument("--target", required=True, type=Path)
    recover_parser.add_argument("--backup", required=True, type=Path)

    inspect_parser = subparsers.add_parser("inspect", help="identify target state")
    inspect_parser.add_argument("--target", required=True, type=Path)
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    try:
        if args.command == "apply":
            result = apply_patch(args.target, dry_run=args.dry_run, backup=args.backup)
        elif args.command == "rollback":
            result = rollback(args.target, args.backup)
        elif args.command == "recover":
            result = recover_missing_target(args.target, args.backup)
        else:
            result = inspect(args.target)
    except (PatchError, OSError) as error:
        result = {"ok": False, "error": str(error)}
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"ERROR: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
