# Verifier v2.1 — Product-Design-Taskpack 对齐 + 单一复审 ZIP 增量安装包

## 适用范围

本包只升级 **Skill 2：单项目独立验收、交付放行与复验**。它不会安装、修改、补写或重新解释 Skill 1，也不会修改被测产品。

安装器只接受本包 `PATCH_MANIFEST.json` 记录的**精确 verifier v2 基线**。目标目录存在人工修改、未知文件、symlink、基线不符或安装包校验失败时一律拒绝覆盖，并保持原 v2 不变。

## 安装

在解压后的本目录执行；把 `<GLOBAL_SKILLS_ROOT>` 替换为真实全局 Skill 根目录：

```bash
python3 apply_patch.py --json inspect \
  --target <GLOBAL_SKILLS_ROOT>/verifier

python3 apply_patch.py --json apply \
  --target <GLOBAL_SKILLS_ROOT>/verifier \
  --dry-run

python3 apply_patch.py --json apply \
  --target <GLOBAL_SKILLS_ROOT>/verifier
```

安装器会先校验整个安装包和 payload，复制精确 v2 到同目录 staging，应用 v2.1 payload，执行 validator、全部 Skill 测试与初始化 smoke，全部通过后才以同文件系统目录重命名切换。安装进程内失败会自动恢复原 v2；成功后保留完整 v2 备份并返回精确回滚命令。

## 回滚与极端中断恢复

```bash
python3 apply_patch.py --json rollback \
  --target <GLOBAL_SKILLS_ROOT>/verifier \
  --backup <安装输出中的备份路径>
```

只有断电或强杀恰好发生于两次目录重命名之间、导致标准目标路径不存在时，才使用：

```bash
python3 apply_patch.py --json recover \
  --target <GLOBAL_SKILLS_ROOT>/verifier \
  --backup <GLOBAL_SKILLS_ROOT>/verifier.backup-v2.0-<timestamp>
```

`recover` 只接受“目标确实不存在、备份与目标同目录、备份是精确 v2”，否则拒绝。

## v2.1 关键增强

- **默认单一交付物**：Owner 只说“验收一下”时，内部完整 evidence tree 仍保留，但对外只交付一个 `*_acceptance_review_taskpack.zip`；根目录 `README_FIRST.md` 让开发 agent 可直接按缺陷、修改要求、测试矩阵和证据开发。
- **完整任务包双锁**：只读冻结全部相关任务包文件为确定性 `TASKPACK_SOURCE_SNAPSHOT.zip`；`pack_digest_sha256` 绑定规范化完整文件树，`contract_digest_sha256` 单独绑定七个核心语义角色。schema、fixture、ADR 或附件变化不会被七文件相同所掩盖。
- **Skill 1 边界不变**：Verifier 只读取、锁定、追溯和裁决已授权任务包；发现缺失、歧义或漂移时阻断，不替 Owner 改任务包。
- **强追溯**：每个权威 Acceptance 必须唯一闭合到 Oracle、锁定 Task、实际 Test、原始 Evidence 和精确 Subject，并具有实际交付 `change_impact`。
- **精确交付身份**：建立 `source snapshot → build → artifact/image digest → deployment identity`；测试源码 A 不能放行制品 B。
- **作用域化 PASS**：严格区分 `developer_check | release_candidate | staged_release | post_deploy`，低层结论不能冒充生产稳定。
- **发布与恢复保证**：支持 Canary/Ring/Blue-Green、control、bake、健康与业务门、自动中止、rollback/roll-forward 和上线后复核。
- **AI/Agent 专项**：每个声明任务切片至少 3 个独立 trial，按切片计算阈值；验证最终 world state、工具副作用、成本、延迟与 evaluator 独立性，禁止总体平均或模型自评掩盖关键失败。
- **机器可验证证据**：生成 `EVIDENCE_INDEX.json`、`FINAL_DECISION.json`、`SHA256SUMS.txt` 和 in-toto Test Result attestation；封存后增删改可被复验发现。
- **Fail-closed 安装**：精确基线、完整 manifest 集合关系、路径安全、大小写冲突、symlink、staging 测试、回滚和 crash-window 恢复均自动验证。

## 重要语义

哈希和未签名 attestation 证明的是**内部一致性与封存后是否变化**，不是来源真实性。高保证放行仍应核验可信 provenance、签名、受控构建与部署映射。

## 默认使用习惯

用户说“调用 skill，说你验收一下”时，Skill 可以在聊天中简述 verdict/进度，但默认只链接一个 `*_acceptance_review_taskpack.zip`。内部报告、截图和 evidence directory 不逐个暴露；只有 Owner 明确要求时才展开。
