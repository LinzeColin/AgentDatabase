# Product Decision — Verifier v2.1 Product-Design-Aligned

- 决策日期：2026-07-19
- 范围：仅 Skill 2
- 基线：用户已安装的精确 verifier v2
- 目标：让 Skill 2 独立消费已定版 Product-Design-Taskpack，自动完成验收、放行、复验与证据封存，并把默认外部交付收敛为一个可直接交给开发 agent 的验收复审 ZIP
- 决策：以本增量安装包作为 v2.1 定版候选；不直接安装较早的 v2.1 草案或旧 Hardened 包

## 产品不变量

```text
一个目标项目
+ 一个经授权且完整锁定的任务包
+ 一个不可变交付主体
+ Acceptance→Oracle→Task→Test→Evidence→Subject 强追溯
+ 风险适配的真实结果验证
+ 明确的 verdict scope
+ 可复验、可发现篡改的证据
+ 一个 builder-first、封存后生成的唯一默认复审 ZIP
= 才允许给出交付结论
```

## 相对 v2 的实际变化

- v2 基线文件：21
- v2.1 payload 文件：31
- 新增：10
- 修改：16
- 原样保留：5
- 删除：0

新增能力文件：

- `references/product-design-taskpack-contract.md`
- `references/evidence-integrity.md`
- `references/release-assurance.md`
- `references/ai-system-acceptance.md`
- `scripts/ingest_taskpack.py`
- `scripts/finalize_acceptance_run.py`
- `scripts/package_review_taskpack.py`
- `templates/TRACEABILITY_MATRIX.json`
- `templates/RELEASE_ASSURANCE.md`
- `templates/AI_EVAL_MATRIX.md`

## 本版解决的伪通过

1. 只锁七个主文件，却漏掉被引用 schema、fixture、ADR 或附件的变化；
2. 同名 ZIP、重新压缩 ZIP 或“最新版”被错误视为同一授权任务包；
3. 有测试结果但没有证明测试对应实际交付制品；
4. Traceability 表面完整，但 Acceptance、Task、Test 或 Subject 并不真实存在或不一致；
5. `developer_check PASS` 被扩张解释为可生产发布；
6. Canary、观察期、自动中止和恢复没有证据，却宣称上线成功；
7. AI 总体平均掩盖关键任务切片失败，或生成模型成为自己唯一裁判；
8. 裁决后替换、删除或补写证据仍沿用旧结论；
9. 增量安装覆盖到被人工修改的 v2，形成不可审计混合状态。
10. 验收结果散落为多个报告、截图和目录，Owner 无法把一个自包含任务包直接交给开发 agent。

## 强制门

- 完整任务包快照、完整包摘要、七角色契约摘要和授权摘要必须一致；
- 哈希完整性、语义兼容性和任务包/Oracle 漂移必须分别举证；
- 权威 Acceptance 必须被 Traceability Matrix 精确覆盖，且 change-impact 非空；
- 正向发布结论必须绑定 artifact/image digest；部署结论还必须证明 deployment mapping；
- blocking FAIL/BLOCKED/NOT_RUN、不可豁免 finding、关键 flaky 或无安全恢复路径均阻止正向 verdict；
- AI 每个声明切片独立达到阈值，generator 不得成为 sole judge；
- finalizer 与 `--verify` 必须同时通过。
