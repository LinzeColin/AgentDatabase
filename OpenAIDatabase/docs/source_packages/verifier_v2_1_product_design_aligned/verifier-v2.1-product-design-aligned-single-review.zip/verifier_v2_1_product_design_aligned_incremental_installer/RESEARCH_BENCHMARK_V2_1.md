# Verifier v2.1 — 公开项目与工程标准对标

核验日期：2026-07-19。只采用官方文档、标准正文或项目官方仓库；这些对象用于设计校准和工具路由，不被打包为依赖，也不被宣称为任何公司的完整内部 SOP。

## 一手标准与工程机制

| 来源 | 可验证机制 | v2.1 吸收方式 |
|---|---|---|
| in-toto Test Result v0.1 | 以机器可读 statement 绑定被测 Subject、测试配置和 passed/warned/failed tests | 生成 `ACCEPTANCE_ATTESTATION.intoto.json`；策略可验证“是否跑了正确配置、必要测试是否通过” |
| SLSA v1.2 Provenance / Verification | 将 artifact 与 source、builder、build process 和策略验证绑定 | 分离 source、build、artifact/image 与 deployment identity；不把文件名、tag 或 build 名当不可变身份 |
| NIST SSDF 800-218 / 218A | 开发、发布、供应链和 AI 风险验证贯穿生命周期 | 安全/供应链/AI 门按风险适配；发布证据和维护责任进入验收范围 |
| OWASP ASVS | 风险分级的应用安全验证要求 | 安全检查按应用风险与授权路由；扫描结果需确认，不能自动等同真实漏洞 |
| W3C WCAG 2.2 | 自动检查不能单独证明完整符合性 | 自动规则与键盘、焦点、状态、真人旅程结合，并明确未覆盖的辅助技术 |
| Google SRE Canary / Production Readiness | 小流量对照、关键指标、观察窗、生产就绪和恢复 | `release_candidate`、`staged_release`、`post_deploy` 分层；control、bake、abort、rollback/roll-forward |
| Microsoft Safe Deployment Practices | Ring、渐进暴露、健康门和逐级扩大范围 | 发布阶段明确 cohort、promotion/abort 条件与爆炸半径 |
| AWS Operational Readiness / Automated rollback | 上线前验证人员、流程、运行能力，发布后自动判断与回退 | Owner/on-call、runbook、dashboard、容量、备份恢复和 post-deploy 关键旅程 |
| OpenAI Evaluation Best Practices | 任务特定、真实分布、持续评估、记录与 grader 校准 | AI task slices、多 trial、原始记录、世界状态 Oracle、持续回归 |
| Anthropic Agent Evals | task/trial/grader/trace/outcome 分离，多 trial，最终环境状态优先 | 每个切片单独达阈值；禁止模型自报、总体平均或同源非盲 grader 伪通过 |

## GitHub 与公开项目横向调研

| 项目 | 强项 | 对 Skill 2 的结论 |
|---|---|---|
| Pact | Consumer-driven contract testing，重放消费者期望验证 provider | 用于多服务契约门；不能替代真实 E2E、数据结果或发布观察 |
| Schemathesis | 从 OpenAPI/GraphQL 自动生成 property-based 边界测试与最小复现 | 用于 API 负向、边界和 schema 漂移；必须受目标 allowlist 与成本门约束 |
| Testcontainers | 以可丢弃容器运行真实数据库、消息队列等依赖 | 减少 mock 假阳性；仍需证明版本/配置与目标环境有代表性 |
| Testkube | 在 Kubernetes 中编排不同工具、顺序/并行 workflow 与证据 | 可作为执行适配层；Verifier 仍保留统一 verdict、追溯和证据语义 |
| Tracetest | 基于 OpenTelemetry trace 对分布式调用链做断言 | 补足“接口 200 但内部链路错误”；不能替代最终数据/用户世界状态 |
| Argo Rollouts | Canary/Blue-Green、AnalysisRun、指标驱动 promotion/abort/rollback | 对应 staged-release 自动放量与中止；不假设所有工作负载适合多版本并行 |
| Flagger | 逐步流量切换、KPI 分析、自动 promotion/rollback | 对应健康/业务门与失败回切；阈值和 control 必须预先定义 |
| LitmusChaos | 受控故障注入发现基础设施和应用韧性弱点 | 仅在隔离、授权、abort、备份和恢复条件完整时路由；不默认执行破坏性实验 |
| OpenTelemetry | 统一 trace、metric、log 信号语义 | 用于证据关联、候选/基线对照和发布后诊断；观测存在不等于业务正确 |
| GitHub CodeQL / SARIF | 语义代码分析与标准化静态分析结果交换 | 安全证据可纳入；告警需去重、确认、绑定 commit，不能用“0 alert”证明全部安全 |

## 公开来源

- https://in-toto.io/attestation/test-result/
- https://slsa.dev/spec/v1.2/provenance
- https://slsa.dev/spec/v1.2/verifying-artifacts
- https://csrc.nist.gov/pubs/sp/800/218/final
- https://csrc.nist.gov/news/2024/nist-publishes-sp-800-218a
- https://owasp.org/www-project-application-security-verification-standard/
- https://www.w3.org/WAI/WCAG22/Understanding/conformance
- https://sre.google/workbook/canarying-releases/
- https://sre.google/sre-book/evolving-sre-engagement-model/
- https://learn.microsoft.com/en-us/azure/well-architected/operational-excellence/safe-deployments
- https://docs.aws.amazon.com/wellarchitected/latest/framework/ops_ready_to_support_const_orr.html
- https://docs.aws.amazon.com/wellarchitected/latest/operational-excellence-pillar/ops_mit_deploy_risks_auto_testing_and_rollback.html
- https://developers.openai.com/api/docs/guides/evaluation-best-practices
- https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- https://docs.pact.io/
- https://schemathesis.readthedocs.io/
- https://testcontainers.com/
- https://docs.testkube.io/articles/test-workflows
- https://github.com/kubeshop/tracetest
- https://argo-rollouts.readthedocs.io/en/stable/features/analysis/
- https://docs.flagger.app/tutorials/nginx-progressive-delivery
- https://docs.litmuschaos.io/docs/introduction/what-is-litmus
- https://opentelemetry.io/docs/concepts/signals/
- https://docs.github.com/code-security/code-scanning/automatically-scanning-your-code-for-vulnerabilities-and-errors/about-code-scanning

## 收敛结论

不存在一个现成开源项目能同时完成“任务包授权锁定、精确交付身份、Acceptance 强追溯、真实结果 Oracle、发布观察、AI 评测、统一裁决和证据封存”。因此 v2.1 不重复造所有测试执行器，而是定义统一的机器契约和 fail-closed 门，并按项目现有栈路由到合适工具。
