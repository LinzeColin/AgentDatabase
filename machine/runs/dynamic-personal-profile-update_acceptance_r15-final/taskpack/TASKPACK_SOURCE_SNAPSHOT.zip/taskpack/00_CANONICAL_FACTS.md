---
doc_id: "P01-CANONICAL-FACTS"
doc_type: "canonical_facts"
version: "0.0.0.1"
status: "frozen_for_acceptance"
---

# Canonical Facts

## Confirmed facts

- The current work is Stage 1. No Stage 2 governance expansion or full raw-data processing is authorized by this package.
- The user wants immediately usable Skill, Workflow, and Prompt assets that can later grow into a larger system.
- Dynamic profile output must be readable by humans, Memory Atlas, ordinary LLMs, and ordinary Agents.
- v0.0.0.1 reads only existing redacted derived data.
- The scheduled check runs every three calendar days on GitHub Actions Free, but an individual run may exit with `NO_CHANGE` and create no commit.
- The only persistent data output of the profile Action is `OpenAIDatabase/data/derived/profile/DYNAMIC_PROFILE.md`.
- `CORE_PROFILE.md`, active memory, Custom Instructions, AGENTS.md, and canonical memory records are outside the write boundary.
- Skill registration, evaluation, controlled iteration, and runtime logs are separate governance surfaces.
- Registration belongs under `CodexSkills/registry/`; runtime records belong under `OpenAIDatabase/data/run_logs/skills_runs/`.
- The registry schema reserves four Skill source namespaces—`agents`, `claude`, `codex-system`, and `codex`; v0.0.0.1 registers the new `codex` Skill there, while broad migration of existing mirror namespaces remains the separately gated T02 task.
- Version changes are patch-only: `0.0.0.N`.
- Accepted Stage 1 opportunities are `Profile-to-Agent-Action Prompt` and `Recurring Asset Miner`.
- `Emerging Capability Trial` is retained only as a single trial gate inside those assets, not as an independent project.
- All other previously unselected opportunities are retired and must not be reintroduced without explicit authorization.

## Non-negotiable governance red line

Every output and component must have a real consumer, a single owner, a bounded write scope, a measurable acceptance test, a stop condition, and a rollback path. No ceremonial schemas, ledgers, dashboards, duplicate indexes, or empty directories are added.

## Unknowns intentionally retained

- GitHub schedule delivery time can be delayed and public-repository scheduled workflows can be disabled after prolonged inactivity; this is an operational risk, not a reason to add another scheduler.
- Full raw-data processing is a future design decision and is not part of v0.0.0.1.
- Existing public mirror migration must be run by the implementing Codex against the latest `main` checkout; this package does not assume a stale tree is safe to rewrite.
