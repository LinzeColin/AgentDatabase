---
doc_id: "P01-SECURITY-PRIVACY"
doc_type: "security_and_privacy"
version: "0.0.0.1"
status: "frozen_for_acceptance"
---

# Security and Privacy

## Threat model

`SKILL.md` is operational text, not passive documentation. A malicious or contaminated Skill can influence discovery, selection, and execution. The public repository must therefore expose only reviewed, derived, credential-free material.

## Controls

- Explicit derived-input allowlist; no broad repository scan.
- Repository-relative path validation; reject `..`, symlinks, raw/private namespaces, cookies, tokens, private keys, and local absolute paths.
- No network, shell interpolation, package installation, API key, LLM call, or dynamic code execution in the processor.
- GitHub Action `contents: write` only; no issues, pull requests, packages, deployments, or secrets permissions.
- `concurrency` prevents overlapping profile writers.
- Atomic replacement preserves the last valid profile on failure.
- Validator runs before the commit step.
- Commit allowlist contains only `DYNAMIC_PROFILE.md` for the scheduled update.
- Stable profile and memory writes are explicitly false in the output contract.
- Registry provenance and evaluation records are separate from runtime profile data.
- Skill iterations are patch-only and require a regression fixture for discovered failures.

## Data classification

| Class | v0.0.0.1 policy |
|---|---|
| Raw conversations, exports, browser state, tokens | Forbidden |
| Redacted derived reports | Allowlisted read-only input |
| Dynamic profile Markdown | One derived output |
| Stable profile / canonical memory | Read-only |
| Runtime log | Compact redacted facts only, future controlled integration |

## Incident response

If a forbidden path/content or unexpected file diff appears: fail closed, do not push, disable the workflow, preserve the prior output, inspect the run, remove the offending source or code, and rerun tests. Do not rewrite history or silently delete evidence.
