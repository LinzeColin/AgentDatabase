---
doc_id: "P01-OPERATIONS-ROLLBACK"
doc_type: "operations_and_rollback"
version: "0.0.0.1"
status: "frozen_for_acceptance"
---

# Operations, Cost Gate, and Rollback

## Schedule

- GitHub Action: `17 1 */3 * *` UTC plus manual `workflow_dispatch`.
- This is a calendar-day step and may be delayed by GitHub; it is not a strict 72-hour timer.
- The workflow runs on the default branch and should be manually re-enabled if GitHub disables a public scheduled workflow after prolonged inactivity.

## Run sequence

1. Checkout with shallow history.
2. Run deterministic processor.
3. Validate the single output.
4. Check the exact diff allowlist.
5. Commit and push only when the profile bytes materially change.
6. Otherwise return `NO_CHANGE` and end successfully.

## Cost gate

The run is justified only when the expected value of detecting a meaningful profile change or asset candidate exceeds runner time, maintenance, and human review cost. No LLM/API cost exists in v0.0.0.1. Three consecutive `NO_CHANGE` runs are evidence for keeping the schedule but not adding more infrastructure; repeated no-value runs trigger a review of frequency or a kill decision.

## Rollback

1. Disable the workflow.
2. Restore the prior `DYNAMIC_PROFILE.md` from the last known-good commit.
3. Re-run the validator and tests.
4. Revert the Skill package to the prior patch version.
5. Preserve the failure record; do not rewrite history.

## Future gate

Full raw-data first baseline and later incremental processing are Stage 2 decisions. They require a new privacy review, input contract, capacity test, and explicit authorization. They cannot be enabled by changing a glob in v0.0.0.1.
