from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
UPDATE = ROOT / "scripts/update_dynamic_profile.py"
VALIDATE = ROOT / "scripts/validate_dynamic_profile.py"


class DynamicProfileTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        derived = self.root / "OpenAIDatabase/data/derived/behavior_intelligence"
        derived.mkdir(parents=True)
        payload = {
            "generated_at": "2026-07-22T00:00:00Z",
            "self_iteration_suggestions": [
                {"title": "Recurring task", "statement": "Use a fixed evidence-first workflow", "confidence": "medium"},
                {"title": "Recurring task", "statement": "Use a fixed evidence-first workflow", "confidence": "medium"},
            ],
        }
        (derived / "signals.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        (self.root / "OpenAIDatabase/data/raw").mkdir(parents=True)
        (self.root / "OpenAIDatabase/data/raw/secret.txt").write_text("do not read this", encoding="utf-8")
        self.output = self.root / "OpenAIDatabase/data/derived/profile/DYNAMIC_PROFILE.md"

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_update(self) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(UPDATE), "--database-dir", str(self.root), "--output", str(self.output), "--now", "2026-07-22T12:00:00Z"],
            text=True,
            capture_output=True,
        )

    def test_first_run_is_dual_plane_and_valid(self) -> None:
        result = self.run_update()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(self.output.exists())
        content = self.output.read_text(encoding="utf-8")
        self.assertIn("# Dynamic Personal Profile", content)
        self.assertNotIn("do not read this", content)
        checked = subprocess.run([sys.executable, str(VALIDATE), "--profile", str(self.output)], text=True, capture_output=True)
        self.assertEqual(checked.returncode, 0, checked.stderr)

    def test_same_input_is_idempotent(self) -> None:
        first = self.run_update()
        self.assertEqual(first.returncode, 0, first.stderr)
        before = self.output.read_bytes()
        second = self.run_update()
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertIn("NO_CHANGE", second.stdout)
        self.assertEqual(before, self.output.read_bytes())

    def test_missing_sources_stop_without_overwriting_previous_output(self) -> None:
        first = self.run_update()
        self.assertEqual(first.returncode, 0, first.stderr)
        before = self.output.read_bytes()
        for path in (self.root / "OpenAIDatabase/data/derived").rglob("*"):
            if path.is_file() and path != self.output:
                path.unlink()
        stopped = self.run_update()
        self.assertEqual(stopped.returncode, 2)
        self.assertEqual(before, self.output.read_bytes())


if __name__ == "__main__":
    unittest.main()
