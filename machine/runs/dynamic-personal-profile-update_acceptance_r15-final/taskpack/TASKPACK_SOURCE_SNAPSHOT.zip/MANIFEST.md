# Delivery Manifest

version: `0.0.0.1`
stage: `1`
status: `frozen_for_acceptance`

## Included

- Portable `SKILL.md` with progressive disclosure references.
- Deterministic processor and fail-closed validator.
- Unit tests and no-change/failure fixtures.
- GitHub Actions workflow for the three-day derived-only check.
- Registry record with five meaningful layers.
- Evaluation and controlled-iteration records.
- Seven dual-plane taskpack documents plus one machine taskpack manifest.
- Roadmap and one-line pursuing goal prompt.
- Static `dynamic_profile` discovery-route contract for Memory Atlas consumers.

## Persistent output boundary

The implementation may persist only:

`OpenAIDatabase/data/derived/profile/DYNAMIC_PROFILE.md`

The repository integration may separately maintain Skill registry/evaluation/control documents, static discovery-route configuration, and compact run facts under their explicitly governed locations. The scheduled profile Action itself must not write those files.

## Not included

Raw conversations, private exports, secrets, LLM/API integrations, a database, vector index, stable-memory writeback, or any rejected opportunity.
