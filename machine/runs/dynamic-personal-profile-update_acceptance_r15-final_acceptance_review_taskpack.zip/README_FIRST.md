# 验收复审任务包 — 开发 Agent 先看这里

这是 verifier 已封存并复验的只读验收结果。请不要修改本 ZIP 内证据，而是在目标产品自己的隔离 worktree 中完成开发。

## 开发顺序

1. 先读 `dynamic-personal-profile-update_acceptance_r15-final/VERDICT.md`，确认裁决范围与不可豁免门。
2. 按 `dynamic-personal-profile-update_acceptance_r15-final/DEFECT_REPORT.md` 逐项最小复现。
3. 以 `dynamic-personal-profile-update_acceptance_r15-final/MODIFICATION_REPORT.md` 作为修复任务与回归边界。
4. 用 `dynamic-personal-profile-update_acceptance_r15-final/TEST_MATRIX.md` 和原始 Evidence 证明修复，不改写旧证据。
5. 交付新的不可变 commit/build/artifact 后，交给 fresh verifier 独立复验。

## 完整性

- Evidence root SHA-256: `cfee2016d1f655c4b65466b9d64d7feac3a55a87c0452cd7e0b32ca82592538d`
- 内部逐文件校验：`dynamic-personal-profile-update_acceptance_r15-final/SHA256SUMS.txt`
- 机器裁决：`dynamic-personal-profile-update_acceptance_r15-final/FINAL_DECISION.json`
- Test Result attestation: `dynamic-personal-profile-update_acceptance_r15-final/ACCEPTANCE_ATTESTATION.intoto.json`

本任务包是开发输入，不是修复后的通过证明。
